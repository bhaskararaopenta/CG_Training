package com.training.service;

import com.training.bean.EmployeeDTO;

public interface IEmployeeService {

	public int saveEmployee(EmployeeDTO edto);
}
