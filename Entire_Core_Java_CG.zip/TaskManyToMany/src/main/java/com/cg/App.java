package com.cg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Course;
import com.cg.entity.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sfty = cfg.buildSessionFactory();
		Session sion = sfty.openSession();
		Transaction tx = sion.beginTransaction();

		Course c1 = new Course();
		c1.setCrId(1);
		c1.setCrName("CJ");
		c1.setCrCost(2.2);

		sion.persist(c1);

		Course c2 = new Course();
		c2.setCrId(2);
		c2.setCrName("AJ");
		c2.setCrCost(5.5);

		sion.persist(c2);

		Course c3 = new Course();
		c3.setCrId(3);
		c3.setCrName("HI");
		c3.setCrCost(5.5);

		sion.persist(c3);

		Student s1 = new Student();
		s1.setStdId(88);
		s1.setStdName("AJ");
		s1.setStdMarsk(3.36);
		s1.getCobs().add(c1);
		s1.getCobs().add(c2);

		sion.persist(s1);

		Student s2 = new Student();
		s2.setStdId(89);
		s2.setStdName("VJ");
		s2.setStdMarsk(8.98);
		s2.getCobs().add(c2);
		s2.getCobs().add(c3);

		sion.persist(s2);

		Student s3 = new Student();
		s3.setStdId(90);
		s3.setStdName("UJ");
		s3.setStdMarsk(7.88);
		s3.getCobs().add(c1);

		sion.persist(s3);
		tx.commit();
	}
}
