package com.cg;

public class Calculation {

	public int getSum(int x, int y) {
		return x + y;
		// TODO Auto-generated method stub

	}

	public String[] getBookList() {
		String blst[] = { "java", "dotnet", "python" };
		return blst;
	}

	public int getEven(int n) {
		if (n % 2 == 0) {
			return 0;
		} else {
			return -1;
		}
	}
}
