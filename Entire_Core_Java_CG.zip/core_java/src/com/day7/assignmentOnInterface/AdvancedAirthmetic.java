package com.day7.assignmentOnInterface;

public interface AdvancedAirthmetic {

	abstract int divisorSum(int n);
}
