package com.cg.exception;

public class CGBookException extends Exception {
	private static final long serialVersionUID = 1L;

	public CGBookException(String message) {
		super(message);
	}
}
