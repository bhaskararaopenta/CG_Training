package com.cg.hbm.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.hbm.entity.RoomDetails;
import com.cg.hbm.exceptions.RoomDetailsNotFoundException;
import com.cg.hbm.repository.IRoomDetailsRepository;
import com.cg.hbm.service.IRoomDetailsServiceImpl;

@ExtendWith(MockitoExtension.class)  // Automatically initializes mocks and injects dependencies
public class RoomTest {

    @Mock
    private IRoomDetailsRepository detailsRepository;

    @InjectMocks
    private IRoomDetailsServiceImpl roomDetailsService;

    private RoomDetails roomDetails;

    @BeforeEach
    public void setUp() {
        // Initialize RoomDetails object before each test
        roomDetails = new RoomDetails();
        roomDetails.setRoom_id(1);
        roomDetails.setHotel_id(101);
        roomDetails.setRoom_no("A101");
        roomDetails.setRoom_type("Single");
        roomDetails.setRate_per_day(1000);
        roomDetails.setAvailable(true);
        roomDetails.setPhoto("photo.jpg");
    }

    // Test for adding room details
    @Test
    public void testAddRoomDetails() throws RoomDetailsNotFoundException {
        when(detailsRepository.save(roomDetails)).thenReturn(roomDetails);
        RoomDetails result = roomDetailsService.addRoomDetails(roomDetails);
        assertNotNull(result);
        assertEquals(roomDetails.getRoom_id(), result.getRoom_id());
        verify(detailsRepository, times(1)).save(roomDetails);
    }

    // Test for updating room details
    @Test
    public void testUpdateRoomDetails() throws RoomDetailsNotFoundException {
        when(detailsRepository.findById(1)).thenReturn(Optional.of(roomDetails));
        when(detailsRepository.save(roomDetails)).thenReturn(roomDetails);
        roomDetails.setRate_per_day(1200);
        RoomDetails updatedDetails = roomDetailsService.updateRoomDetails(roomDetails);
        assertNotNull(updatedDetails);
        assertEquals(1200, updatedDetails.getRate_per_day());
        verify(detailsRepository, times(1)).save(roomDetails);
    }

    // Test for handling room details not found exception during update
    @Test
    public void testUpdateRoomDetails_ThrowsRoomDetailsNotFoundException() {
        when(detailsRepository.findById(1)).thenReturn(Optional.empty());
        RoomDetailsNotFoundException exception = assertThrows(RoomDetailsNotFoundException.class, () -> {
            roomDetailsService.updateRoomDetails(roomDetails);
        });
        assertEquals("Service.ROOMDETAILS_NOT_FOUND", exception.getMessage());
    }

    // Test for removing room details
    @Test
    public void testRemoveRoomDetails() throws RoomDetailsNotFoundException {
        when(detailsRepository.findById(1)).thenReturn(Optional.of(roomDetails));
        RoomDetails deletedRoomDetails = roomDetailsService.removeRoomDetails(roomDetails);
        assertNotNull(deletedRoomDetails);
        verify(detailsRepository, times(1)).delete(roomDetails);
    }

    // Test for handling room details not found exception during removal
    @Test
    public void testRemoveRoomDetails_ThrowsRoomDetailsNotFoundException() {
        when(detailsRepository.findById(1)).thenReturn(Optional.empty());
        RoomDetailsNotFoundException exception = assertThrows(RoomDetailsNotFoundException.class, () -> {
            roomDetailsService.removeRoomDetails(roomDetails);
        });
        assertEquals("Service.ROOMDETAIL_NOT_FOUND", exception.getMessage());
    }

    // Test for showing all room details
    @Test
    public void testShowAllRoomDetails() throws RoomDetailsNotFoundException {
        when(detailsRepository.findAll()).thenReturn(List.of(roomDetails));
        var result = roomDetailsService.showAllRoomDetails();
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(detailsRepository, times(1)).findAll();
    }

    // Test for showing specific room details by ID
    @Test
    public void testShowRoomDetails() throws RoomDetailsNotFoundException {
        when(detailsRepository.findById(1)).thenReturn(Optional.of(roomDetails));
        RoomDetails result = roomDetailsService.showRoomDetails(1);
        assertNotNull(result);
        assertEquals(roomDetails.getRoom_id(), result.getRoom_id());
        verify(detailsRepository, times(1)).findById(1);
    }

    // Test for handling room details not found exception during retrieval
    @Test
    public void testShowRoomDetails_ThrowsRoomDetailsNotFoundException() {
        when(detailsRepository.findById(1)).thenReturn(Optional.empty());
        RoomDetailsNotFoundException exception = assertThrows(RoomDetailsNotFoundException.class, () -> {
            roomDetailsService.showRoomDetails(1);
        });
        assertEquals("Service.ROOMDETAIL_NOT_FOUND", exception.getMessage());
    }
}