package com.cg.ovms.exception;

import java.time.LocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex){
		
		return new ResponseEntity<>(
				ex.getBindingResult()
				.getAllErrors()
				.get(0)
				.getDefaultMessage() , HttpStatus.BAD_REQUEST);		
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleAllExceptions(Exception ex){
		
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler(RuntimeException.class)
	public final ResponseEntity<ExceptionResponse> handleNotFoundException(RuntimeException ex, WebRequest request) {
		
		// Fill the code here
		
		ExceptionResponse res = new ExceptionResponse(LocalDate.now(),ex.getMessage(),request.getDescription(false),"Not found");
		return new ResponseEntity<>(res , HttpStatus.NOT_FOUND);	
	}
	
	@ExceptionHandler(BadGatewayException.class)
    public ResponseEntity<String> handleBadGatewayException(BadGatewayException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_GATEWAY);
    }
}
