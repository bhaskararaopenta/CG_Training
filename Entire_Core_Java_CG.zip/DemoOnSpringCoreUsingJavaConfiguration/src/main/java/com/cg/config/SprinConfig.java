package com.cg.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.bean.Address;
import com.cg.bean.Employee;

@Configuration
public class SprinConfig {

	@Bean(name = "eop")
	public Employee getEmployeeObject() {
		Employee emp = new Employee();
		emp.setEmpId(1021);
		emp.setEmpName("martin");
		emp.setEmpSal(400);
		emp.setAddress(getAddressObject());
		return emp;
		// TODO Auto-generated method stub

	}

	@Bean(name = "add")
	public Address getAddressObject() {
		Address ad = new Address();
		ad.setCity("vzm");
		ad.setDistrict("kothavalasa");
		ad.setState("vizianagaram");
		return ad;
	}
}
