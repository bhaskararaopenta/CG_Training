package com.day4.polymorphism;

public class ExampleOnOverride1 {
	
	int a=10;
	
	public void m1() {
		System.out.println("we are in method m1");
	}
	
	public String sayHello(String s) {
		return "Hello "+s;

	}

}
