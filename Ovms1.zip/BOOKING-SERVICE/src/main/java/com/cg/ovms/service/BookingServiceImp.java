package com.cg.ovms.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entities.Booking;
import com.cg.ovms.exception.BadRequestException;
import com.cg.ovms.exception.ResourceNotFoundException;
import com.cg.ovms.repository.BookingRepository;

@Service
public class BookingServiceImp implements IBookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Override
    public Booking addBooking(Booking booking) {
        if (booking == null) {
            throw new BadRequestException("Booking cannot be null");
        }
        return bookingRepository.save(booking);
    }

    @Override
    public Booking cancelBooking(Booking b) {
        Booking booking = bookingRepository.findById(b.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for this id :: " + b.getBookingId()));
        bookingRepository.delete(booking);
        return booking;
    }

    @Override
    public Booking updateBooking(Booking b) {
        Booking booking = bookingRepository.findById(b.getBookingId())
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for this id :: " + b.getBookingId()));
        booking.setBookingDate(b.getBookingDate());
        booking.setBookedTillDate(b.getBookedTillDate());
        booking.setBookingDescription(b.getBookingDescription());
        booking.setTotalCost(b.getTotalCost());
        booking.setDistance(b.getDistance());
        booking.setDelivery(b.isDelivery());
        final Booking updatedBooking = bookingRepository.save(booking);
        return updatedBooking;
    }

    @Override
    public Booking viewById(int bookingId) {
        return bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found for this id :: " + bookingId));
    }

    @Override
    public List<Booking> viewAllBooking(int customerId) {
        return bookingRepository.findByCustomerIdEquals(customerId);
    }

    @Override
    public List<Booking> viewAllBookingByDate(LocalDate bookingDate) {
        return bookingRepository.findByBookingDateLessThanEqual(bookingDate);
    }

    @Override
    public List<Booking> viewAllBookingByVehicle(int vehicleId) {
        return bookingRepository.findByVehicleIdEquals(vehicleId);
    }
}