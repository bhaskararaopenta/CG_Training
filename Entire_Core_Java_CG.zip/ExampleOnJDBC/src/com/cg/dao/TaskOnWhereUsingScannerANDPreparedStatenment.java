package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TaskOnWhereUsingScannerANDPreparedStatenment {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the deptno to search");
		int dno = sc.nextInt();

		/*
		 * Class.forName("com.mysql.cj.jdbc.Driver");
		 * 
		 * String url = "jdbc:mysql://localhost:3306/batch2"; String uname = "root";
		 * String pwd = "root";
		 * 
		 * Connection con = DriverManager.getConnection(url, uname, pwd);
		 */

		Connection con = DBUtil.getMySQLConnection();

		Statement st = con.createStatement();

		String query = "select empno,ename,job,sal from emp where deptno=" + dno;
		ResultSet res = st.executeQuery(query);
		System.out.println("Employee details are :- ");
		while (res.next()) {
			System.out.println(res.getInt("empno") + " " + res.getString("ename") + " " + res.getString("job") + " "
					+ res.getDouble("sal"));
		}
	}

}
