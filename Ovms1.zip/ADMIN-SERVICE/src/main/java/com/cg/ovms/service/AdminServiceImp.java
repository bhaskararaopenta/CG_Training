package com.cg.ovms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entity.Admin;
import com.cg.ovms.exception.ResourceNotFoundException;
import com.cg.ovms.repository.AdminRepository;

@Service
public class AdminServiceImp implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Override
    public Admin addAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    @Override
    public Admin viewById(int adminId) {
        return adminRepository.findById(adminId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found for this id :: " + adminId));
    }

    @Override
    public Admin deleteById(int adminId) {
        Admin admin = adminRepository.findById(adminId)
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found for this id :: " + adminId));
        adminRepository.delete(admin);
        return admin;
    }

    @Override
    public Admin updateAdmin(Admin admin) {
        Admin existingAdmin = adminRepository.findById(admin.getAdminId())
                .orElseThrow(() -> new ResourceNotFoundException("Admin not found for this id :: " + admin.getAdminId()));
        existingAdmin.setAdminName(admin.getAdminName());
        return adminRepository.save(existingAdmin);
    }
}