package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ExampleForDQLUsingPreparedStatement {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);

		String query = "select * from dept";
		PreparedStatement st = con.prepareStatement(query);

		ResultSet res = st.executeQuery();
		System.out.println("Department details are : ");
		while (res.next()) {
			// System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getString(3));
			System.out.println(res.getInt("deptno") + " " + res.getString("dname") + " " + res.getString("loc"));
		}

		res.close();
		st.close();
		con.close();

	}

}
