import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class CartonUtility {
	private List<Carton> cartonList;

	// FILL THE CODE HERE

	public Stream<Carton> convertToStream() {

		Stream<Carton> res = cartonList.stream();
		// FILL THE CODE HERE
		return res;
	}

	public List<Carton> getCartonList() {
		return cartonList;
	}

	public void setCartonList(List<Carton> cartonList) {
		this.cartonList = cartonList;
	}

	public Carton findMax(Stream<Carton> stream1) {

		// FILL THE CODE HERE
		Comparator<Carton> ct = (x, y) -> x.getQuantity() > y.getQuantity() ? -1
				: x.getQuantity() < y.getQuantity() ? 1 : 0;
		Carton res = stream1.max(ct).get();
		return res;

	}

}
