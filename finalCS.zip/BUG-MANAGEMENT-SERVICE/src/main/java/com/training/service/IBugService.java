package com.training.service;

import java.util.List;

import com.training.dto.BugDTO;
import com.training.entity.Bug;
import com.training.exception.BugException;

public interface IBugService {
	 
	public BugDTO createBug(BugDTO bugdto) throws BugException;
	public BugDTO updateBug(Long id, BugDTO bugdto)throws BugException;
	public BugDTO getBug(Long id) throws BugException ;
	public List<BugDTO> getAllBugs() throws BugException ;
	public List<BugDTO> getAllBugsByStatus() throws BugException ;
	public BugDTO deleteBug(Long id) throws BugException ;

}
