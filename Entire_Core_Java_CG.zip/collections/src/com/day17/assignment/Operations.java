package com.day17.assignment;

public class Operations {

	public boolean isValidPrice(double price) throws InvalidProductException {

		if (price >= 100 && price <= 50000) {
			return true;
		} else {
			throw new InvalidProductException("Entry is invalid");
		}

		// product price should be in the inclusive range 100 and 50000
		// if not throw the exception
	}

	public boolean isValidName(String name) throws InvalidProductException {

		if (name.substring(0, 4).equals("prod") && name.length() <= 15) {
			return true;
		} else {
			throw new InvalidProductException("entry is invalid");
		}

		// product name should starts with prod_anyName(max 15) else throw the exception
	}
}
