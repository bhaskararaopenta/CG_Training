 package com.cg.hbm.exceptions;

public class TransactionsNotFoundException extends Exception {

	public TransactionsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
