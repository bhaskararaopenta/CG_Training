package com.day15.lamdaExpression;

@FunctionalInterface
public interface MethodRefrence {

	public String sayHello(String s);
}
