package com.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOnSpringRestApiWithDataJpaWithGlobalExceptionAndValidationAndAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
