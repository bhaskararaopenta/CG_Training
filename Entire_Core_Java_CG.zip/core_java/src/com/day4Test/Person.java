package com.day4Test;

public class Person {

	String name = "smith";

	public void display() {
		System.out.println("name is " + name);
	}
}
