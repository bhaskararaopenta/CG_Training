package com.cg.ovms.service;





import java.util.List;

import com.cg.ovms.entities.Driver;
import com.cg.ovms.exception.DriverNotFoundException;


public interface DriverService {
    Driver addDriver(Driver driver) ;
    Driver updateDriver(Driver driver) throws DriverNotFoundException;
    void deleteDriver(int driverId);
    Driver findById(int driverId) throws DriverNotFoundException;
    List<Driver> findAllDriver();
    Driver findByVehicleId(int vehicleId);
}
