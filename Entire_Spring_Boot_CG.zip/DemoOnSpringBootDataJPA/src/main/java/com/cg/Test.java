package com.cg;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cg.entity.Product;
import com.cg.service.IProductService;

@Component
public class Test implements CommandLineRunner {

	@Autowired
	private IProductService pService;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		// 1:- insert operation :--

		/*
		 * Product p = new Product(); p.setProdName("Rose"); p.setColor("Red");
		 * p.setCost(800);
		 * 
		 * int res = pService.insertProduct(p);
		 * System.out.println(" record inserted successfully " + res);
		 */

		// 2 :- Search specific record
		/*
		 * Optional<Product> opt = pService.searchById(10);
		 * 
		 * if (opt.isEmpty()) { System.out.println("Record Does not exist"); } else {
		 * Product p = opt.get(); System.out.println(p.getProdId() + " " +
		 * p.getProdName() + " " + p.getColor() + " " + p.getCost()); }
		 */

		// 3 :- Display all the Records

		/*
		 * List<Product> pobj = pService.getAllProductDetails(); if (pobj.isEmpty()) {
		 * System.out.println("No Records"); } else { for (Product pro : pobj) {
		 * System.out.println( pro.getProdId() + " " + pro.getProdName() + " " +
		 * pro.getColor() + " " + pro.getCost()); } }
		 */

		// 4 :- Delete by id
		// pService.productDeleteById(1);

		// 5 :- Update Based On Id
		/*
		 * Product p = new Product(); p.setProdId(2); p.setProdName("ewwwww");
		 * p.setColor("Black"); p.setCost(1500); int res = pService.updateProduct(p);
		 * 
		 * System.out.println("record " + res + " is updated");
		 */

		// 6 :- Search Based On ProductName (This is custom Query)
		// search based on QueryApproach 1.Query by methodName using find..by or
		/*
		 * Optional<Product> res = pService.searchByProdName("Rose"); if (res.isEmpty())
		 * { System.out.println("Data doesn't exist"); } else { Product p = res.get();
		 * System.out.println("Data exist :-------"); System.out.println(p.getProdId() +
		 * " " + p.getProdName() + " " + p.getColor() + " " + p.getCost()); }
		 */

		// 7 :- Search Based On ProductName (This is using @query)
		// calling method of @query annotation ----> to write custom query
		/*
		 * List<Product> res = pService.searchProductsByProdName("Rose"); if
		 * (res.isEmpty()) { System.out.println("Records doesn't exist"); } else {
		 * System.out.println("Product Details are :---"); for (Product pro : res) {
		 * System.out.println( pro.getProdId() + " " + pro.getProdName() + " " +
		 * pro.getColor() + " " + pro.getCost()); } }
		 */

		// 8 :- Serach Based On ProductName (This is using @NamedQuery)

		List<Product> res = pService.searchProductsByProdNameThirdWay("ewwwww");
		if (res.isEmpty()) {
			System.out.println("Data doesn't exist");
		} else {
			System.out.println("Data exist :-");
			for (Product pro : res) {
				System.out.println(
						pro.getProdId() + " " + pro.getProdName() + " " + pro.getColor() + " " + pro.getCost());
			}
		}
	}

}
