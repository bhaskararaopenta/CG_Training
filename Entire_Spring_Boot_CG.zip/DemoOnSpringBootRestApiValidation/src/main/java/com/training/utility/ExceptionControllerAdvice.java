package com.training.utility;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.training.exception.BankException;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;

@RestControllerAdvice
public class ExceptionControllerAdvice {
	@Autowired
	Environment environment;

	/*
	 * @ExceptionHandler(Exception.class) public ResponseEntity<ErrorInfo>
	 * exceptionHandler(Exception exception) { ErrorInfo error = new ErrorInfo();
	 * error.setErrorMessage(environment.getProperty("General.EXCEPTION_MESSAGE"));
	 * error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
	 * error.setTimestamp(LocalDateTime.now()); return new
	 * ResponseEntity<ErrorInfo>(error, HttpStatus.INTERNAL_SERVER_ERROR); }
	 */
	@ExceptionHandler(BankException.class)
	public ResponseEntity<ErrorInfo> bankExceptionHandler(BankException exception) {
		ErrorInfo error = new ErrorInfo();
		error.setErrorMessage(environment.getProperty(exception.getMessage()));
		error.setTimestamp(LocalDateTime.now());
		error.setErrorCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ErrorInfo>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorInfo> restApiValidationsExceptionHandler(MethodArgumentNotValidException mave) {
		ErrorInfo info = new ErrorInfo();
		info.setTimestamp(LocalDateTime.now());
		info.setErrorCode(HttpStatus.BAD_REQUEST.value());
		/*
		 * String msg =
		 * mave.getBindingResult().getAllErrors().stream().map(x->x.getDefaultMessage())
		 * .collect(Collectors.joining(","));
		 */

		List<ObjectError> erobj = mave.getBindingResult().getAllErrors();
		Stream<ObjectError> stobj = erobj.stream();
		Stream<String> smg = stobj.map(x -> x.getDefaultMessage());
		String msg = smg.collect(Collectors.joining(","));

		info.setErrorMessage(msg);
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorInfo> restPathVariableValidation(ConstraintViolationException cve) {
		ErrorInfo info = new ErrorInfo();
		info.setTimestamp(LocalDateTime.now());
		info.setErrorCode(HttpStatus.BAD_REQUEST.value());

		// String
		// msg=cve.getConstraintViolations().stream().map(x->x.getMessage()).collect(Collectors.joining(","));

		Set<ConstraintViolation<?>> scv = cve.getConstraintViolations();
		Stream<ConstraintViolation<?>> stcv = scv.stream();
		Stream<String> st = stcv.map(x -> x.getMessage());
		String msg = st.collect(Collectors.joining(","));
		info.setErrorMessage(msg);
		return new ResponseEntity<ErrorInfo>(info, HttpStatus.BAD_REQUEST);
	}
}
