package com.cg.hbm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.hbm.UserApplication;

@SpringBootTest(classes = UserApplication.class)
class UserApplicationTests {

	@Test
	void contextLoads() {
	}

}
