package com.cg.hbm.dto;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entity.RoomDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
@Setter
@Getter
@AllArgsConstructor
public class RoomDetailsDTO {
	private BookingDetails bookingDetails;
	private RoomDetails roomDetails;

}
