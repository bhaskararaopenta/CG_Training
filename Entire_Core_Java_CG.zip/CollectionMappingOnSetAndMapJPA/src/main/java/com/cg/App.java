package com.cg;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Customer;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		Customer c = new Customer();
		c.setCustId(1001);
		c.setCustName("mohan");

		Set<String> st = new HashSet<String>();
		st.add("java");
		st.add("python");

		c.setCustData(st);

		Map<Integer, String> mp = new HashMap<Integer, String>();
		mp.put(10, "Hyd");
		mp.put(11, "Banglore");
		c.setData(mp);
		ses.persist(c);
		tx.commit();
		ses.close();
	}
}
