package com.cg;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cg.entity.BookEntity;
import com.cg.service.IBookService;

@Component
public class Test implements CommandLineRunner {

	@Autowired
	private IBookService iBookService;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		// 1 :- insert Operation
		/*
		 * BookEntity bookEntity = new BookEntity();
		 * bookEntity.setAuthorName("Bhaskar"); bookEntity.setTitle("Beach Vibes");
		 * bookEntity.setPublisher("Ramana"); bookEntity.setIsbn(3179098456l);
		 * bookEntity.setPrice(900); LocalDate pDate = LocalDate.parse("2015-01-25");
		 * bookEntity.setPublishedYear(pDate);
		 * 
		 * int inBook = iBookService.insertBook(bookEntity);
		 * System.out.println("The book is saved to Database " + inBook);
		 */

		// 2 :- get Book By Id :---------
		/*
		 * Optional<BookEntity> res = iBookService.getBookDetails(1); if (res.isEmpty())
		 * { System.out.println("Record doesn't exist"); } else { BookEntity out =
		 * res.get(); System.out.println(out.getBookId() + " " + out.getTitle() + " " +
		 * out.getAuthorName() + " " + out.getPublisher() + " " + out.getPrice() + " " +
		 * out.getPublishedYear() + " " + out.getIsbn()); }
		 */

		// 3 :- 1 st way
		/*
		 * List<BookEntity> res = iBookService.getBookByAuthorName("Bhaskar"); if
		 * (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 3 :- 2 nd Way
		/*
		 * List<BookEntity> res = iBookService.getBookByAuthorNameSecond("Chand Basha");
		 * if (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 3 :- 3 rd Way
		/*
		 * List<BookEntity> res = iBookService.getBookByAuthorNameThird("Fazil"); if
		 * (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 4 :- 1 st Way
		/*
		 * List<BookEntity> res = iBookService.getBookGreaterThanEqualToPrice(500); if
		 * (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 4 :- 2 nd Way
		/*
		 * List<BookEntity> res =
		 * iBookService.getBookGreaterThanEqualToPriceSecond(800); if (res.isEmpty()) {
		 * System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 4 :- 3 rd Way
		/*
		 * List<BookEntity> res =
		 * iBookService.getBookGreaterThanEqualToPriceThird(1000); if (res.isEmpty()) {
		 * System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 5 :- 1 st Way
		/*
		 * List<BookEntity> res = iBookService.getBookLessThanPrice(600); if
		 * (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 5 :- 2 nd Way
		/*
		 * List<BookEntity> res = iBookService.getBookLessThanPriceSecond(800); if
		 * (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 5 :- 3 rd Way
		/*
		 * List<BookEntity> res = iBookService.getBookLessThanPriceThird(1000); if
		 * (res.isEmpty()) { System.out.println("Records Not found"); } else {
		 * System.out.println("Data Exist :- "); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 6 :- 1 st Way
		/*
		 * LocalDate stDate = LocalDate.parse("2003-07-05"); LocalDate endDate =
		 * LocalDate.parse("2006-07-05"); List<BookEntity> res =
		 * iBookService.bookPublishedBetweenYear(stDate, endDate); if (res.isEmpty()) {
		 * System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data Exist"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 6 :- 2 nd Way
		/*
		 * LocalDate stDate = LocalDate.parse("2000-07-05"); LocalDate endDate =
		 * LocalDate.parse("2003-07-05"); List<BookEntity> res =
		 * iBookService.bookPublishedBetweenYearSecond(stDate, endDate); if
		 * (res.isEmpty()) { System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data Exist"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 6 :- 3 rd Way
		/*
		 * LocalDate stDate = LocalDate.parse("1998-07-05"); LocalDate endDate =
		 * LocalDate.parse("2000-07-05"); List<BookEntity> res =
		 * iBookService.bookPublishedBetweenYearThird(stDate, endDate); if
		 * (res.isEmpty()) { System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data Exist"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 7 :- 1 st Way
		/*
		 * LocalDate stDate = LocalDate.parse("2000-07-05"); List<BookEntity> res =
		 * iBookService.bookPublishedAfterYear(stDate); if (res.isEmpty()) {
		 * System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data Exist"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 7 :- 2 nd Way
		/*
		 * LocalDate stDate = LocalDate.parse("2010-12-05"); List<BookEntity> res =
		 * iBookService.bookPublishedAfterYearSecond(stDate); if (res.isEmpty()) {
		 * System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data Exist"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 7 :- 3 rd Way
		/*
		 * LocalDate stDate = LocalDate.parse("2011-12-05"); List<BookEntity> res =
		 * iBookService.bookPublishedAfterYearThird(stDate); if (res.isEmpty()) {
		 * System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data Exist"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 8 :- 1 st Way :--
		/*
		 * List<BookEntity> res = iBookService.getBookByAuthorNameAndPublisher("Fazil",
		 * "Ramu"); if (res.isEmpty()) { System.out.println("Data doesn't exist"); }
		 * else { System.out.println("Data exist :-----"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 8 :- 2 nd Way :-----
		/*
		 * List<BookEntity> res =
		 * iBookService.getBookByAuthorNameAndPublisherSecond("Bhaskar", "Yendamuri");
		 * if (res.isEmpty()) { System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data exist :-----"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 8 :- 3 rd Way :-----
		/*
		 * List<BookEntity> res =
		 * iBookService.getBookByAuthorNameAndPublisherThird("Fazil", "Ramu"); if
		 * (res.isEmpty()) { System.out.println("Data doesn't exist"); } else {
		 * System.out.println("Data exist :-----"); for (BookEntity book : res) {
		 * System.out.println(book.getBookId() + " " + book.getTitle() + " " +
		 * book.getAuthorName() + " " + book.getPublisher() + " " + book.getPrice() +
		 * " " + book.getPublishedYear() + " " + book.getIsbn()); } }
		 */

		// 9 :- Delete Book By Id
		iBookService.DeleteBook(3);

		// 10 :- Update Book Price By Based On Id
		// iBookService.updateBookPrice(3, 10000);
	}

}
