package com.cg.ovms.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.ovms.entities.Payment;



@Repository
public interface PaymentRepository  extends JpaRepository<Payment, Integer>{

	
	
	
	
	List<Payment> findByBookingIdEquals(int bookingId);



	List<Payment> findByVehicleIdEquals(int vehicleId);

	
	
	
}
