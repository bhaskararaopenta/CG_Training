package com.cg.hbm.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertFalse;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.mockito.ArgumentMatchers.any;

import static org.mockito.Mockito.times;

import static org.mockito.Mockito.verify;

import static org.mockito.Mockito.when;

import java.time.LocalDate;

import java.time.format.DateTimeFormatter;

import java.util.List;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;

import org.mockito.Mock;

import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.hbm.entites.BookingDetails;

import com.cg.hbm.exceptions.BookingDetailsNotFoundException;

import com.cg.hbm.repository.IBookingDetailsRepository;

import com.cg.hbm.service.IBookingDetailsServiceImpl;

@ExtendWith(MockitoExtension.class)  // Automatically initializes mocks and injects dependencies

public class BookingTest {



	@Mock

	private IBookingDetailsRepository bookingRepository;

	@InjectMocks

	private IBookingDetailsServiceImpl bookingDetailsService;

	private BookingDetails mockBooking;

	@BeforeEach

	public void setUp() {

		mockBooking = new BookingDetails();

		mockBooking.setBookingId(1);

		mockBooking.setRoomId(101);

		mockBooking.setUserId(1001);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		LocalDate bf = LocalDate.parse("2024-11-20", formatter);

		LocalDate bt = LocalDate.parse("2024-11-25", formatter);

		mockBooking.setBookedFrom(bf);

		mockBooking.setBookedTo(bt);

		mockBooking.setNoOfAdults(2);

		mockBooking.setNoOfChildren(1);

		mockBooking.setAmount(5000.00);

	}

	@Test

	public void testAddBookingDetails() throws BookingDetailsNotFoundException  {

		// Arrange

		when(bookingRepository.save(any(BookingDetails.class))).thenReturn(mockBooking);

		// Act

		BookingDetails result = bookingDetailsService.addBookingDetails(mockBooking);

		// Assert

		assertNotNull(result);

		assertEquals(mockBooking.getBookingId(), result.getBookingId());

		verify(bookingRepository, times(1)).save(mockBooking);

	}

	@Test

	public void testUpdateBookingDetails() throws BookingDetailsNotFoundException {

		// Arrange

		when(bookingRepository.findById(1)).thenReturn(Optional.of(mockBooking));

		when(bookingRepository.save(any(BookingDetails.class))).thenReturn(mockBooking);

		// Act

		BookingDetails updatedBooking = bookingDetailsService.updateBookingDetails(mockBooking);

		// Assert

		assertNotNull(updatedBooking);

		assertEquals(mockBooking.getBookingId(), updatedBooking.getBookingId());

		verify(bookingRepository, times(1)).save(mockBooking);

	}

	@Test

	public void testUpdateBookingDetails_NotFound() {

		// Arrange

		when(bookingRepository.findById(1)).thenReturn(Optional.empty());

		// Act & Assert

		assertThrows(BookingDetailsNotFoundException.class, () -> {

			bookingDetailsService.updateBookingDetails(mockBooking);

		});

	}

	@Test

	public void testRemoveBookingDetails() throws BookingDetailsNotFoundException {

		// Arrange

		when(bookingRepository.findById(1)).thenReturn(Optional.of(mockBooking));

		// Act

		BookingDetails removedBooking = bookingDetailsService.removeBookingDetails(mockBooking);

		// Assert

		assertNotNull(removedBooking);

		assertEquals(mockBooking.getBookingId(), removedBooking.getBookingId());

		verify(bookingRepository, times(1)).delete(mockBooking);

	}

	@Test

	public void testRemoveBookingDetails_NotFound() {

		// Arrange

		when(bookingRepository.findById(1)).thenReturn(Optional.empty());

		// Act & Assert

		assertThrows(BookingDetailsNotFoundException.class, () -> {

			bookingDetailsService.removeBookingDetails(mockBooking);

		});

	}

	@Test

	public void testShowBookingDetails() throws BookingDetailsNotFoundException {

		// Arrange

		when(bookingRepository.findById(1)).thenReturn(Optional.of(mockBooking));

		// Act

		BookingDetails foundBooking = bookingDetailsService.showBookingDetails(mockBooking);

		// Assert

		assertNotNull(foundBooking);

		assertEquals(mockBooking.getBookingId(), foundBooking.getBookingId());

	}

	@Test

	public void testShowBookingDetails_NotFound() {

		// Arrange

		when(bookingRepository.findById(1)).thenReturn(Optional.empty());

		// Act & Assert

		assertThrows(BookingDetailsNotFoundException.class, () -> {

			bookingDetailsService.showBookingDetails(mockBooking);

		});

	}

	@Test

	public void testShowAllBookingDetails() {

		// Arrange

		when(bookingRepository.findAll()).thenReturn(List.of(mockBooking));

		// Act

		List<BookingDetails> allBookings = bookingDetailsService.showAllBookingDetails();

		// Assert

		assertNotNull(allBookings);

		assertFalse(allBookings.isEmpty());

		assertEquals(1, allBookings.size());

		verify(bookingRepository, times(1)).findAll();

	}

}

