package com.cg.bean;

import org.springframework.stereotype.Component;

@Component("impl1")
public class MyTestImpl implements MyTest {

	@Override
	public String getMessage(String msg) {
		// TODO Auto-generated method stub
		return "Hii " + msg;
	}

}
