import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		GadgetValidatorUtil gvu=new GadgetValidatorUtil();
		System.out.println("Enter the number of gadget entries");
		int input = sc.nextInt();
		sc.nextLine();
		for (int i = 1; i <= input; i++) {
			System.out.println("Enter gadget " + i + "details");
			String data = sc.nextLine();
			String[] res = data.split(":");
			String id = res[0];
			String item = res[1];
			int period = Integer.parseInt(res[2]);
			
			try {
				boolean res1 = gvu.validateGadgetID(id);
				boolean res2 = gvu.validateWarrantyPeriod(period);
				if (res1 && res2 ) {
					System.out.println("Warranty accepted,stock updated");
				}
			} catch (InvalidGadgetException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
			
		}
	}
}
