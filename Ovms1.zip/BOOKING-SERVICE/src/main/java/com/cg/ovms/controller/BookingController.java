package com.cg.ovms.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.cg.ovms.entities.Booking;
import com.cg.ovms.service.IBookingService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/bookings")
@Validated
public class BookingController {

    @Autowired
    private IBookingService bookingService;

    @PostMapping("/add")
    public ResponseEntity<Booking> addBooking(@Valid @RequestBody Booking booking) {
        Booking newBooking = bookingService.addBooking(booking);
        return ResponseEntity.ok(newBooking);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<Booking> cancelBooking(@Valid @RequestBody Booking booking) {
        Booking cancelledBooking = bookingService.cancelBooking(booking);
        return ResponseEntity.ok(cancelledBooking);
    }

    @PutMapping("/update")
    public ResponseEntity<Booking> updateBooking(@Valid @RequestBody Booking booking) {
        Booking updatedBooking = bookingService.updateBooking(booking);
        return ResponseEntity.ok(updatedBooking);
    }

    @GetMapping("/byId/{id}")
    public ResponseEntity<Booking> viewBooking(@Valid @PathVariable int id) {
         Booking booking = bookingService.viewById(id);
        return ResponseEntity.ok(booking);
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Booking>> viewAllBooking(@Valid @PathVariable int customerId) {
        List<Booking> bookings = bookingService.viewAllBooking(customerId);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/date/{bookingDate}")
    public ResponseEntity<List<Booking>> viewAllBookingByDate(@Valid @PathVariable LocalDate bookingDate) {
        List<Booking> bookings = bookingService.viewAllBookingByDate(bookingDate);
        return ResponseEntity.ok(bookings);
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<List<Booking>> viewAllBookingByVehicle(@Valid @PathVariable int vehicleId) {
        List<Booking> bookings = bookingService.viewAllBookingByVehicle(vehicleId);
        return ResponseEntity.ok(bookings);
    }
}