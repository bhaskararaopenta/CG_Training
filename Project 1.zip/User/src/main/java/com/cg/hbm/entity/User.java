package com.cg.hbm.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name="tab")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int user_id; // Unique identifier for the user

    @Column(unique = true)
    @Pattern(regexp = "^[a-zA-Z0-9_-]{3,15}$", message = "Username must be valid")
    private String user_name; // Username with specific pattern validation

    @Column(unique = true)
    @Email(message = "Email must be valid")
    private String email; // Email with validation for proper email format

    @Column(unique = true)
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$&*])[A-Za-z\\d@#$&*]{8,}$", message = "Password must be valid")
    private String password; // Password with specific pattern validation

    private String role; // Role of the user (e.g., admin, user)

    @NotNull
    @Pattern(regexp = "[0-9]{10}$", message = "Mobile number must be exactly 10 digits long")
    private String mobile; // Mobile number with validation for 10 digits

    private String address; // Address of the user
}