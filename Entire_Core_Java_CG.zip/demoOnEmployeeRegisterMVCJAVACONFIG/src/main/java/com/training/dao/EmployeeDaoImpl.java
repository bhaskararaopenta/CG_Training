package com.training.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.training.bean.EmployeeDTO;
import com.training.entity.Employee;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao{
	
	@Autowired
	private HibernateTemplate ht;

	@Override
	public int saveEmployee(EmployeeDTO edto) {
		// TODO Auto-generated method stub
		//here convert the EMployeeDto to Employee (entity)
		Employee e= new Employee();
		e.setEmpId(edto.getEmpId());
		e.setEmpName(edto.getEmpName());
		e.setEmpPwd(edto.getEmpPwd());
		e.setEmpGen(edto.getEmpGen());
		e.setEmpAddr(edto.getEmpAddr());
		e.setEmpCountry(edto.getEmpCountry());
		
		ht.save(e);
		
		return Integer.parseInt(e.getEmpId());
	}

}
