
module core_java {
}