package com.day6.AssignmentOnException;

public class InfyBankException extends Exception {

	public InfyBankException(String s) {
		super(s);
	}

}
