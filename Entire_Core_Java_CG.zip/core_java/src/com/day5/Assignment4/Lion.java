package com.day5.Assignment4;

public class Lion extends Animal {

	@Override
	public String eat() {
		return "Lion eats Raw meat when they hunt";
	}

	@Override
	public String sleep() {
		return "Lion sleep 8 hrs a day";
	}

}
