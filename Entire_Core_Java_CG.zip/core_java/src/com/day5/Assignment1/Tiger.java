package com.day5.Assignment1;

public class Tiger extends Animal{

	@Override
	public String sound() {
		
		return " ROARRRRRRRRR";
	}

}
