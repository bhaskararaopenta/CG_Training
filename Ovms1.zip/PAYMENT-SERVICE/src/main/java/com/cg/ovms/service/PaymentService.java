package com.cg.ovms.service;


import java.util.List;

import org.springframework.web.bind.MethodArgumentNotValidException;

import com.cg.ovms.entities.Payment;
import com.cg.ovms.exception.ResourceNotFoundException;




public interface PaymentService {

	Payment addPayment(Payment payment);
    Payment cancelPayment(Payment p) throws ResourceNotFoundException;
    
    
    List<Payment> viewByVehicleIdEquals(int vehicleId);
   
    
    List<Payment> viewByBookingIdEquals(int bookingId);
}
