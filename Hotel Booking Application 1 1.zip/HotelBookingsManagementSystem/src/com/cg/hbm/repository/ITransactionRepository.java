package com.cg.hbm.repository;

import com.cg.hbm.entites.Transactions;

public interface ITransactionRepository {
	public Transactions addTransaction(Transactions transaction);
}
