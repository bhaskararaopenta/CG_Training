package com.cg;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Student;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		Student st = new Student();
		st.setStdId(1001);
		st.setStdName("Ram");

//		st.getStdData().add("D1");
//		st.getStdData().add("D2");

		List<String> li = new ArrayList<String>();
		li.add("java");
		li.add("python");

		st.setStdData(li);

		 ses.persist(st);
		tx.commit();
		ses.close();
	}
}
