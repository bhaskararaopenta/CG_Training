package com.cg.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.bean.Employee;

@Configuration
public class SpringConfig {

	@Bean
	public Employee getEmpObject() {
		Employee emp = new Employee(100, "bhaskar", 154);
		return emp;
	}
}
