package com.cg.hbm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = HotelModuleApplication.class)
class HotelModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
