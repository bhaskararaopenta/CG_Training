package com.cg.ovms.dto;

import java.util.List;

import com.cg.ovms.customer.entity.Customer;
import com.cg.ovms.entities.Booking;
import com.cg.ovms.entities.Driver;
import com.cg.ovms.entities.Payment;
import com.cg.ovms.entites.Vehicle;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ResponseDto {

	private Driver driver;
	
	private Booking booking;
	
	private List<Payment> payment;
	
	private Customer customer;
	
	private Vehicle vehicle;

}
