package com.day20.threads;

import java.util.Random;

public class ExampleOnGenerateRandom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random rd = new Random();
		int num = rd.nextInt(1000); // -- 0 to 9999 it will generate random

		System.out.println(num);
		System.out.println(rd.nextInt());

		System.out.println(Math.sqrt(25)); // 5
		System.out.println("Random number is Math class :" + Math.random());

		System.out.println("ceil value is :" + Math.ceil(4.67)); //5.0
		System.out.println("floor value is :" + Math.floor(4.67)); //4.0
		System.out.println("round value is :" + Math.round(4.01)); //4
		System.out.println("round value is :" + Math.round(4.67)); //5

	}

}
