package com.cg.hbm.exceptions;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cg.hbm.exceptions.BookingDetailsNotFoundException;
import com.cg.hbm.exceptions.ErrorInfo;
import com.cg.hbm.exceptions.RoomDetailsNotFoundException;

@ControllerAdvice 
public class ExceptionControllerAdvice {
	@Autowired
	private Environment environment;
	
	  // Handle validation exceptions (e.g., @Valid not satisfied)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorInfo> cascadeExceptionHandler(MethodArgumentNotValidException exception) {
		ErrorInfo error = new ErrorInfo();
	
		error.setTimestamp(LocalDateTime.now());
		error.setErrorCode(HttpStatus.BAD_REQUEST.value());
		
		String msg = exception.getBindingResult().getAllErrors().stream().map(x->x.getDefaultMessage())
				.collect(Collectors.joining(","));
		
		error.setErrorMessage(msg);
		
		return new ResponseEntity<ErrorInfo>(error, HttpStatus.BAD_REQUEST);
	}
    
   

    // General fallback for other exceptions
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Map<String, String>> handleException(Exception ex) {
        Map<String, String> error = new HashMap<>();
        error.put("message", "An unexpected error occurred: " + ex.getMessage());
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
    @ExceptionHandler(BookingDetailsNotFoundException.class)
	public ResponseEntity<ErrorInfo> roomdetailsNotFoundExceptionHandler(RoomDetailsNotFoundException exception) {
		ErrorInfo error = new ErrorInfo();
		error.setErrorMessage(environment.getProperty(exception.getMessage()));
		error.setTimestamp(LocalDateTime.now());
		error.setErrorCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

}
