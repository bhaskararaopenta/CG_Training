package com.cg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/emp")
public class EmployeeController {

	@RequestMapping("/show") // http://localhost:8000/myapp/emp/show
	public String showPage() {
		return "home";
	}

	@RequestMapping("/test") // http://localhost:8000/myapp/emp/test?n=welcome to springWEBMVC
	public ModelAndView showPage2(@RequestParam("n") String n) {

		ModelAndView mav = new ModelAndView();

		mav.setViewName("success");
		mav.addObject("msg", n);
		return mav;
	}

	@RequestMapping("/test2/{n}") // http://localhost:8000/myapp/emp/test2/welcome to pathVariablePage
	public ModelAndView showPage3(@PathVariable("n") String n) {

		ModelAndView mav = new ModelAndView();

		mav.setViewName("pathVariableSuccessPage");
		mav.addObject("msg", n);
		return mav;
	}
}
