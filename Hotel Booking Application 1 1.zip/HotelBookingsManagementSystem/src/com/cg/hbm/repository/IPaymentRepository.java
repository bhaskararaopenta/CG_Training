package com.cg.hbm.repository;

import com.cg.hbm.entites.Payments;

public interface IPaymentRepository {
	public Payments addPayment(Payments payment);
}
