package com.cg.hbm.dto;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entity.Payments;
import com.cg.hbm.entity.Transactions;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ResponseDTO {

    // Payment details
    private Payments payment;

    // Booking details
    private BookingDetails bookingDetails;

    // Transaction details
    private Transactions transactions;
}