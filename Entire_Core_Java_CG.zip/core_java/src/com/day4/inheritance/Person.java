package com.day4.inheritance;


// this example referes to hierarchy
public class Person {

	String name="smith";
	public void display() {
		System.out.println("name is "+name);
	}
}
