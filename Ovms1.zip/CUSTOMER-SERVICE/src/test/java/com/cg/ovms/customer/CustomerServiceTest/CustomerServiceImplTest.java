package com.cg.ovms.customer.CustomerServiceTest;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.ovms.customer.entity.Customer;
import com.cg.ovms.customer.repository.CustomerRepository;
import com.cg.ovms.customer.service.CustomerServiceImpl;



class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerServiceImpl customerService;

    private Customer customer;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        customer = new Customer();
    }

    @Test
    public void testGetCustomerById() {
        // Mock repository method to return a customer when findById is called
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));

        // Call service method
        Customer foundCustomer = customerService.viewCustomer(1);

        // Verify result
        assertNotNull(foundCustomer);
        assertEquals(1, foundCustomer.getCustomerld());
        assertEquals("John", foundCustomer.getFirstName());
        assertEquals("Doe", foundCustomer.getLastName());
    }

    @Test
    public void testCreateCustomer() {
        // Mock repository method to save and return the same customer
        when(customerRepository.save(customer)).thenReturn(customer);

        // Call service method
        Customer createdCustomer = customerService.addCustomer(customer);

        // Verify result
        assertNotNull(createdCustomer);
        assertEquals("John", createdCustomer.getFirstName());
        assertEquals("Doe", createdCustomer.getLastName());
    }

    @Test
    public void testUpdateCustomer() {
        // Mock repository methods
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        when(customerRepository.save(customer)).thenReturn(customer);

        // Prepare updated customer
        customer.setFirstName("Jane");
        customer.setLastName("Smith");

        // Call service method
        Customer updatedCustomer = customerService.updateCustomer(customer);

        // Verify result
        assertNotNull(updatedCustomer);
        assertEquals("Jane", updatedCustomer.getFirstName());
        assertEquals("Smith", updatedCustomer.getLastName());
    }

    @Test
    public void testDeleteCustomer() {
        // Mock repository methods
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        doNothing().when(customerRepository).delete(customer);

        // Call service method
        customerService.viewCustomer(1);

        // Verify interaction with repository
        verify(customerRepository, times(1)).delete(customer);
    }
}
