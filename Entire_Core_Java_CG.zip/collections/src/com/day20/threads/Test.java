package com.day20.threads;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExampleOnThreadDemo etd = new ExampleOnThreadDemo();
		Thread t = new Thread(etd);
		
		t.start(); //internally it will execute run method()
		
		System.out.println("Default thread name :"+t.getName());
		t.setName("CG");  //changing the thread name default thread name - Thread-0....
		System.out.println("custom thread priority :"+t.getPriority());
		
		Thread t2 = new Thread(etd);
		t2.start(); //internally it will execute run method()
		System.out.println("Thread name :"+t2.getName());  //Thread-1
		for (int i = 0; i < 5; i++) {
			System.out.println("Main thread or parent Thread");
		}
	}

}
