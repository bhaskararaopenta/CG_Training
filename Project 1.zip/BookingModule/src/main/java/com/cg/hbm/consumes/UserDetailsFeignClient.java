package com.cg.hbm.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.hbm.entity.User;

//Feign client for User service
@FeignClient(name = "User")
public interface UserDetailsFeignClient {
	
	// Get user details by ID
	 @GetMapping("users/{userId}")
	    User getUserById(@PathVariable("userId") int userId );

}
