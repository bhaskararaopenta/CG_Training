package com.cg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import com.cg.entity.BookEntity;

public interface IBookService {

	public int addBook(BookEntity b);

	public Optional<BookEntity> getBookDetails(int id);

	public List<BookEntity> getBookByAuthorName(String authorName);

	public List<BookEntity> getBookByAuthorNameSecond(String authorName);

	public List<BookEntity> getBookByAuthorNameThird(String authorName);

	public List<BookEntity> getBookGreaterThanEqualToPrice(Integer price);

	public List<BookEntity> getBookGreaterThanEqualToPriceSecond(Integer price);

	public List<BookEntity> getBookGreaterThanEqualToPriceThird(Integer price);

	public List<BookEntity> getBookLessThanPrice(Integer price);

	public List<BookEntity> getBookLessThanPriceSecond(Integer price);

	public List<BookEntity> getBookLessThanPriceThird(Integer price);

	public List<BookEntity> bookPublishedBetweenYear(LocalDate startDate, LocalDate endDate);

	public List<BookEntity> bookPublishedBetweenYearSecond(LocalDate startDate, LocalDate endDate);

	public List<BookEntity> bookPublishedBetweenYearThird(LocalDate startDate, LocalDate endDate);

	public List<BookEntity> bookPublishedAfterYear(LocalDate date);

	public List<BookEntity> bookPublishedAfterYearSecond(LocalDate date);

	public List<BookEntity> bookPublishedAfterYearThird(LocalDate date);

	public List<BookEntity> getBookByAuthorNameAndPublisher(String author, String publisher);

	public List<BookEntity> getBookByAuthorNameAndPublisherSecond(String authorName, String publisher);

	public List<BookEntity> getBookByAuthorNameAndPublisherThird(String authorName, String publisher);

	public void DeleteBook(int id);

	public void updateBookPrice(Integer bookId, Integer price);
}
