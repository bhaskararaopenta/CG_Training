package com.cg.hbm.test;
 
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
 
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
 
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.exceptions.HotelNotFoundException;
import com.cg.hbm.repository.IHotelRepository;
import com.cg.hbm.service.IHotelServiceImpl;
 
public class HotelTest {
    // Mock the hotel repository
    @Mock
    private IHotelRepository hotelRepository;
 
    // Inject mocks into the hotel service implementation
    @InjectMocks
    private IHotelServiceImpl hotelService;
 
    private Hotel hotel;
 
    // Set up method to initialize mocks and test data
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        hotel = new Hotel();
        hotel.setHotelId(1);
        hotel.setHotelName("Test Hotel");
    }
 
    // Test for adding a hotel
    @Test
    public void testAddHotel() {
        when(hotelRepository.save(hotel)).thenReturn(hotel);
        Hotel addedHotel = hotelService.addHotel(hotel);
        assertEquals(hotel, addedHotel);
    }
 
    // Test for updating a hotel
    @Test
    public void testUpdateHotel() {
        when(hotelRepository.existsById(hotel.getHotelId())).thenReturn(true);
        when(hotelRepository.save(hotel)).thenReturn(hotel);
        Hotel updatedHotel = hotelService.updateHotel(hotel);
        assertEquals(hotel, updatedHotel);
    }
 
    // Test for updating a hotel that does not exist
    @Test
    public void testUpdateHotel_NotFound() {
        when(hotelRepository.existsById(hotel.getHotelId())).thenReturn(false);
        assertThrows(HotelNotFoundException.class, () -> {
            hotelService.updateHotel(hotel);
        });
    }
 
    // Test for removing a hotel
    @Test
    public void testRemoveHotel() {
        when(hotelRepository.existsById(hotel.getHotelId())).thenReturn(true);
        doNothing().when(hotelRepository).delete(hotel);
        Hotel removedHotel = hotelService.removeHotel(hotel);
        assertEquals(hotel, removedHotel);
    }
 
    // Test for removing a hotel that does not exist
    @Test
    public void testRemoveHotel_NotFound() {
        when(hotelRepository.existsById(hotel.getHotelId())).thenReturn(false);
        assertThrows(HotelNotFoundException.class, () -> {
            hotelService.removeHotel(hotel);
        });
    }
 
    // Test for showing all hotels
    @Test
    public void testShowAllHotels() {
        List<Hotel> hotels = Arrays.asList(hotel);
        when(hotelRepository.findAll()).thenReturn(hotels);
        List<Hotel> allHotels = hotelService.showAllHotels();
        assertEquals(hotels, allHotels);
    }
 
    // Test for showing a specific hotel by ID
    @Test
    public void testShowHotel() {
        when(hotelRepository.findById(hotel.getHotelId())).thenReturn(Optional.of(hotel));
        Hotel foundHotel = hotelService.showHotel(hotel.getHotelId());
        assertEquals(hotel, foundHotel);
    }
 
    // Test for showing a hotel that does not exist
    @Test
    public void testShowHotel_NotFound() {
        when(hotelRepository.findById(hotel.getHotelId())).thenReturn(Optional.empty());
        assertThrows(HotelNotFoundException.class, () -> {
            hotelService.showHotel(hotel.getHotelId());
        });
    }
}