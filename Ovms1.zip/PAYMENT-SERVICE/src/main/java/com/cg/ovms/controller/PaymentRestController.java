package com.cg.ovms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.entities.Payment;
import com.cg.ovms.exception.ErrorInfo;
import com.cg.ovms.exception.ResourceNotFoundException;
import com.cg.ovms.service.PaymentService;

import jakarta.validation.Valid;





@RestController
@RequestMapping("/payments")
@Validated
public class PaymentRestController {

	

	    @Autowired
	    private PaymentService paymentService;

	    @PostMapping("/payments")
	    public ResponseEntity<Payment> addPayment(@Valid @RequestBody Payment payment) throws MethodArgumentNotValidException {
	        Payment addedPayment = paymentService.addPayment(payment);
	        return new ResponseEntity<>(addedPayment, HttpStatus.CREATED);
	    }

	    @PostMapping("/payments/cancel")
	    public ResponseEntity<Payment> cancelPayment(@Valid @RequestBody Payment payment) throws ResourceNotFoundException {
	        Payment canceledPayment = paymentService.cancelPayment(payment);
	        return new ResponseEntity<>(canceledPayment, HttpStatus.OK);
	    }

	    @GetMapping("/payments/vehicle")
	    public ResponseEntity<List<Payment>> viewPaymentsByVehicle(@RequestParam int vehicleId) {
	        List<Payment> payments = paymentService.viewByVehicleIdEquals(vehicleId);
	        return new ResponseEntity<>(payments, HttpStatus.OK);
	    }

	    @GetMapping("/payments/booking")
	    public ResponseEntity<List<Payment>> viewPaymentsByBooking(@RequestParam int bookingId) {
	        List<Payment> payments = paymentService.viewByBookingIdEquals(bookingId);
	        return new ResponseEntity<>(payments, HttpStatus.OK);
	    }

	}

