package com.day6.testOnException;

public class NameException extends Exception {

	public NameException(String s) {
		super(s);
	}

}
