package com.day20.threads;

public class ExampleOnThreadSecondWay extends Thread {
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println("child thread");

		}
	}

	public static void main(String[] args) {
		ExampleOnThreadSecondWay eotsw = new ExampleOnThreadSecondWay();
		eotsw.start();// internally called which method run method
		
		ExampleOnThreadSecondWay eotsw1 = new ExampleOnThreadSecondWay();
		eotsw1.start();// internally called which method run method
		for (int i = 0; i < 5; i++) {
			System.out.println("main thread");
		}
	}

}
