package com.training.service;

import com.training.dto.UserDepartment;
import com.training.entity.User;

public interface UserService {
    User saveUser(User user);
    UserDepartment getUser(Long userId);
}