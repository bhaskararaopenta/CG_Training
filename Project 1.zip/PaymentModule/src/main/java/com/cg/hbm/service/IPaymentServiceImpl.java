package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.consumes.PaymentFeignClient;
import com.cg.hbm.entity.Payments;
import com.cg.hbm.entity.Transactions;
import com.cg.hbm.exceptions.PaymentsNotFoundException;
import com.cg.hbm.repository.IPaymentRepository;

@Service
public class IPaymentServiceImpl implements IPaymentService{

    @Autowired
    private IPaymentRepository iPaymentRepository;

    @Override
    public List<Payments> showAllPayments() throws PaymentsNotFoundException {
        // Fetch all payments from the repository
        return iPaymentRepository.findAll();
    }

    @Override
    public Payments addPayment(Payments payment) throws PaymentsNotFoundException {
        // Save the payment to the repository
        return iPaymentRepository.save(payment);
    }

    @Override
    public Payments showPayment(int paymentId) throws PaymentsNotFoundException {
        // Find the payment by ID, throw exception if not found
        Optional<Payments> opt = iPaymentRepository.findById(paymentId);
        Payments payment = opt.orElseThrow(() -> new PaymentsNotFoundException("paymentId not found"));
        
        return payment;
    }
}