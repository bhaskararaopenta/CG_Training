package com.cg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.model.Product;

public class ProductMainUpdate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure();
		// replacing <mapping class="com.cg.model.Product" /> from hibernate.cfg.xml this with below code
		cfg.addAnnotatedClass(com.cg.model.Product.class);
		
		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();

		Product pro = new Product();
		
		pro.setPid(1234);
		pro.setPname("Keyboard");
		pro.setPrice(5000);
		
		ses.merge(pro); 
		tr.commit();

		ses.close();

	}

}
