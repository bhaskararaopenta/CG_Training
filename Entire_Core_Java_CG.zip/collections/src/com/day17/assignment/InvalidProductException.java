package com.day17.assignment;

public class InvalidProductException extends Exception {

	public InvalidProductException(String s) {
		super(s);
	}

}
