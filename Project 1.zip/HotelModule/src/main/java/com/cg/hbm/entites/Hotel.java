package com.cg.hbm.entites;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Entity
@Table(name = "hotels")
@Data // Lombok annotation to generate getters, setters, equals, and other methods
public class Hotel {

   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int hotelId;

    
    @NotBlank(message = "City is required")
    @Size(max = 100, message = "City name can't exceed 100 characters")
    private String city;

    
    @NotBlank(message = "Hotel name is required")
    @Size(max = 200, message = "Hotel name can't exceed 200 characters")
    private String hotelName;

   
    @NotBlank(message = "Address is required")
    @Size(max = 255, message = "Address can't exceed 255 characters")
    private String address;

   
    @Size(max = 500, message = "Description can't exceed 500 characters")
    private String description;

   
    @NotNull(message = "Average rate per day is required")
    private double avgRatePerDay;

   
    @Email(message = "Invalid email format")
    @NotBlank(message = "Email is required")
    private String email;

    
    @NotBlank(message = "Primary phone is required")
    @Size(min = 10, max = 15, message = "Phone number must be between 10 to 15 characters")
    private String phone1;

   
    @Size(min = 10, max = 15, message = "Phone number must be between 10 to 15 characters")
    private String phone2;

   
    @NotBlank(message = "Website is required")
    @Size(max = 100, message = "Website URL can't exceed 100 characters")
    private String website;
    
 // Assuming Hotel is a POJO class that corresponds to the Hotel entity
}