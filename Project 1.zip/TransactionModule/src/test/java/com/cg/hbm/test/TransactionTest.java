package com.cg.hbm.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.hbm.entity.Transactions;
import com.cg.hbm.exceptions.TransactionsNotFoundException;
import com.cg.hbm.repository.ITransactionRepository;
import com.cg.hbm.service.ITransactionServiceImpl;

@ExtendWith(MockitoExtension.class)
public class TransactionTest {

    @InjectMocks
    private ITransactionServiceImpl transactionService;

    @Mock
    private ITransactionRepository transactionRepository;

    private Transactions transaction;

    @BeforeEach
    public void setUp() {
        transaction = new Transactions();
        transaction.setTransactionId(1);
        // Set other properties of transaction as needed
    }

    // Test for adding a transaction
    @Test
    public void testAddTransaction() {
        when(transactionRepository.save(transaction)).thenReturn(transaction);
        Transactions savedTransaction = transactionService.addTransaction(transaction);
        assertEquals(transaction, savedTransaction);
    }

    // Test for showing a specific transaction by ID
    @Test
    public void testShowTransaction() throws TransactionsNotFoundException {
        when(transactionRepository.findById(1)).thenReturn(Optional.of(transaction));
        Transactions foundTransaction = transactionService.showTransaction(1);
        assertEquals(transaction, foundTransaction);
    }

    // Test for handling transaction not found exception
    @Test
    public void testShowTransactionNotFound() {
        when(transactionRepository.findById(1)).thenReturn(Optional.empty());
        assertThrows(TransactionsNotFoundException.class, () -> {
            transactionService.showTransaction(1);
        });
    }

    // Test for showing all transactions
    @Test
    public void testShowAllTransactions() throws TransactionsNotFoundException {
        List<Transactions> transactionsList = Arrays.asList(transaction);
        when(transactionRepository.findAll()).thenReturn(transactionsList);
        List<Transactions> foundTransactions = transactionService.showAllTransactions();
        assertEquals(transactionsList, foundTransactions);
    }
}