package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ExampleOnDeleteUsingPrepareStatement {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);

		String query = " delete from product where id=?";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1, 1233);
		

		int res = ps.executeUpdate();
		if (res > 0) {
			System.out.println("Record deleted successfully");
		} else {
			System.out.println("Record not deleted");
		}
		
		ps.close();
		con.close();
	}

}
