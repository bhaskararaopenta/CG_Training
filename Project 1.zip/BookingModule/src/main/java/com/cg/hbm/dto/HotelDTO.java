package com.cg.hbm.dto;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class HotelDTO {
	
	private  BookingDetails bookingDetails;
	
	private Hotel hotel;
}
	


