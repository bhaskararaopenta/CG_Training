package com.cg.ovms.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.ovms.entities.Payment;

@FeignClient(name = "PAYMENT-SERVICE")
public interface PaymentClient {

	 @GetMapping("/payments/payments/vehicle")
	     List<Payment> viewPaymentsByVehicle(@RequestParam int vehicleId) ;



}
