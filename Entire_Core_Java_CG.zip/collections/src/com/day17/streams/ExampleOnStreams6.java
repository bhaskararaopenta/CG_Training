package com.day17.streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams6 {

	public static void main(String[] args) {

		List<String> al = new ArrayList();
		al.add("smith");
		al.add("rakesh");
		al.add("allen");
		al.add("banu");
		al.add("jack");

		System.out.println("no of elkements is list :" + al.size());
		System.out.println(al);

		// printing in ascending order

		System.out.println("ascending or alphabetical order");
		Stream<String> st = al.stream();
		st.sorted().forEach(e -> System.out.println(e));

		System.out.println("descending or alphabetical order");
		Stream<String> st1 = al.stream();
		st1.sorted((a, b) -> b.compareTo(a)).forEach(e -> System.out.println(e));
		
		System.out.println("descending or alphabetical order using extra comparator");
		Stream<String> st2 = al.stream();
		Comparator<String> cm= (x,y)->x.compareTo(y);
		st2.sorted(cm).forEach(e->System.out.println(e));
		

		/*
		 * System.out.println("descending or alphabetical order"); Stream<String> st1 =
		 * al.stream();
		 * st1.sorted(Comparator.comparing(String::valueof)).forEach(System::out.println
		 * );
		 */
	}

}
