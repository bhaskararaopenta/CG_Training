package com.day5.Assignment1;

public abstract class Animal {
	
	public abstract String sound();

}
