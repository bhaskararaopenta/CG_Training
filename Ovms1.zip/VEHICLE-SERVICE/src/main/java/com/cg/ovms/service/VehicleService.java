package com.cg.ovms.service;


import java.util.List;

import com.cg.ovms.entites.Vehicle;

public interface VehicleService {
    Vehicle addVehicle(Vehicle vehicle);
    Vehicle updateVehicle(Vehicle vehicle);
    void deleteVehicle(Integer vehicleId);
    Vehicle getVehicleById(Integer vehicleId);
    List<Vehicle> getAllVehicles();
}
