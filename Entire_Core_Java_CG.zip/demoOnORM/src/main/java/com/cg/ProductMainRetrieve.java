package com.cg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.model.Product;

public class ProductMainRetrieve {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration cfg = new Configuration();
		cfg.configure();
		// replacing <mapping class="com.cg.model.Product" /> from hibernate.cfg.xml this with below code
		cfg.addAnnotatedClass(com.cg.model.Product.class);

		SessionFactory sf = cfg.buildSessionFactory();
		Session ses = sf.openSession();
		Product pr2 = ses.get(Product.class, 1234);
		System.out.println(pr2.getPid() + " " + pr2.getPname() + " " + pr2.getPrice());
 
		ses.close();

	}

}
