package com.cg.ovms.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cg.ovms.entities.User;
import com.cg.ovms.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Service
public class UserServiceImp implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private HttpSession httpSession;

    @Override
    public User addUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    @Override
    public String loginUser(String userId, String password) throws Exception {
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if (passwordEncoder.matches(password, user.getPassword())) {
                if (user.getRole().equalsIgnoreCase("admin")) {
                    return "Redirecting to the Admin Service Module";
                } else if (user.getRole().equalsIgnoreCase("customer")) {
                    return "Redirecting to the Customer Service Module.";
                } else {
                    throw new Exception("Invalid role");
                }
            } else {
                throw new Exception("Invalid password");
            }
        } else {
            throw new Exception("User Not Found");
        }
    }

    @Override
    public String removeUser(String userId) {
        userRepository.deleteById(userId);
        return "Successfully deleted";
    }

    @Override
    public String signOut() {
        SecurityContextHolder.clearContext();
        httpSession.invalidate();
        return "You are Signed Out";
    }

    @Override
    public Optional<User> findByUserId(String userId) {
        return userRepository.findById(userId);
    }
}