package com.day20.threads;

public class WithdrawThread extends Thread {

	Bank b;
	int amount;

	public WithdrawThread(Bank b, int amount) {
		// TODO Auto-generated constructor stub
		this.b = b;
		this.amount = amount;
	}

	public void run() {
		b.withDrawal(amount);
	}
}
