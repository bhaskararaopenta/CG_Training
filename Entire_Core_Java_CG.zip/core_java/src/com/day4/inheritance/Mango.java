package com.day4.inheritance;

public class Mango extends Fruits {
	String taste;

	public void mangoDetails() {
		System.out.println(this.taste);

	}
}

