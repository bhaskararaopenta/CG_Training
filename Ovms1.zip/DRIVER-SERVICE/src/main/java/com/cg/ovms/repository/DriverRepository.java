package com.cg.ovms.repository;

import com.cg.ovms.entities.Driver;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DriverRepository extends JpaRepository<Driver, Integer> {
	
	

	Driver findByVehicleIdEquals(int vehicleId);
}
