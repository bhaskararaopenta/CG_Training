package com.day5.example3OnInterface;

public interface MyInt4 {
	public void m2();
	
	public abstract String sayHello(String m);
}
