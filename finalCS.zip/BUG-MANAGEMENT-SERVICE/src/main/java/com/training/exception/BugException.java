package com.training.exception;

public class BugException extends Exception
{
	private static final long serialVersionUID = 1L;

	public BugException (String message) {
		super(message);
	}
}
