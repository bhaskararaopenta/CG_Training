package com.cg.hbm.exceptions;

import java.time.LocalDateTime;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ErrorDetails {
    private String errorMessage;
    private Integer errorCode;
    private LocalDateTime timestamp;
    
}