package com.day5.test;

public interface AdvancedArithmetic {
	
	void divisorSum(int n);
}
