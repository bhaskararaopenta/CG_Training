package com.cg.hbm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = PaymentModuleApplication.class)
class PaymentModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
