package com.day5.Assignment4;

public class Deer extends Animal {

	@Override
	public String eat() {
		return "deer eats grass";
	}

	@Override
	public String sleep() {
		return "deer sleep 7 hrs a day";
	}

}
