import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EarphoneUtil {

	public Stream<Earphone> getEarphonesByBrandName(Stream<Earphone> earphoneStream, String brandName) {
		// Fill the code here
		Stream<Earphone> st = earphoneStream.filter(e -> e.getBrandName().equals(brandName));

		return st;
	}

	public List<Earphone> getEarphonesWithinPriceRange(Stream<Earphone> earphoneStream, double minimumPrice,
			double maximumPrice) {
		// Fill the code here

		 List<Earphone> res = earphoneStream.filter(e -> e.getPrice() >= minimumPrice && e.getPrice() <= maximumPrice).toList();
		

		return res;
	}
}
