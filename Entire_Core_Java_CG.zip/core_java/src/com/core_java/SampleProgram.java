package com.core_java;

public class SampleProgram {
	int a;
	float b;
	boolean c;
	char d;
	public static void main(String[] args) {
		SampleProgram t=new SampleProgram();
		t.a=10;
		// TODO Auto-generated method stub
		System.out.println("hello");
		System.out.println(t.a);
	}

}
