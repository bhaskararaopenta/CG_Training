package com.day15.lamdaExpression;

@FunctionalInterface
public interface MyTest {

	public String sayHello(String m);
}
