package com.day5.Assignment1;

public class Lion extends Animal {

	@Override
	public String sound() {

		return "roar";
	}

	

}
