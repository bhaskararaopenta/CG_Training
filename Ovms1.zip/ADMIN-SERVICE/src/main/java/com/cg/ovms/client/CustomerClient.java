package com.cg.ovms.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.ovms.customer.entity.Customer;

@FeignClient(name = "CUSTOMER-SERVICE")
public interface CustomerClient {

	@GetMapping("/customer/{customerId}")
    Customer getCustomerById(@PathVariable int customerId);
	
}
