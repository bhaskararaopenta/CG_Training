package com.training.consumes;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.training.dto.CustomerDTO;

@FeignClient(name = "CUSTOMER-SERVICE")
public interface BankCustomerRestApiConsumes {

	@GetMapping("/bank/customers") // http://locahost:8000/bank/customers
	List<CustomerDTO> getAllCustomers();

	@GetMapping("/bank/customers/{customerId}") // get specific record
	CustomerDTO getBankConusmesCustomerById(@PathVariable Integer customerId);

	@PostMapping("/bank/customers")
	String fromBankAddCustomer(@RequestBody CustomerDTO customerDTO);

	@DeleteMapping("/bank/customers/{customerId}") // get specific record
	String deletBankConusmesCustomerById(@PathVariable Integer customerId);

	@PutMapping("/bank/customers/{customerId}")
	String updateCustomerById(@PathVariable Integer customerId, @RequestBody CustomerDTO customer);

}
