package com.cg;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.bean.Employee;
import com.cg.config.SpringConfig;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		// this using xml configuration
		/*
		 * ApplicationContext context = new
		 * ClassPathXmlApplicationContext("applicationContext.xml"); Employee e =
		 * context.getBean("emp2", Employee.class);
		 * 
		 * System.out.println("employee details are"); System.out.println(e.getEmpId() +
		 * " " + e.getEmpName() + " " + e.getEmpSal());
		 */

		// now using java configuration ----------------
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		Employee e = context.getBean("getEmpObject", Employee.class);

		System.out.println("employee details are");
		System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getEmpSal());
	}
}
