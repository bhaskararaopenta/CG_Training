package com.day6.customException;

public class InvalidAgeException extends Exception {

	public InvalidAgeException(String s) {

		super(s);

	}

}
