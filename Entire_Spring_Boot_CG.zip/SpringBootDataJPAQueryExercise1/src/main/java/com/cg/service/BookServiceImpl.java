package com.cg.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dto.BookDTO;
import com.cg.entity.Book;
import com.cg.exception.CGBookException;
import com.cg.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepository bRepository;
	
	//this is userdefined method to convert Book object to BookDTO
	public BookDTO convertBookToBookDTO(Book b) {
		BookDTO dto = new BookDTO();
		dto.setBookId(b.getBookId());
		dto.setAuthorName(b.getAuthorName());
		dto.setPrice(b.getPrice());
		dto.setIsbn(b.getIsbn());
		dto.setPublishedYear(b.getPublishedYear());
		dto.setPublisher(b.getPublisher());
		dto.setTitle(b.getTitle());
		
		return dto;
	}
	
	//this is userdefined method to convert BookDTO object to Book
		public Book convertBookDTOtoBook(BookDTO dto) {
			Book b = new Book();
			b.setBookId(dto.getBookId());
			b.setAuthorName(dto.getAuthorName());
			b.setPrice(dto.getPrice());
			b.setIsbn(dto.getIsbn());
			b.setPublishedYear(dto.getPublishedYear());
			b.setPublisher(dto.getPublisher());
			b.setTitle(dto.getTitle());
			
			return b;
		}
	

	@Override
	public BookDTO getBookDetails(Integer bookId) throws CGBookException {
	    Optional<Book> optBk = bRepository.findById(bookId);
	    return convertBookToBookDTO(optBk.get());
	}

	@Override
	public void addBook(BookDTO bookDTO) throws CGBookException {
		// TODO Auto-generated method stub
		Book boj = convertBookDTOtoBook(bookDTO);
		bRepository.save(boj);
		
	}

	@Override
	public List<BookDTO> getBookByAuthorName(String authorName) throws CGBookException {
		List<Book>	lsbk =bRepository.getBookByAuthorName(authorName);
		//java8 code
		List<BookDTO> ls =lsbk.stream().map(bk -> convertBookToBookDTO(bk)).toList();
		
		/*
		 * List<BookDTO> ls = new ArrayList<>(); for(Book bk:lsbk) { BookDTO lsbto=
		 * convertBookToBookDTO(bk); ls.add(lsbto); }
		 */
		
		return ls;
	}

	@Override
	public List<BookDTO> getBookGreaterThanEqualToPrice(Integer price) throws CGBookException {
		List<Book>	lsbk =bRepository.getBookGreaterThanEqualToPrice(price);
		//java8 code
				List<BookDTO> ls =lsbk.stream().map(bk -> convertBookToBookDTO(bk)).toList();

				return ls;
	}

	@Override
	public List<BookDTO> getBookLessThanPrice(Integer price) throws CGBookException {
		List<Book>	lsbk =bRepository.getBookLessThanPrice(price);
		//java8 code
				List<BookDTO> ls =lsbk.stream().map(bk -> convertBookToBookDTO(bk)).toList();

				return ls;
	}

	@Override
	public List<BookDTO> bookPublishedBetweenYear(LocalDate startYear, LocalDate endYear) throws CGBookException {
		List<Book>	lsbk =bRepository.bookPublishedBetweenYear(startYear, endYear);
		//java8 code
				List<BookDTO> ls =lsbk.stream().map(bk -> convertBookToBookDTO(bk)).toList();

				return ls;
	}

	@Override
	public List<BookDTO> bookPublishedAfterYear(LocalDate year) throws CGBookException {
		List<Book>	lsbk =bRepository.bookPublishedAfterYear(year);
		//java8 code
				List<BookDTO> ls =lsbk.stream().map(bk -> convertBookToBookDTO(bk)).toList();

				return ls;

	}

	@Override
	public List<BookDTO> getBookByAuthorNameAndPublisher(String authorName, String publisher) throws CGBookException {
		List<Book>	lsbk =bRepository.getBookByAuthorNameAndPublisher(authorName, publisher);
		//java8 code
				List<BookDTO> ls =lsbk.stream().map(bk -> convertBookToBookDTO(bk)).toList();

				return ls;

	}

	@Override
	public void updateBookPrice(Integer bookId, Integer price) throws CGBookException {
		// TODO Auto-generated method stub
		Book bk =bRepository.findById(bookId).get();
        bk.setPrice(price);	
        bRepository.save(bk);
	}

	@Override
	public void deleteBook(Integer bookId) throws CGBookException {
		// TODO Auto-generated method stub
		Book bk =bRepository.findById(bookId).get();
		bRepository.delete(bk);
		
	}

	


	
}
