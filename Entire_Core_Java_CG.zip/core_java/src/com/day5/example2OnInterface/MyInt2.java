package com.day5.example2OnInterface;

public interface MyInt2 {
	 
	public abstract void m2();
	public int addition(int x,int y);
}
