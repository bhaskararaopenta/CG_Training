package com.training.repository;


import org.springframework.data.repository.CrudRepository;

import com.training.entity.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Integer> {

}
