package com.day7.stringsPrograms;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="earth";
		String s2="heart";
		
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		

	}

}
