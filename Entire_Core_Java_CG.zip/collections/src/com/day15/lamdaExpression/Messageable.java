package com.day15.lamdaExpression;

public interface Messageable {

	public abstract Message getMsg(String m);
}
