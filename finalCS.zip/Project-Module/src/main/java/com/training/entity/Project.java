package com.training.entity;

import java.util.List;

import com.training.dto.EmployeeForProject;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long projId;
	private String projName;
	@ElementCollection
	private List<EmployeeForProject> projManager;
	private String projStatus;

	public Long getProjId() {
		return projId;
	}

	public void setProjId(Long projId) {
		this.projId = projId;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public List<EmployeeForProject> getProjManager() {
		return projManager;
	}

	public void setProjManager(List<EmployeeForProject> projManager) {
		this.projManager = projManager;
	}

	public String getProjStatus() {
		return projStatus;
	}

	public void setProjStatus(String projStatus) {
		this.projStatus = projStatus;
	}

	@Override
	public String toString() {
		return "Project [projId=" + projId + ", projName=" + projName + ", projManager=" + projManager + ", projStatus="
				+ projStatus + "]";
	}

}
