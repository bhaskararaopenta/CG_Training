package com.cg.ovms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cg.ovms.entities.Driver;
import com.cg.ovms.exception.DriverNotFoundException;
import com.cg.ovms.service.DriverService;

@RestController
@RequestMapping("/drivers")
public class DriverController {

    @Autowired
    private DriverService driverService;

    @PostMapping
    public ResponseEntity<Driver> addDriver(@RequestBody Driver driver) {
        Driver newDriver = driverService.addDriver(driver);
        return new ResponseEntity<>(newDriver, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<Driver> updateDriver(@RequestBody Driver driver) throws DriverNotFoundException {
        Driver updatedDriver = driverService.updateDriver(driver);
        return new ResponseEntity<>(updatedDriver, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDriver(@PathVariable int id) {
        driverService.deleteDriver(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Driver> findDriverById(@PathVariable int id) throws DriverNotFoundException {
        Driver driver = driverService.findById(id);
        return new ResponseEntity<>(driver, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Driver>> findAllDrivers() {
        List<Driver> drivers = driverService.findAllDriver();
        return new ResponseEntity<>(drivers, HttpStatus.OK);
    }

    @GetMapping("/vehicle/{vehicleId}")
    public ResponseEntity<Driver> findDriverByVehicleId(@PathVariable int vehicleId) {
        Driver driver = driverService.findByVehicleId(vehicleId);
        return new ResponseEntity<>(driver, HttpStatus.OK);
    }
}