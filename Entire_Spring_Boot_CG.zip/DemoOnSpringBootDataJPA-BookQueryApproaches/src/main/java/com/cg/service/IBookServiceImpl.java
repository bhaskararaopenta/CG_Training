package com.cg.service;

import java.awt.print.Book;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.BookEntity;
import com.cg.repo.BookRepository;

@Service
public class IBookServiceImpl implements IBookService {

	@Autowired
	private BookRepository bookRepository;

	@Override
	public int addBook(BookEntity b) {
		BookEntity res = bookRepository.save(b);
		return res.getBookId();
	}

	@Override
	public Optional<BookEntity> getBookDetails(int id) {
		// TODO Auto-generated method stub
		Optional<BookEntity> res = bookRepository.findById(id);
		return res;
	}

	@Override
	public List<BookEntity> getBookByAuthorName(String authorName) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();

		List<BookEntity> res = bookRepository.findByAuthorName(authorName);
		return res;
	}

	@Override
	public List<BookEntity> getBookByAuthorNameSecond(String authorName) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();

		List<BookEntity> res = bookRepository.findAuthorNameByNameSecond(authorName);
		return res;
	}

	@Override
	public List<BookEntity> getBookByAuthorNameThird(String authorName) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();

		List<BookEntity> res = bookRepository.findAuthorNameByNameThird(authorName);
		return res;
	}

	@Override
	public List<BookEntity> getBookGreaterThanEqualToPrice(Integer price) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPriceGreaterThanEqual(price);
		return res;
	}

	@Override
	public List<BookEntity> getBookGreaterThanEqualToPriceSecond(Integer price) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPriceGreaterThanEqualSecond(price);
		return res;
	}

	@Override
	public List<BookEntity> getBookGreaterThanEqualToPriceThird(Integer price) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPriceGreaterThanEqualThird(price);
		return res;
	}

	@Override
	public List<BookEntity> getBookLessThanPrice(Integer price) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPriceLessThan(price);
		return res;
	}

	@Override
	public List<BookEntity> getBookLessThanPriceSecond(Integer price) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPriceLessThanSecond(price);
		return res;
	}

	@Override
	public List<BookEntity> getBookLessThanPriceThird(Integer price) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPriceLessThanThird(price);
		return res;
	}

	@Override
	public List<BookEntity> bookPublishedBetweenYear(LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPublishedYearBetween(startDate, endDate);
		return res;
	}

	@Override
	public List<BookEntity> bookPublishedBetweenYearSecond(LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPublishedYearBetweenSecond(startDate, endDate);
		return res;
	}

	@Override
	public List<BookEntity> bookPublishedBetweenYearThird(LocalDate startDate, LocalDate endDate) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPublishedYearBetweenThird(startDate, endDate);
		return res;
	}

	@Override
	public List<BookEntity> bookPublishedAfterYear(LocalDate date) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPublishedYearAfter(date);
		return res;
	}

	@Override
	public List<BookEntity> bookPublishedAfterYearSecond(LocalDate date) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPublishedYearAfterSecond(date);
		return res;
	}

	@Override
	public List<BookEntity> bookPublishedAfterYearThird(LocalDate date) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByPublishedYearAfterThird(date);
		return res;
	}

	@Override
	public List<BookEntity> getBookByAuthorNameAndPublisher(String author, String publisher) { // TODO Auto-generated
																								// method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByAuthorNameAndPublisher(author, publisher);
		return res;
	}

	@Override
	public List<BookEntity> getBookByAuthorNameAndPublisherSecond(String authorName, String publisher) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByAuthorAndPublisherEqualsSecond(authorName, publisher);
		return res;
	}

	@Override
	public List<BookEntity> getBookByAuthorNameAndPublisherThird(String authorName, String publisher) {
		// TODO Auto-generated method stub
		List<BookEntity> lbe = new ArrayList<>();
		List<BookEntity> res = bookRepository.findByAuthorAndPublisherEqualsThird(authorName, publisher);
		return res;
	}

	@Override
	public void DeleteBook(int id) {
		// TODO Auto-generated method stub
		Optional<BookEntity> opt = bookRepository.findById(id);

		if (opt.isEmpty()) {
			System.out.println("Record doesnt exist");
		} else {
			BookEntity b = opt.get();
			bookRepository.deleteById(b.getBookId());
		}
	}

	@Override
	public void updateBookPrice(Integer bookId, Integer price) {
		// TODO Auto-generated method stub

		BookEntity entity = new BookEntity();

		Optional<BookEntity> ob = bookRepository.findById(bookId);

		if (ob.isEmpty()) {
			System.out.println("Record not found");
		} else {

			BookEntity res = ob.get();
			res.setPrice(25000);
			bookRepository.save(res);
		}

	}

}
