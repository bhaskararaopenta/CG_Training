package com.day17.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class ExampleOnStreams8 {

	public static void main(String[] args) {

		List<String> al = new ArrayList();
		al.add("smith");
		al.add("rakesh");
		al.add("allen");
		al.add("banu");
		al.add("jack");

		System.out.println("no of elkements is list :" + al.size());
		System.out.println(al);

		Stream<String> st = al.stream();
		Optional<String> os = st.findFirst();
		System.out.println(os.get());

		Stream<String> st2 = al.stream();
		Optional<String> os2 = st2.findAny();
		System.out.println(os2.get());

	}
}
