package com.day18.stringQuestions;

import java.util.Scanner;

public class StringExample4 {

	public static void main(String[] args) {
		
		

	}

}
