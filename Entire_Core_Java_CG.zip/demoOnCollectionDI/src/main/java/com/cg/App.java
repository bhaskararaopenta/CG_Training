package com.cg;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.CollectionDI;
import com.cg.config.SpringConfig;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
//		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//		CollectionDI e = context.getBean("cdi", CollectionDI.class);
//
//		List<String> res = e.getProdNames();
//		System.out.println("Products are :- ");
//		for (String str : res) {
//			System.out.println(str);
//		}
//
//		System.out.println();
//		Set<String> res1 = e.getCustNames();
//		System.out.println("customers name :- ");
//		for (String str1 : res1) {
//			System.out.println(str1);
//		}
//
//		System.out.println();
//		Map<Integer, String> res2 = e.getEmpIdName();
//		System.out.println("emp id & name are :- ");
//		Set<Entry<Integer, String>> entry = res2.entrySet();
//		Iterator<Entry<Integer, String>> itr = entry.iterator();
//		while (itr.hasNext()) {
//			Entry<Integer, String> nxt = itr.next();
//			Integer k = nxt.getKey();
//			String v = nxt.getValue();
//			System.out.println(k + " " + v);
//		}

		// now using java configuration
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		CollectionDI e = context.getBean("getAllDetails", CollectionDI.class);

		List<String> res = e.getProdNames();
		System.out.println("Products are :- ");
		for (String str : res) {
			System.out.println(str);
		}

		System.out.println();
		Set<String> res1 = e.getCustNames();
		System.out.println("customers name :- ");
		for (String str1 : res1) {
			System.out.println(str1);
		}

		System.out.println();
		Map<Integer, String> res2 = e.getEmpIdName();
		System.out.println("emp id & name are :- ");
		Set<Entry<Integer, String>> entry = res2.entrySet();
		Iterator<Entry<Integer, String>> itr = entry.iterator();
		while (itr.hasNext()) {
			Entry<Integer, String> nxt = itr.next();
			Integer k = nxt.getKey();
			String v = nxt.getValue();
			System.out.println(k + " " + v);
		}

	}
}
