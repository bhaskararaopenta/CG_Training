import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UserInterface {
	public static void main(String[] args) {
		// FILL THE CODE HERE
		Scanner scanner = new Scanner(System.in);
		CartonUtility cartonUtility = new CartonUtility();
		List<Carton> cartons = new ArrayList<>();

		System.out.println("Enter the number of cartons");
		int numberOfCartons = scanner.nextInt();
		scanner.nextLine(); // Consume newline

		if (numberOfCartons <= 0) {
			System.out.println("Invalid");
			return;
		}

		System.out.println("Enter carton details");
		for (int i = 0; i < numberOfCartons; i++) {
			String[] details = scanner.nextLine().split("/");
			String productName = details[0];
			int quantity;
			double productCost;

			try {
				quantity = Integer.parseInt(details[1]);
				productCost = Double.parseDouble(details[2]);
			} catch (NumberFormatException e) {
				System.out.println("Quantity number should be a valid number");
				return;
			}

			if (quantity <= 0) {
				System.out.println("Quantity number should be a valid number");
				return;
			}

			Carton carton = new Carton();
			carton.setProductName(productName);
			carton.setQuantity(quantity);
			carton.setProductCost(productCost);
			cartons.add(carton);
		}

		cartonUtility.setCartonList(cartons);
		Carton maxCarton = cartonUtility.findMax(cartonUtility.convertToStream());

		if (maxCarton != null) {
			System.out.println(
					maxCarton.getProductName() + " had the highest quantity with " + maxCarton.getQuantity() + " nos");
		}
	}
}
