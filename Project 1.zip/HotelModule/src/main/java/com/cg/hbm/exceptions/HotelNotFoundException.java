package com.cg.hbm.exceptions;

public class HotelNotFoundException extends RuntimeException {

    // Constructor to create a HotelNotFoundException with a custom message
    public HotelNotFoundException(String message) {
        super(message);
    }

    // Constructor to create a HotelNotFoundException with a custom message and cause
    public HotelNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
