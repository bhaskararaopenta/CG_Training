package com.cg.ovms.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.cg.ovms.customer.entity.Customer;
import com.cg.ovms.customer.service.CustomerService;


@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    
    

  
    @PostMapping("/add")
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        Customer createdCustomer = customerService.addCustomer(customer);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

  
    @GetMapping("/{customerId}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable int customerId) {
        Customer customer = customerService.viewCustomer(customerId);  
       
        
        return new ResponseEntity<>(customer, HttpStatus.OK);
    }


    @GetMapping("/showall")
    public ResponseEntity<List<Customer>> getAllCustomers() {
        List<Customer> customers = customerService.viewAllCustomers("all");
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }


    @GetMapping("/location/{location}")
    public ResponseEntity<List<Customer>> getCustomersByLocation(@PathVariable String location) {
        List<Customer> customers = customerService.viewAllCustomersByLocation(location);
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

  
    @PutMapping("/{customerId}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable int customerId, @RequestBody Customer customer) {
        customer.setCustomerld(customerId);  // Correct the typo here
        Customer updatedCustomer = customerService.updateCustomer(customer);
        return new ResponseEntity<>(updatedCustomer, HttpStatus.OK);
    }


    @DeleteMapping("/{customerId}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable int customerId) {
        Customer customer = new Customer();
        customer.setCustomerld(customerId);  // Set the correct customer ID for deletion
        customerService.removeCustomer(customer);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    
    

    @GetMapping("/vehicle/{customerId}")
    public ResponseEntity<Customer> getVehicleByCustomerId(@PathVariable int customerId) {
        Customer customer = customerService.viewCustomer(customerId);  
       
        
     
       
        
        
        return new ResponseEntity<>(customer, HttpStatus.OK);
    }
    
    
    
}
