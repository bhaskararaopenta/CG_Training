package com.cg.bean;

import org.springframework.stereotype.Component;

@Component("impl2")
public class MyTestImpl2 implements MyTest {

	@Override
	public String getMessage(String msg) {
		// TODO Auto-generated method stub
		return "welcome " + msg;
	}

}
