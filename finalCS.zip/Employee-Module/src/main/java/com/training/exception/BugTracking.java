package com.training.exception;

public class BugTracking extends Exception {

	public BugTracking(String message) {
		super(message);
	}

}
