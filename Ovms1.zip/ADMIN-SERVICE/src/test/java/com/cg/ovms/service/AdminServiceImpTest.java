package com.cg.ovms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.ovms.entity.Admin;
import com.cg.ovms.repository.AdminRepository;

public class AdminServiceImpTest {

    @InjectMocks
    private AdminServiceImp adminService;

    @Mock
    private AdminRepository adminRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddAdmin() {
        Admin admin = new Admin(1, "AdminName");
        when(adminRepository.save(admin)).thenReturn(admin);
        assertEquals(admin, adminService.addAdmin(admin));
    }

    @Test
    public void testViewById() {
        Admin admin = new Admin(1, "AdminName");
        when(adminRepository.findById(1)).thenReturn(Optional.of(admin));
        assertEquals(admin, adminService.viewById(1));
    }

    @Test
    public void testDeleteById() {
        Admin admin = new Admin(1, "AdminName");
        when(adminRepository.findById(1)).thenReturn(Optional.of(admin));
        adminService.deleteById(1);
    }

    @Test
    public void testUpdateAdmin() {
        Admin admin = new Admin(1, "AdminName");
        when(adminRepository.findById(1)).thenReturn(Optional.of(admin));
        when(adminRepository.save(admin)).thenReturn(admin);
        assertEquals(admin, adminService.updateAdmin(admin));
    }
}