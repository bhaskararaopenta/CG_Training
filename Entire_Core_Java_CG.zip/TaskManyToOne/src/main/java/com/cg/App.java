package com.cg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Address;
import com.cg.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sfty = cfg.buildSessionFactory();
		Session sion = sfty.openSession();
		Transaction tx = sion.beginTransaction();

		Address addr = new Address();
		addr.setAddrId(101);
		addr.setLoc("HYD");
		addr.setPin("58849");
		sion.persist(addr);

		Employee e1 = new Employee();
		e1.setEmpId(1);
		e1.setEmpName("A");
		e1.setEmpSal(3.3);
		e1.setAddr(addr);
		sion.persist(e1);

		Employee e3 = new Employee();
		e3.setEmpId(3);
		e3.setEmpName("B");
		e3.setEmpSal(4.3);
		e3.setAddr(addr);

		sion.persist(e3);
		tx.commit();
	}
}
