package com.cg;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Address;
import com.cg.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();

		SessionFactory sfty = cfg.buildSessionFactory();
		Session sion = sfty.openSession();
		Transaction tx = sion.beginTransaction();

		Address a1 = new Address();
		a1.setAddressId(120);
		a1.setCity("vizag-Permit");
		a1.setState("AP");

		Address a2 = new Address();
		a2.setAddressId(120);
		a2.setCity("Bang-Temp");
		a2.setState("KA");

		Employee e1 = new Employee();
		e1.setEmpId(12121);
		e1.setEmpName("SAI");
		e1.setEmpSal(10000);

		List<Address> ls = new ArrayList<Address>();
		ls.add(a2);
		ls.add(a1);
		e1.setAddrs(ls);

		sion.persist(e1);
		tx.commit();
	}
}
