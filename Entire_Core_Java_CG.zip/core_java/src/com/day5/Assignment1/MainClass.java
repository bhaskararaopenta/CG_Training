package com.day5.Assignment1;

public class MainClass {

	public static void main(String[] args) {
		Lion l = new Lion();
		System.out.println("the lion roars :" + l.sound());

		Tiger t = new Tiger();
		System.out.println("the tiger roars :" + t.sound());

	}

}