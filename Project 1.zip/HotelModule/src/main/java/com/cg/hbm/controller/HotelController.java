package com.cg.hbm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.entites.Hotel;
import com.cg.hbm.exceptions.HotelNotFoundException;
import com.cg.hbm.service.IHotelService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/api/hotels")
public class HotelController {

    @Autowired
    private IHotelService hotelService;

    // Create a new hotel
    @PostMapping("/addhotel")
    public ResponseEntity<Hotel> addHotel(@Valid @RequestBody Hotel hotel) {
        Hotel createdHotel = hotelService.addHotel(hotel);
        return new ResponseEntity<>(createdHotel, HttpStatus.CREATED);
    }

    // Update an existing hotel
    @PutMapping("/update/{hotelId}")
    public ResponseEntity<Hotel> updateHotel(@PathVariable int hotelId, @Valid @RequestBody Hotel hotel) {
        hotel.setHotelId(hotelId); // Ensure the hotelId is set in case the request doesn't include it
        Hotel updatedHotel = hotelService.updateHotel(hotel);
        return new ResponseEntity<>(updatedHotel, HttpStatus.OK);
    }

    // Remove a hotel
    @DeleteMapping("/delete/{hotelId}")
    public ResponseEntity<String> removeHotel(@PathVariable int hotelId) {
        Hotel hotel = hotelService.showHotel(hotelId);
        hotelService.removeHotel(hotel);
        return new ResponseEntity<>("Hotel with ID " + hotelId + " deleted successfully", HttpStatus.OK);
    }

    // Get details of a specific hotel
    @GetMapping("/{hotelId}")
    public ResponseEntity<Hotel> getHotel(@PathVariable int hotelId) {
        Hotel hotel = hotelService.showHotel(hotelId);
        return new ResponseEntity<>(hotel, HttpStatus.OK);
    }

    // Get all hotels
    @GetMapping("/showall")
    public ResponseEntity<List<Hotel>> getAllHotels() {
        List<Hotel> hotels = hotelService.showAllHotels();
        return new ResponseEntity<>(hotels, HttpStatus.OK);
    }

    
}
