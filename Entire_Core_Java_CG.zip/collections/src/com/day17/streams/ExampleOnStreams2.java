package com.day17.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams2 {

	public static void main(String[] args) {

		List<Integer> al = new ArrayList<Integer>();

		al.add(30);
		al.add(40);
		al.add(50);
		al.add(20);
		al.add(10);
		al.add(5);

		System.out.println("no of elements in list  :" + al.size());

		System.out.println("Displaying even numbers using enhanced for loop");

		for (int i : al) {

			if (i % 2 == 0) {
				System.out.println(i);
			}
		}

		System.out.println("Displaying even numbers using streams");

		Stream<Integer> st = al.stream();// converting collection object into stream
		Stream<Integer> filterOut = st.filter(s -> s % 2 == 0);

		filterOut.forEach(System.out::println);

	}
}
