package com.cg.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.BookEntity;

public interface BookRepository extends JpaRepository<BookEntity, Integer> {

// 3:-It should accept the name of the author and return all the books authored by him as List<Book>

	// 1 st Way :------
	List<BookEntity> findByAuthorName(String authorName);

	// 2nd Way :-------
	@Query("select b from BookEntity b where b.authorName=:authorName")
	List<BookEntity> findAuthorNameByNameSecond(@Param("authorName") String authorName);

	// 3rd Way :-------
	List<BookEntity> findAuthorNameByNameThird(@Param("authorName") String authorName);

// 4 :-It should accept the price of book and return all the books whose price 
//	is greater than or equal to given price as List<Book>.

	// 1 st Way :-------
	List<BookEntity> findByPriceGreaterThanEqual(Integer price);

	// 2 nd Way
	@Query("select b from BookEntity b where b.price >=:price")
	List<BookEntity> findByPriceGreaterThanEqualSecond(@Param("price") Integer price);

	// 3 rd Way
	List<BookEntity> findByPriceGreaterThanEqualThird(@Param("price") Integer price);

// 5 :-It should accept the price of book and return all the books whose
//	price is less than the given price as List<Book>

	// 1 st Way :-------
	List<BookEntity> findByPriceLessThan(Integer price);

	// 2 nd Way :------
	@Query("select b from BookEntity b where b.price <:price")
	List<BookEntity> findByPriceLessThanSecond(@Param("price") Integer price);

	// 3 rd Way :------
	List<BookEntity> findByPriceLessThanThird(@Param("price") Integer price);

// 6 :- t should accept range of dates and return all the books which 
//	are published between a given dates as List<Book>

	// 1 st Way :-----
	List<BookEntity> findByPublishedYearBetween(LocalDate startDate, LocalDate endDate);

	// 2 nd Way :----
	@Query("select b from BookEntity b where b.publishedYear between :startDate and :endDate")
	List<BookEntity> findByPublishedYearBetweenSecond(@Param("startDate") LocalDate startDate,
			@Param("endDate") LocalDate endDate);

	List<BookEntity> findByPublishedYearBetweenThird(@Param("startDate") LocalDate startDate,
			@Param("endDate") LocalDate endDate);

// 7 :- It should accept date and return all the books which are published
//	after the given date as List<Book>.

	// 1 st Way :------
	List<BookEntity> findByPublishedYearAfter(LocalDate date);

	// 2 nd Way :------
	@Query("select b from BookEntity b where b.publishedYear >:date")
	List<BookEntity> findByPublishedYearAfterSecond(@Param("date") LocalDate date);

	// 3 rd Way :------
	List<BookEntity> findByPublishedYearAfterThird(@Param("date") LocalDate date);

// 8 :- It should accept the name of author and publisher and return all the books 
//	having same author and publisher as List<Book>

	// 1 st Way
	List<BookEntity> findByAuthorNameAndPublisher(String authorName, String publisher);

	// 2nd Way :----------
	@Query("select b from BookEntity b where b.authorName = :authorName and b.publisher = :publisher")
	List<BookEntity> findByAuthorAndPublisherEqualsSecond(@Param("authorName") String authorName,
			@Param("publisher") String publisher);

	// 3 rd Way :-----
	List<BookEntity> findByAuthorAndPublisherEqualsThird(@Param("authorName") String authorName,
			@Param("publisher") String publisher);

}
