package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cg.bean.Employee;

@Component
public class Test implements CommandLineRunner {

	@Autowired
	private Employee emp;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		System.out.println("Employee details are :Using Spring Boot :");
		System.out.println(emp.getEmpId() + " " + emp.getEmpName() + " " + emp.getEmpSal());
	}

}
