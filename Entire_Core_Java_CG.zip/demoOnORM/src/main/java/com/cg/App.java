package com.cg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.model.Employee;
import com.cg.utility.HIbernateUtil;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		/*
		 * Configuration cfg = new Configuration(); cfg.configure();
		 * 
		 * SessionFactory sf = cfg.buildSessionFactory();
		 */
		SessionFactory sf=HIbernateUtil.getUserSessionFactory();
		Session ses = sf.openSession();
		Transaction tr = ses.beginTransaction();
		
		Employee emp=new Employee();
		emp.setEmpno(1000);
		emp.setEmpName("meher");
		emp.setJob("tech");
		emp.setSal(10000);
		
		ses.persist(emp);   // insert into table
		tr.commit();
		
		ses.close();

	}
}
