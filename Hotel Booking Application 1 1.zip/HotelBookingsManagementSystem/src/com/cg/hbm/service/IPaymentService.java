package com.cg.hbm.service;

import com.cg.hbm.entites.Payments;

public interface IPaymentService {
	public Payments addPayment(Payments payment);
}
