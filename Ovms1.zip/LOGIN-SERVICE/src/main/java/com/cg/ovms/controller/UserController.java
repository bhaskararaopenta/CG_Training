package com.cg.ovms.controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.entities.User;
import com.cg.ovms.service.UserService;
import com.cg.ovms.service.UserServiceImp;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/register")//http://localhost:
	public ResponseEntity<User> addUser(@Valid @RequestBody User user){
		User createdUser = userService.addUser(user);
		return ResponseEntity.ok(createdUser);
		}
	
	@PostMapping("/login")
	public ResponseEntity<String> loginUser(@Valid @RequestBody Map<String, String> loginDetails){
		try{
		String userId = loginDetails.get("userId");
		String password = loginDetails.get("password");
		String result = userService.loginUser(userId, password);
		return ResponseEntity.ok(result);
	}catch(Exception ex) {
		return ResponseEntity.badRequest().body(ex.getMessage());
	}}
	
	@GetMapping("getbyId/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable("userId") String userId){
		Optional<User> userget = userService.findByUserId(userId);
		return ResponseEntity.of(userget);
	}
	@DeleteMapping("/remove")
    public ResponseEntity<String> removeUser(@RequestParam String userId) {
       String msg = userService.removeUser(userId);
        return ResponseEntity.ok(msg);
    }

    @PostMapping("/signout")
    public ResponseEntity<String> signOut() {
        String message = userService.signOut();
        return ResponseEntity.ok(message);
    }
}
	
	

