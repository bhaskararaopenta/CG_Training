package com.day4.inheritance;


// this refers to multi-level
public class Fruits {

	String shape;
	
	public void display() {
		System.out.println(this.shape);

	}
}
