package com.day20.threads;

public class ExampleOnThreadDemo implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 0; i < 5; i++) {
			System.out.println("we are in child thread");
		}
	}

}
