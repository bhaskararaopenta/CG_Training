//make the necessary change to make this class a Exception
public class StationNotAvailableException extends Exception {

	public StationNotAvailableException(String s) {
		super(s);
	}
	// fill the code

}
