package com.cg.ovms.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.ovms.entites.Vehicle;

import jakarta.validation.Valid;

@FeignClient(name = "VEHICLE-SERVIVCE")
public interface VehicleClient {

	 @PostMapping("/vehicles/vehicle/add")
	     Vehicle addVehicle(@Valid @RequestBody Vehicle vehicle) ;
	    
	
}
