package com.cg.hbm.dto;

import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entity.RoomDetails;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ResponseDTO {

    // Details of the room
    private RoomDetails roomdetails;

    // Details of the hotel
    private Hotel hotel;
}