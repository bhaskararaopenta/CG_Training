package com.day17.streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams4 {

	public static void main(String[] args) {

		List<Integer> al = Arrays.asList(40, 10, 20, 5, 50, 30);

		System.out.println("Insertion order :" + al);

		Stream<Integer> st = al.stream();
		System.out.println("ascending order");
		st.sorted().forEach(e -> System.out.print(e + " "));

		Stream<Integer> st2 = al.stream();
		System.out.println();
		System.out.println("descending order");

		Comparator<Integer> ct = (c, d) -> c < d ? 1 : (c > d) ? -1 : 0;
		st2.sorted(ct).forEach(e -> System.out.print(e + " "));

		/*
		 * syntax for terminary operator type of variable =
		 * condition?statement1:statement2 if condition is true it returns stat1 if
		 * condition is false it returns stat2
		 */

	}
}
