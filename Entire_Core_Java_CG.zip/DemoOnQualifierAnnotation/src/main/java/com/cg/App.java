package com.cg;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.bean.MyApp;
import com.cg.bean.MyTest;
import com.cg.config.SpringConfig;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		MyApp obj = context.getBean(MyApp.class);
		MyTest myobj = obj.getMytest();
		String res = myobj.getMessage("Bhaskar");
		System.out.println(res);

	}
}
