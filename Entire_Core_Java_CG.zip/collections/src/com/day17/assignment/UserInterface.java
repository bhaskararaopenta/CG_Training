package com.day17.assignment;

import java.util.Scanner;

public class UserInterface {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Operations op = new Operations();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of entries");
		int count = sc.nextInt();
		sc.nextLine();
		for (int i = 0; i < count; i++) {
			System.out.println("Entyer the details");
			String input = sc.nextLine();
			String[] inputAll = input.split(":");
			int id = Integer.parseInt(inputAll[0]);
			String name = inputAll[1];
			int price = Integer.parseInt(inputAll[2]);
			try {
				if (op.isValidPrice(price) && op.isValidName(name)) {
					System.out.println("entry is valid");
				}
			} catch (InvalidProductException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}

		}

	}

}
