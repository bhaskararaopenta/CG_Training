package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class AssignmentOnDeletePrepareStatementUsingScanner {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the product id");
		int pid = sc.nextInt();

		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);

		String query = " delete from product where id=?";
		PreparedStatement ps = con.prepareStatement(query);

		ps.setInt(1, pid);

		int res = ps.executeUpdate();
		if (res > 0) {
			System.out.println("Record deleted successfully");
		} else {
			System.out.println("Record not deleted");
		}

		ps.close();
		con.close();

	}

}
