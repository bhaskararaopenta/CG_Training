package com.cg.hbm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.hbm.entites.Hotel;

// Repository interface for Hotel entity
public interface IHotelRepository extends JpaRepository<Hotel, Integer> {
   
}