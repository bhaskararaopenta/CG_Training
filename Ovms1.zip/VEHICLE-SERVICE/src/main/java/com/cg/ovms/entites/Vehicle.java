package com.cg.ovms.entites;
 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import lombok.Data;
 
@Entity
@Data
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer vehicleId;
 
    @NotNull(message = "Vehicle number cannot be null")
    private String vehicleNumber;
 
    @NotNull(message = "Type cannot be null")
    private String type;
 
    @NotNull(message = "Category cannot be null")
    private String category;
 
    @NotNull(message = "Description cannot be null")
    private String description;
 
    @NotNull(message = "Location cannot be null")
    private String location;
 
    @NotNull(message = "Capacity cannot be null")
    @Min(value = 1, message = "Capacity should be at least 1")
    private int capacity;
 
    @NotNull(message = "Charges per KM cannot be null")
    @Min(value = 0, message = "Charges per KM should be a positive number")
    private double chargesPerKM;
 
    @NotNull(message = "Fixed charges cannot be null")
    @Min(value = 0, message = "Fixed charges should be a positive number")
    private double fixedCharges;
}