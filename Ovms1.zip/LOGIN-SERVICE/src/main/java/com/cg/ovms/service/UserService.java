package com.cg.ovms.service;


import java.util.Optional;

import com.cg.ovms.entities.User;

public interface UserService {

	User addUser(User user);
	String loginUser(String userId , String password) throws Exception;
	String removeUser(String userId);
	String signOut();
	Optional<User> findByUserId(String userId);  // see if you can add exception here and change over all code
}
