package com.day7.stringsPrograms;

public class Dummy {

	public static void main(String[] args) {
		String s="Bhaskar";
		
		System.out.println(s.indexOf('B'));
	}
}
