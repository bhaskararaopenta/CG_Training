package com.day15.lamdaExpression;

import java.util.List;

@FunctionalInterface
public interface EmployeeSal {

	public List<Integer> getEmplyoeeSal(List<Integer> es);
}
