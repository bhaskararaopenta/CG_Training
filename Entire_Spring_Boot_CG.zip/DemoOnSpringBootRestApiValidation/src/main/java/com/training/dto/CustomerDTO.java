package com.training.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;

public class CustomerDTO {

	
	private Integer customerId;
	//key will be read from ValidtionMessages.properties
	@Email(message = "{customer.emailId.invalid}")
	@NotNull(message = "Email Cannot be null")
	private String emailId;
	//key will be read from ValidtionMessages.properties
	@NotNull(message = "{customer.name.invalid}")
	@Pattern(regexp = "[A-Za-z\s]+",
	message = "Invalid pattern Name should not "
			+ "contains numbers")
	private String name;
	
	@PastOrPresent(message = "please provide valid"
			+ " date .Date should be present "
			+ "or past")
	private LocalDate dateOfBirth;

	
	
	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	@Override
	public String toString() {

		return "Customer [customerId=" + customerId + ", emailId=" + emailId + ", name=" + name + ", dateOfBirth="
				+ dateOfBirth + "]";
	}

}
