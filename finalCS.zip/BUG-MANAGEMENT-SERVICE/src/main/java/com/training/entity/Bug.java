package com.training.entity;

import java.time.LocalDate;


//import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class Bug {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long bugId;
	private String title;
	private String description;
	private String type;
	private String priority;
	private Integer progress;
	private String status;
	private LocalDate startDate;
	private LocalDate endDate;
	private Long projectId;
	private Long employeeId;
	
	
	public Bug() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getBugId() {
		return bugId;
	}
	public void setBugId(Long bugId) {
		this.bugId = bugId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Integer getProgress() {
		return progress;
	}
	public void setProgress(Integer progress) {
		this.progress = progress;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public Long getProjectId() {
		return projectId;
	}
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	@Override
	public String toString() {
		return "Bug [bugId=" + bugId + ", title=" + title + ", description=" + description + ", type=" + type
				+ ", priority=" + priority + ", progress=" + progress + ", status=" + status + ", startDate="
				+ startDate + ", endDate=" + endDate + ", projectId=" + projectId + ", employeeId=" + employeeId + "]";
	}
	
	
	
	
	
		
	
}
