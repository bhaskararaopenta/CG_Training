package com.cg;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

public class CalculationTest {

	static Calculation cobj = null;

	@BeforeAll
	public static void methodOne() {
		System.out.println("mainly we are the code to open the connection(database,file)");
		cobj = new Calculation();
		System.out.println("we are in methodOne");
	}

	@Test
	public void getSumTest() {
		System.out.println("we are in getSumTest method");
		int actualOutput = cobj.getSum(40, 40);
		int expectedOutput = 80;
		assertEquals(expectedOutput, actualOutput);
	}

	@Test
	public void getBookList() {
		System.out.println("we are in getBookList method");
		String[] atlst = cobj.getBookList();
		String[] exlst = { "java", "dotnet", "python" };
		assertArrayEquals(exlst, atlst);
	}

	@ParameterizedTest
	@ValueSource(ints = { 6, 8, 10 })
	public void testGetEven(int num) {
		System.out.println("we are in testGetEven method");
		int actopt = cobj.getEven(num);
		assertEquals(0, actopt, "Not a even number");
	}

	@AfterAll
	public static void methodTwo() {
		System.out.println("mainly we are the code to close the connection (database,file)");
		System.out.println("we are in method two");
	}
}
