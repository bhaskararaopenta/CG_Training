package com.day3;

public class ExampleOnConstructors2 {

	int produdtId;
	String productName;
	double price;

	public ExampleOnConstructors2() {
		super();
	}

	public ExampleOnConstructors2(int produdtId, String productName, double price) {
		super();
		this.produdtId = produdtId;
		this.productName = productName;
		this.price = price;
	}

	public static void main(String[] args) {

	}

}
