package com.cg.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.dto.BookDTO;
import com.cg.exception.CGBookException;

public interface BookService {
	
	public BookDTO getBookDetails(Integer bookId) throws CGBookException;
	public void addBook(BookDTO bookDTO) throws CGBookException;
	public List<BookDTO> getBookByAuthorName(String authorName) throws CGBookException;
	public List<BookDTO> getBookGreaterThanEqualToPrice(Integer price) throws CGBookException;
	public List<BookDTO> getBookLessThanPrice(Integer price) throws CGBookException;
	public List<BookDTO> bookPublishedBetweenYear(LocalDate startYear, LocalDate endYear) throws CGBookException;
	public List<BookDTO> bookPublishedAfterYear(LocalDate year) throws CGBookException;
	public List<BookDTO> getBookByAuthorNameAndPublisher(String authorName, String publisher) throws CGBookException;
	public void updateBookPrice(Integer bookId, Integer price) throws CGBookException;
	public void deleteBook(Integer bookId) throws CGBookException;

}
