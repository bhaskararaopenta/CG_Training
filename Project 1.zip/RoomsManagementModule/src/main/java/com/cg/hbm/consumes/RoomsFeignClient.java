package com.cg.hbm.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.hbm.entites.Hotel;

@FeignClient(name = "HotelModule")
public interface RoomsFeignClient {

    // Fetch a hotel by its ID
    @GetMapping("/api/hotels/{hotelId}")
    Hotel getHotel(@PathVariable("hotelId") int hotelId);
}