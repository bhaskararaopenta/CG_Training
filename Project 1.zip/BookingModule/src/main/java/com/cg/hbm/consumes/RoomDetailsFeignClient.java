package com.cg.hbm.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import com.cg.hbm.entity.RoomDetails;

//Feign client for Rooms Management
@FeignClient(name ="RoomsManagementModule")
public interface RoomDetailsFeignClient {
	
	// Get room details by ID
	@GetMapping("/api/rooms/{roomId}")
    RoomDetails getRoomById(@PathVariable("roomId") int roomId );
	
	// Update room details by ID
	@PutMapping("/api/rooms/update/{id}")
	RoomDetails updateRoomDetails(@PathVariable("roomId") int roomId);
	

}
