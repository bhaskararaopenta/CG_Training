package com.day17.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams1 {

	public static void main(String[] args) {

		List<String> al = new ArrayList<String>();

		al.add("scott");
		al.add("martin");
		al.add("allen");
		al.add("fazil");
		al.add("bhaskar");
		al.add("shiva");

		System.out.println("no of elements in list  :" + al.size());

		Stream<String> st = al.stream();// converting collection object into stream
		System.out.println("Displaying elements using strams");

		al.forEach((a) -> {
			System.out.println(a);
		});// terminal operation

		System.out.println("Displaying the elements using forEach Method reference");// converting collection object
																						// into stream
		al.forEach(System.out::println);// terminal operation

	}
}
