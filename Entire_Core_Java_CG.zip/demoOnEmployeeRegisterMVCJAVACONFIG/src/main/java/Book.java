
public class Book {

	   String name;
	    String author;
	    int price;
		@Override
		public String toString() {
			return "Book [name=" + name + ", author=" + author + ", price=" + price + "]";
		}
	    
	    
	
}
