package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.dto.CustomerDTO;
import com.cg.entity.Customer;
import com.cg.repo.CustomerRepo;

@Service
public class ICustomerServiceImpl implements ICustomerService {

	@Autowired
	private CustomerRepo customerRepo;

	@Override
	public int insertCustomer(CustomerDTO c) {

		// converting dto(UserDTO) into entity(User)
		Customer customer = new Customer();

		customer.setEmailId(c.getEmailId());
		customer.setName(c.getName());
		LocalDate cDate = LocalDate.parse(c.getDateOfBirth());
		customer.setDateOfBirth(cDate);
		// TODO Auto-generated method stub

		Customer cobj = customerRepo.save(customer);
		return cobj.getCustomerId();
	}

	@Override
	public Optional<CustomerDTO> searchById(int id) {
		// TODO Auto-generated method stub
		Optional<Customer> sobj = customerRepo.findById(id);

		Customer cus = sobj.get();
		CustomerDTO customerDTO = new CustomerDTO();
		customerDTO.setCustomerId(cus.getCustomerId().toString());
		customerDTO.setName(cus.getName());
		customerDTO.setEmailId(cus.getEmailId());
		customerDTO.setDateOfBirth(cus.getDateOfBirth().toString());
		Optional<CustomerDTO> opdto = Optional.of(customerDTO);
		return opdto;
	}

	@Override
	public List<CustomerDTO> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		List<Customer> res = customerRepo.findAll();

		List<CustomerDTO> cDTO = new ArrayList<>();
		Iterator<Customer> itr = res.iterator();
		while (itr.hasNext()) {
			Customer nxt = itr.next();
			CustomerDTO customerDTO = new CustomerDTO();
			customerDTO.setCustomerId(nxt.getCustomerId().toString());
			customerDTO.setName(nxt.getName());
			customerDTO.setEmailId(nxt.getEmailId());
			customerDTO.setDateOfBirth(nxt.getDateOfBirth().toString());
			cDTO.add(customerDTO);
		}
		return cDTO;
	}

	@Override
	public void customerDeleteById(int id) {
		// TODO Auto-generated method stub
		// 1 st way
		/*
		 * Optional<CustomerDTO> cDel = searchById(id); if (cDel.isEmpty()) {
		 * System.out.println("record not exist"); } else { customerRepo.deleteById(id);
		 * }
		 */

		// 2 nd way
		Optional<Customer> opt = customerRepo.findById(id);
		if (opt.isEmpty()) {
			System.out.println("Record doesnt exist");
		} else {
			Customer c = opt.get();
			customerRepo.deleteById(c.getCustomerId());
		}
	}

	@Override
	public int updateCustomer(CustomerDTO c) {
		// TODO Auto-generated method stub

		// 1 st way
		/*
		 * Customer co = null; Optional<CustomerDTO> cUpd =
		 * searchById(Integer.parseInt(c.getCustomerId()));
		 * 
		 * if (cUpd.isEmpty()) { System.out.println("Record not found"); } else {
		 * Customer customer = new Customer();
		 * customer.setCustomerId(Integer.parseInt(c.getCustomerId()));
		 * customer.setEmailId(c.getEmailId()); customer.setName(c.getName()); LocalDate
		 * cDate = LocalDate.parse(c.getDateOfBirth()); customer.setDateOfBirth(cDate);
		 * // TODO Auto-generated method stub
		 * 
		 * co = customerRepo.save(customer); } return co.getCustomerId();
		 */

		// 2 nd way

		Optional<Customer> opt = customerRepo.findById(Integer.parseInt(c.getCustomerId()));
		if (opt.isEmpty()) {
			System.out.println("No Record Exist Based On Id To update....");
		} else {
			Customer cus = opt.get();
			LocalDate dobj = LocalDate.parse(c.getDateOfBirth());
			cus.setDateOfBirth(dobj);
			cus.setName(c.getName());
			cus.setEmailId(c.getEmailId());
			customerRepo.save(cus);
		}
		return opt.get().getCustomerId();
	}

}
