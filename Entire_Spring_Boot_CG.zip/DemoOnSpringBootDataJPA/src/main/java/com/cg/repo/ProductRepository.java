package com.cg.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	// by default jpa/crud repository uses Id(Primary Key) it perform curd
	// operations instead of primary key you need to use other fields the we need to
	// work with QueryApproach
	Optional<Product> findByProdName(String prodName);

	// 2nd way using @query
	@Query("select p from Product p where p.prodName=:prodName")
	List<Product> findProdNameByName(@Param("prodName") String prodName);
	
	
	// 3rd way using NamedQuery in Entity class (Product)
	List<Product> findProductNameByNameThird(@Param("prodName") String prodName);
}
