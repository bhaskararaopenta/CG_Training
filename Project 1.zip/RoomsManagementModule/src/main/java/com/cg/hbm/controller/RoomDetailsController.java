package com.cg.hbm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.consumes.RoomsFeignClient;
import com.cg.hbm.dto.ResponseDTO;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entity.RoomDetails;
import com.cg.hbm.exceptions.RoomDetailsNotFoundException;
import com.cg.hbm.service.IRoomDetailsService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/rooms")
@Validated
public class RoomDetailsController {

    @Autowired
    private IRoomDetailsService roomDetailsService;

    @Autowired
    private RoomsFeignClient roomsFeignClient;

    // Add a new room detail
    @PostMapping("/add")
    public ResponseEntity<RoomDetails> addRoomDetails(@Valid @RequestBody RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        RoomDetails newRoomDetails = roomDetailsService.addRoomDetails(roomDetails);
        return new ResponseEntity<>(newRoomDetails, HttpStatus.OK);
    }

    // Add room details with hotel details
    @PostMapping("/adddetails")
    public ResponseEntity<ResponseDTO> addRoomDetailswithHoteldetails(@Valid @RequestBody RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        RoomDetails newRoomDetails = roomDetailsService.addRoomDetails(roomDetails);
        Hotel hotel = roomsFeignClient.getHotel(roomDetails.getHotel_id());
        ResponseDTO rdt = new ResponseDTO();
        rdt.setHotel(hotel);
        rdt.setRoomdetails(newRoomDetails);
        return new ResponseEntity<>(rdt, HttpStatus.OK);
    }

    // Update room details
    @PutMapping("/update/{id}")
    public ResponseEntity<RoomDetails> updateRoomDetails(@Valid @PathVariable int id, @Valid @RequestBody RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        roomDetails.setRoom_id(id);
        RoomDetails updatedRoomDetails = roomDetailsService.updateRoomDetails(roomDetails);
        return new ResponseEntity<>(updatedRoomDetails, HttpStatus.OK);
    }

    // Update room details with hotel details
    @PutMapping("/updatedetails/{id}")
    public ResponseEntity<ResponseDTO> updateRoomDetailswithHoteldetails(@Valid @PathVariable int id, @Valid @RequestBody RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        roomDetails.setRoom_id(id);
        RoomDetails updatedRoomDetails = roomDetailsService.updateRoomDetails(roomDetails);
        Hotel hotel = roomsFeignClient.getHotel(roomDetails.getHotel_id());
        ResponseDTO rdt = new ResponseDTO();
        rdt.setHotel(hotel);
        rdt.setRoomdetails(updatedRoomDetails);
        return new ResponseEntity<>(rdt, HttpStatus.OK);
    }

    // Remove room details
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<RoomDetails> removeRoomDetails(@Valid @PathVariable int id) throws RoomDetailsNotFoundException {
        RoomDetails roomDetails = new RoomDetails();
        roomDetails.setRoom_id(id);
        RoomDetails removedRoomDetails = roomDetailsService.removeRoomDetails(roomDetails);
        return new ResponseEntity<>(removedRoomDetails, HttpStatus.OK);
    }

    // Show all room details
    @GetMapping("/allroomdetails")
    public ResponseEntity<List<RoomDetails>> showAllRoomDetails() throws RoomDetailsNotFoundException {
        List<RoomDetails> roomDetailsList = roomDetailsService.showAllRoomDetails();
        return new ResponseEntity<>(roomDetailsList, HttpStatus.OK);
    }

    // Show specific room details by ID
    @GetMapping("/{id}")
    public ResponseEntity<RoomDetails> showRoomDetails(@Valid @PathVariable int id) throws RoomDetailsNotFoundException {
        RoomDetails roomDetails = roomDetailsService.showRoomDetails(id);
        return new ResponseEntity<>(roomDetails, HttpStatus.OK);
    }

    // Show room details with hotel details
    @GetMapping("details/{id}")
    public ResponseEntity<ResponseDTO> showRoomDetailswithHotelDetails(@Valid @PathVariable int id) throws RoomDetailsNotFoundException {
        RoomDetails roomDetails = roomDetailsService.showRoomDetails(id);
        Hotel hotel = roomsFeignClient.getHotel(roomDetails.getHotel_id());
        ResponseDTO rdt = new ResponseDTO();
        rdt.setHotel(hotel);
        rdt.setRoomdetails(roomDetails);
        return new ResponseEntity<>(rdt, HttpStatus.OK);
    }
}