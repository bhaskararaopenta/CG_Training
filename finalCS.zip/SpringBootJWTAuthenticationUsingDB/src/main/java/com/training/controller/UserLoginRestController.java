package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.entity.UserLogin;
import com.training.repo.UserLoginRepo;
import com.training.service.JwtService;

@RestController
@RequestMapping("/api")
public class UserLoginRestController {

	@Autowired
	private UserLoginRepo crepo;

	@Autowired
	private PasswordEncoder pwdEncoder;

	@Autowired
	private AuthenticationManager authManager;
	
	@Autowired
	private JwtService jwt;
	
	@GetMapping("/welcome")
	public String welcome() {
		return "welcome to bug tracking project";
	}
	
	
	@GetMapping("/dummy")
	public String dummy() {
		return "welcome to dummy method";
	}
    //Login Method
	@PostMapping("/login")
	public ResponseEntity<String> loginCheck(@RequestBody UserLogin c) {
		
		UsernamePasswordAuthenticationToken token = 
				new UsernamePasswordAuthenticationToken(c.getRole(), c.getPassword());

		try {
			Authentication authenticate = authManager.authenticate(token);

			if (authenticate.isAuthenticated()) {
				String jwtToken = jwt.generateToken(c.getRole());
				return new ResponseEntity<>(jwtToken, HttpStatus.OK);
			}

		} catch (Exception e) {
			//logger
		}

		return new ResponseEntity<String>("Invalid Credentials", HttpStatus.BAD_REQUEST);
	}
    // Create Method
	@PostMapping("/register")
	public String registerCustomer(@RequestBody UserLogin ulogin) {
		
		// duplicate check

		String encodedPwd = pwdEncoder.encode(ulogin.getPassword());
		ulogin.setPassword(encodedPwd);

		crepo.save(ulogin);;

		return "User registered";
	}
	 // Logout method
    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        // Clear the authentication from SecurityContextHolder
        SecurityContextHolder.clearContext();
        
        
        String  token="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTczMjEwMTQyNiwiZXhwIjoxNzMyMTAxNDg2fQ.uy1e7g5NOtcRcIHyQ-VW-z_vPEd0FHZYmbfcGvuLH0M";
        boolean b= jwt.isTokenExpired(token);
        
        System.out.println("is expried: "+b);
        // Optionally, you could return a success message or status code
        return new ResponseEntity<>("Logged out successfully", HttpStatus.OK);
    }

}





