package com.day5.Assignment4;

public abstract class Animal {

	public abstract String eat();

	public abstract String sleep();

}
