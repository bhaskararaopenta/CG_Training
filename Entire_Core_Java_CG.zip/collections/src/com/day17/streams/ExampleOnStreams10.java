package com.day17.streams;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ExampleOnStreams10 {

	public static void main(String[] args) {

		Stream<String> s = Stream.of("smith", "clerk", "allen", "martin");
		// there is no difference between list-(contains) and stream(anyMatch)

		boolean b = s.anyMatch(e -> e.equals("smith"));
		System.out.println("element is found : ?" + b);

		Stream<String> s1 = Stream.of("smith", "smith");
		boolean b2 = s1.allMatch(e -> e.equals("smith"));
		System.out.println("element found : ? " + b2);

		Product p1 = new Product(1021, "mouse", 400);
		Product p2 = new Product(1212, "laptop", 50000);
		Product p3 = new Product(1211, "keyboard", 5000);
		Stream<Product> s2 = Stream.of(p1, p2, p3);
		double max = s2.collect(Collectors.summarizingDouble(Product::getPrice)).getMax();
		System.out.println("max price is using summarizing :" + max);
		
		
		Stream<Product> s3 = Stream.of(p1, p2, p3);
		Double res = s3.collect(Collectors.summingDouble(Product::getPrice));
		System.out.println("summing :"+ res);

	}
}
