package com.cg;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.utility.Modulee;
import com.cg.utility.Product;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory sfty = cfg.buildSessionFactory();
		Session sion = sfty.openSession();
		Transaction tx = sion.beginTransaction();

		Modulee m1 = new Modulee();
		m1.setModId(101);
		m1.setModName("M1");
		m1.setModType("U");

		sion.persist(m1);

		Modulee m2 = new Modulee();
		m2.setModId(102);
		m2.setModName("M2");
		m2.setModType("E");

		sion.persist(m2);
		

		Product p1 = new Product();
		p1.setProdId(10);
		p1.setProdName("P1");
		p1.setProdCost(2.2);

		List<Modulee> li = new ArrayList<Modulee>();
		li.add(m1);
		li.add(m2);

		p1.setMob(li);
		sion.persist(p1);
		tx.commit();
	}
}
