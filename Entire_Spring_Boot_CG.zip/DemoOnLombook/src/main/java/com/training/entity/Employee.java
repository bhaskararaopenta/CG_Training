package com.training.entity;

import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Component
@Setter
@Getter
public class Employee {

	private int empId;
	private String empName;
	private double sal;
}
