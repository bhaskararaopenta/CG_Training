package com.cg.ovms.dto;

import java.time.LocalDate;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

	private int bookingId;
    private LocalDate bookingDate;
    private LocalDate bookedTillDate;
    private String bookingDescription;
    private double totalCost;
    private double distance;
    private boolean delivery;
}
