package com.day6.testOnException2ndWay;

//custom exception or UserDefined
public class NameException extends Exception {

	public NameException(String s) {
		super(s);
	}

}
