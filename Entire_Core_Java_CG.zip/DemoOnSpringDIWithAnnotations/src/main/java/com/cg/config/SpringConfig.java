package com.cg.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@ComponentScan(basePackages = { "com.cg.bean" })
@PropertySource("AddressData.properties")
public class SpringConfig {

}
