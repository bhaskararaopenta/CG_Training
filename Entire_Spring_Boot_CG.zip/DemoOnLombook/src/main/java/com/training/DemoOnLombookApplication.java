package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.training.entity.Employee;

@SpringBootApplication
public class DemoOnLombookApplication implements CommandLineRunner {

	@Autowired
	private Employee emp;

	public static void main(String[] args) {
		SpringApplication.run(DemoOnLombookApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		emp.setEmpId(1001);
		emp.setEmpName("Bhaskar");
		emp.setSal(5000);

		System.out.println(emp.getEmpId() + " " + emp.getEmpName() + " " + emp.getSal());
	}

}
