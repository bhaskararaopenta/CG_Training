package com.cg.hbm.dto;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entity.User;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class UserDTO {
	
	private BookingDetails bookingDetails;
	
	private User user;

}
