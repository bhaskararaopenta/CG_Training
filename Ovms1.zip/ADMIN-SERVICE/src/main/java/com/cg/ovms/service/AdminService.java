package com.cg.ovms.service;

import com.cg.ovms.entity.Admin;

public interface AdminService {

	public Admin addAdmin(Admin admin);
	
	public Admin viewById(int adminId);
	
	public Admin deleteById(int adminId);
	
	public Admin updateAdmin(Admin admin);
}
