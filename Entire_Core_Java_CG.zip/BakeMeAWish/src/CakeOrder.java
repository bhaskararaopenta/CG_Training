import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class CakeOrder {

	private Map<String, Double> orderMap = new HashMap<String, Double>();

	public Map<String, Double> getOrderMap() {
		return orderMap;
	}

	public void setOrderMap(Map<String, Double> orderMap) {
		this.orderMap = orderMap;
	}

	public void addOrderDetails(String orderId, double cakeCost) {
		// Fill the code here
//		orderMap.put(orderId, cakeCost);	
		orderMap.put(orderId, cakeCost);
	}

	public Map<String, Double> findOrdersAboveSpecifiedCost(double cakeCost) {
		Map<String, Double> mp = new HashMap<String, Double>();

		Set<Entry<String, Double>> entry = orderMap.entrySet();
		Iterator<Entry<String, Double>> itr = entry.iterator();
		while (itr.hasNext()) {
			Entry<String, Double> res = itr.next();
			if (res.getValue() >= cakeCost) {
				String first = res.getKey();
				Double second = res.getValue();
				mp.put(first, second);
			}
		}
		return mp;
	}

	public int findTheNumberOfOrdersBasedOnThePizzaType(String orderId) {

		int count = 0;

		Set<Entry<String, Double>> entry = orderMap.entrySet();
		Iterator<Entry<String, Double>> itr = entry.iterator();
		while (itr.hasNext()) {
			Entry<String, Double> res = itr.next();
			if (res.getKey().equals(orderId)) {
				count++;
			}
		}

		if (count > 0) {
			return count;
		} else {
			return -1;
		}
	}

}
