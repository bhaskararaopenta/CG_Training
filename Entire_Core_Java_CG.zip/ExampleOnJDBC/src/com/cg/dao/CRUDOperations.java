package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CRUDOperations {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		char ch = 'y';

		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);
		do {
			System.out.println("1. insert");
			System.out.println("2. update");
			System.out.println("3. delete");
			System.out.println("4. view all");
			System.out.println("5. view based on requirement");
			System.out.println("6.exit");
			System.out.println("Enter the choice");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:

				System.out.println("Enter the product id");
				int pid = sc.nextInt();

				sc.nextLine();
				System.out.println("Enter the product pname");
				String pname = sc.nextLine();

				System.out.println("Enter the product price");
				int price = sc.nextInt();

				String query = " insert into product values(?,?,?)";
				PreparedStatement ps = con.prepareStatement(query);

				ps.setInt(1, pid);
				ps.setString(2, pname);
				ps.setInt(3, price);

				int res = ps.executeUpdate();
				if (res > 0) {
					System.out.println("Record insert successfully");
				} else {
					System.out.println("Record not inserted");
				}

				ps.close();

				break;
			case 2:
				System.out.println("Enter the product id");
				int pid2 = sc.nextInt();

				sc.nextLine();
				System.out.println("Enter the product pname");
				String pname2 = sc.nextLine();

				System.out.println("Enter the product price");
				int price2 = sc.nextInt();

				String query2 = "update product set pname=?, amount=? where id=?";
				PreparedStatement ps2 = con.prepareStatement(query2);

				ps2.setString(1, pname2);
				ps2.setInt(2, price2);
				ps2.setInt(3, pid2);

				int res1 = ps2.executeUpdate();
				if (res1 > 0) {
					System.out.println("Record update successfully");
				} else {
					System.out.println("Record not updated");
				}
				break;
			case 3:

				System.out.println("Enter the product id");
				int pid3 = sc.nextInt();

				String query3 = " delete from product where id=?";
				PreparedStatement ps3 = con.prepareStatement(query3);

				ps3.setInt(1, pid3);

				int res3 = ps3.executeUpdate();
				if (res3 > 0) {
					System.out.println("Record deleted successfully");
				} else {
					System.out.println("Record not deleted");
				}

				break;
			case 4:
				String query4 = "select * from product";
				PreparedStatement st4 = con.prepareStatement(query4);

				ResultSet res4 = st4.executeQuery();
				System.out.println("product details are : ");
				while (res4.next()) {
					// System.out.println(res.getInt(1)+" "+res.getString(2)+" "+res.getString(3));
					System.out.println(res4.getInt("id") + " " + res4.getString("pname") + " " + res4.getInt("amount"));
				}

				break;
			case 5:

				System.out.println("enter the id to search");
				int dno = sc.nextInt();
				Statement st5 = con.createStatement();
				String query5 = "select id,pname,amount from product where id=" + dno;
				ResultSet res5 = st5.executeQuery(query5);
				System.out.println("Employee details are :- ");
				while (res5.next()) {
					System.out.println(res5.getInt("id") + " " + res5.getString("pname") + " " + res5.getInt("amount"));
				}
				break;
			case 6:
				ch = 'Y';
				System.out.println("Thanks for using application");
				break;

			}

		} while (ch != 'Y');

	}

}
