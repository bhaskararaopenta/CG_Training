package com.day4Test;

public class Address {

	String area;
	String district;

	public Address(String area, String district) {
		super();
		this.area = area;
		this.district = district;
	}

}
