package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.exceptions.BookingDetailsNotFoundException;
import com.cg.hbm.repository.IBookingDetailsRepository;

@Service
public class IBookingDetailsServiceImpl implements IBookingDetailsService {

	@Autowired
	private IBookingDetailsRepository bookRepo;

	private static final String exc = "Booking not found with id ";

	@Override
	@Transactional // Mark as @Transactional to ensure both entities are updated together
	public BookingDetails addBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
		// Fetch the hotel associated with the booking using the hotelId
		bookingDetails = bookRepo.save(bookingDetails);

		// Update the RoomDetails to set availability to false (Booked) for upcoming
		// user they can't access it

		return bookingDetails;
	}

	@Override
	public BookingDetails updateBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
		// Fetch the existing booking from the repository
		Optional<BookingDetails> existingBookingOptional = bookRepo.findById(bookingDetails.getBookingId());

		if (!existingBookingOptional.isPresent()) {
			throw new BookingDetailsNotFoundException(exc + bookingDetails.getBookingId());
		}

		BookingDetails existingBooking = existingBookingOptional.get();

		// Update the fields of the existing booking
		existingBooking.setRoomId(bookingDetails.getRoomId());
		existingBooking.setUserId(bookingDetails.getUserId());
		existingBooking.setBookedFrom(bookingDetails.getBookedFrom());
		existingBooking.setBookedTo(bookingDetails.getBookedTo());
		existingBooking.setNoOfAdults(bookingDetails.getNoOfAdults());
		existingBooking.setNoOfChildren(bookingDetails.getNoOfChildren());
		existingBooking.setAmount(bookingDetails.getAmount());

	
		return bookRepo.save(existingBooking);
	}

	@Override
	@Transactional
	public BookingDetails removeBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
		// Fetch the booking to be deleted from the repository
		Optional<BookingDetails> existingBookingOptional = bookRepo.findById(bookingDetails.getBookingId());

		if (!existingBookingOptional.isPresent()) {
			throw new BookingDetailsNotFoundException(exc + bookingDetails.getBookingId());
		}

		// Delete the booking from the repository
		BookingDetails existingBooking = existingBookingOptional.get();
		bookRepo.delete(existingBooking);

		return existingBooking; // Return the deleted booking
	}

	@Override
	public BookingDetails showBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
		// Fetch the booking details from the repository
		Optional<BookingDetails> existingBookingOptional = bookRepo.findById(bookingDetails.getBookingId());

		if (!existingBookingOptional.isPresent()) {
			throw new BookingDetailsNotFoundException(exc + bookingDetails.getBookingId());
		}

		BookingDetails existingBooking = existingBookingOptional.get();

		return existingBooking; // Return the booking with hotel details
	}

	@Override
	public List<BookingDetails> showAllBookingDetails() {
		return bookRepo.findAll(); // Return all bookings from the repository
	}
}
