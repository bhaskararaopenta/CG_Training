package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.training.dto.UserDepartment;
import com.training.entity.User;
import com.training.service.UserService;


@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
    private UserService userService;

    @PostMapping("/add")
    public ResponseEntity<User> saveUser(@RequestBody User user){
        User savedUser = userService.saveUser(user);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<UserDepartment> getUser(@PathVariable("id") Long userId){
        UserDepartment usDt = userService.getUser(userId);
        return ResponseEntity.ok(usDt);
    }
}