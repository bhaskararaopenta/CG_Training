package com.day5.interfaceTopic;

public interface MyApp {
	 static  double pi=3.142;     //static final                          //while compiling MyApp.java -> MyApp.class
	public String sayHello(String s);         //public abstract String sayHello();
	public abstract void m1();         
	int addition(int x,int y);        //public abstract int addition();
}
