package com.day5.example1OnInterface;

public interface I2 extends I1{
    public abstract int addition(int x,int y,int z);
    public  void display();
}
