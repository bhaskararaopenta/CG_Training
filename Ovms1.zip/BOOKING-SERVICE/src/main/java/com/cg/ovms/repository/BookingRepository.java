package com.cg.ovms.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.ovms.entities.Booking;

@Repository
public interface BookingRepository  extends JpaRepository<Booking, Integer>{

	 List<Booking> findByCustomerIdEquals(int customerId);
	List<Booking> findByBookingDateLessThanEqual (LocalDate bookingDate);
	 List<Booking> findByVehicleIdEquals(int vehicleId);
}
