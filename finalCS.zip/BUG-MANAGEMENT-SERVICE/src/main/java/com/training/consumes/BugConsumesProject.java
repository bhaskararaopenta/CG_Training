package com.training.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.training.dto.ProjectDTO;

@FeignClient(name="Project-Module")
public interface BugConsumesProject {

	@GetMapping("/project/get/{id}")
	public ProjectDTO bugConsumesProjectById(@PathVariable Long id);
		
	
}
