package com.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.training.bean.EmployeeDTO;
import com.training.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	@RequestMapping("/show")
	public ModelAndView show() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("Register"); // returning the view - it will search for Register.jsp
		// views
		return mav;
	}

	@RequestMapping("/reg")
	public ModelAndView register(@ModelAttribute("employee") EmployeeDTO emp) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("Register"); // return the views Register.jsp
		mav.addObject("emp", emp); // in jsp request object passing employee(emp) object

		employeeService.saveEmployee(emp); // sending to service service layer

		return mav;
	}

}
