import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// Fill the code here
		System.out.println("Enter the man name");
		String manName = sc.next();
		System.out.println("Enter the woman name");
		String womenName = sc.next();

		if (!nameChecking(manName)) {
			System.out.println(manName + " is an invalid name");
		} else if (!nameChecking(womenName)) {
			System.out.println(manName + " is an invalid name");
		} else if (!nameChecking(manName) && !nameChecking(womenName)) {
			System.out.println("Both " + manName + " and " + womenName + " are invalid names");
		}

	}

	public static boolean nameChecking(String manName) {
		// TODO Auto-generated method stub
		manName.matches("[a-zA-Z ]");
		return false;
	}

}
