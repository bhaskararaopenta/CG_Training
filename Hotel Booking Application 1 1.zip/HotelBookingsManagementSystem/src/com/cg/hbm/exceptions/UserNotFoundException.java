package com.cg.hbm.exceptions;

public class UserNotFoundException extends Exception {

}
