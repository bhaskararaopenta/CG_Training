package com.day18.stringQuestions;

import java.util.Scanner;

public class StringExample3 {

	public static void main(String[] args) {

		System.out.println("enter the string");
		Scanner sc = new Scanner(System.in);

		String out = sc.nextLine();

		if (out.matches(".*[aeiou].*")) {

			System.out.println("yes");
		} else {

			System.out.println("no");
		}

	}

}
