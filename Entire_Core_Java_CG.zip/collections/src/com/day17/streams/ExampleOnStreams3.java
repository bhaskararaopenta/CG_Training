package com.day17.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams3 {

	public static void main(String[] args) {

		List<String> al = Arrays.asList("mango", "apple", "grape", "kiwi", "papaya", "banana");

		// print the elements whose length is greater than 5

		Stream<String> st = al.stream();
		st.filter(e -> e.length() > 5).forEach(e -> System.out.println(e));

		System.out.println("printing length of each element using map() ");
		Stream<String> st1 = al.stream();
		Stream<Object> mapOutPut = st1.map(s -> s.length());
		mapOutPut.forEach(System.out::println);

	}
}
