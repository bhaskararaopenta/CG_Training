package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ExampleOnUpdateUsingPrepareStatement {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);

		String query="update product set pname=?, amount=? where id=?";
		PreparedStatement ps = con.prepareStatement(query);

		ps.setString(1, "Keyboard");
		ps.setInt(2, 20000);
		ps.setInt(3, 1222);
		
		int res = ps.executeUpdate();
		if (res>0) {
			System.out.println("record is update successfully");
		} else {
			System.out.println("record is not updated .....! ");
		}
		ps.close();
		con.close();
	}

}
