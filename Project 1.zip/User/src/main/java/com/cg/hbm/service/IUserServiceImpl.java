package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.entity.User;
import com.cg.hbm.exceptions.UserNotFoundException;
import com.cg.hbm.repository.UserRepository;

@Service
public class IUserServiceImpl implements IUserService {

    @Autowired
    private UserRepository userRepository;

    // Add a new user
    @Override
    public User addUser(User user) throws UserNotFoundException {
        return userRepository.save(user);
    }

    // Update an existing user
    @Override
    public User updateUser(User user) throws UserNotFoundException {
        Optional<User> optionalUser = userRepository.findById(user.getUser_id());
        User updatedUser = optionalUser.orElseThrow(() -> new UserNotFoundException("service.USER_NOT_FOUND"));
        updatedUser.setUser_id(user.getUser_id());
        updatedUser.setUser_name(user.getUser_name());
        updatedUser.setEmail(user.getEmail());
        updatedUser.setPassword(user.getPassword());
        updatedUser.setRole(user.getRole());
        updatedUser.setAddress(user.getAddress());
        userRepository.save(updatedUser);
        return updatedUser;
    }

    // Remove a user
    @Override
    public User removeUser(User user) throws UserNotFoundException {
        Optional<User> existingUser = userRepository.findById(user.getUser_id());
        User deleteUser = existingUser.orElseThrow(() -> new UserNotFoundException("service.USER_NOT_FOUND"));
        userRepository.delete(deleteUser);
        return deleteUser;
    }

    // Show all users
    @Override
    public List<User> showAllUsers() throws UserNotFoundException {
        List<User> users = userRepository.findAll();
        if (users.isEmpty()) {
            throw new UserNotFoundException("service.USER_NOT_FOUND");
        }
        return users;
    }

    // Show a specific user
    @Override
    public User showUser(User user) throws UserNotFoundException {
        Optional<User> optionalUser = userRepository.findById(user.getUser_id());
        return optionalUser.orElseThrow(() -> new UserNotFoundException("service.USER_NOT_FOUND"));
    }
}