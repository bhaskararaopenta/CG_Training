package com.day15.lamdaExpression;

public interface ProdTest {

	public int addition(int x, int y);
}
