package com.cg.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;

@Entity
public class Cust {

	@Id
	@SequenceGenerator(name = "pkgen", sequenceName = "customer_sequence", allocationSize = 1)
	@GeneratedValue(generator = "pkgen", strategy = GenerationType.SEQUENCE)
	private int customerId;

	private String custName;
	private String addrs;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAddrs() {
		return addrs;
	}

	public void setAddrs(String addrs) {
		this.addrs = addrs;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", custName=" + custName + ", addrs=" + addrs + "]";
	}

}
