package com.day5.Assignment4;

public class Tiger extends Animal {

	@Override
	public String eat() {
		return "Tiger eats fresh meat";
	}

	@Override
	public String sleep() {
		return "tiger sleeps 5 hrs a day";
	}

}
