package com.day18.stringQuestions;

import java.util.Scanner;

public class StringExample2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the full string");
		String input = sc.nextLine();

		System.out.println("enter the single character to remove");
		String ch = sc.next();
		char ch1 = ch.charAt(0);

		StringBuilder sb = new StringBuilder(input);
		for (int i = 0; i < sb.length(); i++) {

			if (sb.charAt(i) == ch1) {
				sb.deleteCharAt(i);
			}
		}

		System.out.println(sb.substring(0, 1).toUpperCase() + sb.substring(1));
		// TODO Auto-generated method stub

	}

}
