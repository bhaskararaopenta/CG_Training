package com.cg;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.cg.dto.CustomerDTO;
import com.cg.service.ICustomerService;

@Component
public class Test implements CommandLineRunner {

	@Autowired
	private ICustomerService customerService;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		// 1 :- insert operation

		/*
		 * CustomerDTO dto = new CustomerDTO(); dto.setName("Meher");
		 * dto.setEmailId("Meher@gmail.com"); dto.setDateOfBirth("2001-07-14"); int res
		 * = customerService.insertCustomer(dto);
		 * System.out.println(" record inserted successfully " + res);
		 */

		// 2 :- search By Id
		/*
		 * Optional<CustomerDTO> res = customerService.searchById(1); if (res.isEmpty())
		 * { System.out.println("Record not found"); } else { CustomerDTO out =
		 * res.get(); System.out.println( out.getCustomerId() + " " + out.getName() +
		 * " " + out.getEmailId() + " " + out.getDateOfBirth()); }
		 */

		// 3 :- Fetch All Records

		/*
		 * List<CustomerDTO> res = customerService.getAllCustomerDetails(); if
		 * (res.isEmpty()) { System.out.println(" No records in database"); } else { for
		 * (CustomerDTO customerDTO : res) {
		 * System.out.println(customerDTO.getCustomerId() + " " + customerDTO.getName()
		 * + " " + customerDTO.getEmailId() + " " + customerDTO.getDateOfBirth()); } }
		 */

		// 4 :- Delete By Id
		// customerService.customerDeleteById(2);

		// 5 :-Update Based On Id

		CustomerDTO cDto = new CustomerDTO();
		cDto.setCustomerId("3");
		cDto.setName("Bhaskar");
		cDto.setEmailId("Bhaskar@gmail.com");
		cDto.setDateOfBirth("1947-07-15");
		int res = customerService.updateCustomer(cDto);
		System.out.println("Record updated successfully " + res);

	}

}
