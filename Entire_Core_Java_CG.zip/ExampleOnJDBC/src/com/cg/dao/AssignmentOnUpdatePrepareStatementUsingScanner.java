package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class AssignmentOnUpdatePrepareStatementUsingScanner {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the product id");
		int pid = sc.nextInt();

		sc.nextLine();
		System.out.println("Enter the product pname");
		String pname = sc.nextLine();
		
		System.out.println("Enter the product price");
		int price = sc.nextInt();
		
		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);

		String query = "update product set pname=?, amount=? where id=?";
		PreparedStatement ps = con.prepareStatement(query);

		ps.setString(1, pname);
		ps.setInt(2, price);
		ps.setInt(3, pid);

		int res = ps.executeUpdate();
		if (res > 0) {
			System.out.println("Record update successfully");
		} else {
			System.out.println("Record not updated");
		}

		ps.close();
		con.close();

	}

}
