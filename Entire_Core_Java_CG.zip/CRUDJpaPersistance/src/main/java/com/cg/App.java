package com.cg;

import com.cg.model.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		EntityManagerFactory emfty = Persistence.createEntityManagerFactory("bhaskar");
		EntityManager em = emfty.createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();

		Student st = new Student();
		st.setStudentId(67890);
		st.setStudentName("basha");
		st.setAddress("nellore");
		
		em.persist(st);
		et.commit();
		em.close();
	}
}
