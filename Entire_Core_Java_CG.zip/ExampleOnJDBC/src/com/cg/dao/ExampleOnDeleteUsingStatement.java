package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ExampleOnDeleteUsingStatement {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		Class.forName("com.mysql.cj.jdbc.Driver");

		String url = "jdbc:mysql://localhost:3306/batch2";
		String uname = "root";
		String pwd = "root";

		Connection con = DriverManager.getConnection(url, uname, pwd);
		
		Statement st = con.createStatement();
		int res = st.executeUpdate("delete from product where id=1211");
		if (res>0) {
			System.out.println("Record deleted successfully");
		} else {
			System.out.println("Record  not deleted");
		}
		
		st.close();
		con.close();
	}

}
