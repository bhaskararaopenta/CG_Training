/**
 * 
 */
/**
 * 
 */
module ExampleOnJDBC {
	requires java.sql;
}