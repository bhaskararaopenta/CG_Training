package com.day5.example1OnInterface;

public interface I1 {
	   public String sayHello(String s);
	   public  void display();
	}
