package com.day20.threads;

public class Thread1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub]
		
		System.out.println("Hello World");
		Thread t=Thread.currentThread();
		System.out.println("current thread information is :"+t); // [main,5,main]
		System.out.println("Current thread priority is  :"+t.getPriority()); //5
		System.out.println("current thread name is :"+t.getName());
 
		System.out.println("hi");
		System.out.println("hello CG");
	}

}
