package com.cg.bean;

import org.springframework.stereotype.Component;

@Component
public interface MyTest {

	public String getMessage(String msg);
}
