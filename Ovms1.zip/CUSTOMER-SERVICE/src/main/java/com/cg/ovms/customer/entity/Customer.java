package com.cg.ovms.customer.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "customer")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerld;

	@NotNull(message = "First name cannot be null")
	@Size(min = 2, max = 50, message = "First name should be between 2 and 50 characters")
	@Pattern(regexp = "^[A-Za-z]+$", message = "First name should only contain alphabetic characters")
	private String firstName;

	@NotNull(message = "Last name cannot be null")
	@Size(min = 2, max = 50, message = "Last name should be between 2 and 50 characters")
	@Pattern(regexp = "^[A-Za-z]+$", message = "Last name should only contain alphabetic characters")
	private String lastName;

	@NotNull(message = "Email cannot be null")
	@Email(message = "Email should be valid")
	private String emailld;


	@NotNull(message = "Phone number cannot be null")
	@Size(min = 10, max = 10, message = "Phone number should be 10 digits")
	private String mobileNumber;

	@NotNull(message = "Address cannot be null")
	@Size(min = 5, max = 255, message = "Address should be between 5 and 255 characters")
	private String address;
	
	@NotEmpty(message = "Vehicle id must be present")
	private int vehicleID;
	
	@Positive(message =  "It Must be Positive")
	private int bookingId;
	
	@Positive(message = "It must be Positive")
	private int paymentId;

	
}
