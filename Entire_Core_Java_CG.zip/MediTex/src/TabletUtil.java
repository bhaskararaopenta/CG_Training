import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TabletUtil {

	public List<Tablet> retrieveTabletsByBrand(Stream<Tablet> tabletStream, String brand) {

		// Fill the code here

//		Stream<Tablet> res = tabletStream.filter(e -> e.getBrand().equals(brand));
//		List<Tablet> fi = res.collect(Collectors.toList());
//		return fi;
		
//		 List<Tablet> res = tabletStream.filter(e -> e.getBrand().equals(brand)).toList();
//		 return res;
		
		List<Tablet> res = tabletStream.filter(e->e.getBrand().equals(brand)).toList();
		return res;
	}

	public List<String> getTabletsAboveMg(Stream<Tablet> tabletStream, int mg) {
		
		List<String> res = tabletStream.filter(e->e.getMg()>= mg).map(e->e.getName()).toList();
		return res;
		/*
		 * List<String> al = new ArrayList<String>();
		 * 
		 * List<Tablet> res = tabletStream.filter(e -> e.getMg() >
		 * mg).collect(Collectors.toList());
		 * 
		 * for (Tablet tablet : res) { String name = tablet.getBrand(); al.add(name); }
		 * return al;
		 */
		// Fill the code here
		//return tabletStream.filter(t -> t.getMg() >= mg).map(Tablet::getName).toList();
		//return tabletStream.filter(t -> t.getMg() >= mg).map(e->e.getName()).toList();
		
		

	}
}
