package com.cg.ovms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.ovms.entities.Booking;
import com.cg.ovms.repository.BookingRepository;

public class BookingServiceImpTest {

    @InjectMocks
    private BookingServiceImp bookingService;

    @Mock
    private BookingRepository bookingRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddBooking() {
        Booking booking = new Booking();
        when(bookingRepository.save(booking)).thenReturn(booking);
        assertEquals(booking, bookingService.addBooking(booking));
    }

    @Test
    public void testCancelBooking() {
        Booking booking = new Booking();
        booking.setBookingId(1);
        when(bookingRepository.findById(1)).thenReturn(Optional.of(booking));
        bookingService.cancelBooking(booking);
    }

    @Test
    public void testUpdateBooking() {
        Booking booking = new Booking();
        booking.setBookingId(1);
        when(bookingRepository.findById(1)).thenReturn(Optional.of(booking));
        when(bookingRepository.save(booking)).thenReturn(booking);
        assertEquals(booking, bookingService.updateBooking(booking));
    }

    @Test
    public void testViewById() {
        Booking booking = new Booking();
        booking.setBookingId(1);
        when(bookingRepository.findById(1)).thenReturn(Optional.of(booking));
        assertEquals(booking, bookingService.viewById(1));
    }

    @Test
    public void testViewAllBooking() {
        List<Booking> bookings = Arrays.asList(new Booking(), new Booking());
        when(bookingRepository.findByCustomerIdEquals(1)).thenReturn(bookings);
        assertEquals(bookings, bookingService.viewAllBooking(1));
    }

    @Test
    public void testViewAllBookingByDate() {
        List<Booking> bookings = Arrays.asList(new Booking(), new Booking());
        when(bookingRepository.findByBookingDateLessThanEqual(LocalDate.now())).thenReturn(bookings);
        assertEquals(bookings, bookingService.viewAllBookingByDate(LocalDate.now()));
    }

    @Test
    public void testViewAllBookingByVehicle() {
        List<Booking> bookings = Arrays.asList(new Booking(), new Booking());
        when(bookingRepository.findByVehicleIdEquals(1)).thenReturn(bookings);
        assertEquals(bookings, bookingService.viewAllBookingByVehicle(1));
    }
}