package com.day7.stringsPrograms;

public class StringBigReverseWordByWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="This is a class";
		
		String res="";
		String[] str = s.split("");
		for (int i = 0; i < str.length; i++) {
			
			res=res+first(str[i]);
		}
		System.out.println(res);

	}

	public static String first(String string) {
		// TODO Auto-generated method stub
		String rev="";
		
		for (int i = string.length()-1;i>=0; i--) {
			rev=string.charAt(i)+rev;
		}
		return rev;
	}}