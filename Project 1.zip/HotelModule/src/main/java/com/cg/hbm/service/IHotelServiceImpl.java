package com.cg.hbm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.hbm.entites.Hotel;
import com.cg.hbm.exceptions.HotelNotFoundException;
import com.cg.hbm.repository.IHotelRepository;

@Service
public class IHotelServiceImpl implements IHotelService {

    // Autowire the hotel repository
    @Autowired 
    private final IHotelRepository hotelRepository;

    // Constructor for dependency injection
    @Autowired
    public IHotelServiceImpl(IHotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    // Add a new hotel
    @Override
    public Hotel addHotel(Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    // Update an existing hotel
    @Override
    public Hotel updateHotel(Hotel hotel) {
        if (!hotelRepository.existsById(hotel.getHotelId())) {
            throw new HotelNotFoundException("Hotel not found with id " + hotel.getHotelId());
        }
        return hotelRepository.save(hotel);
    }

    // Remove a hotel
    @Override
    public Hotel removeHotel(Hotel hotel) {
        if (!hotelRepository.existsById(hotel.getHotelId())) {
            throw new HotelNotFoundException("Hotel not found with id " + hotel.getHotelId());
        }
        hotelRepository.delete(hotel);
        return hotel;
    }

    // Show all hotels
    @Override
    public List<Hotel> showAllHotels() {
        return hotelRepository.findAll();
    }

    // Show a specific hotel by ID
    @Override
    public Hotel showHotel(int hotelId) {
        return hotelRepository.findById(hotelId)
             .orElseThrow(() -> new HotelNotFoundException("Hotel not found with id " + hotelId));
    }
}