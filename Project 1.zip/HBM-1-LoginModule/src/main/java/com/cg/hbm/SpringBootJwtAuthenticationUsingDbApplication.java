package com.cg.hbm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.cg.hbm.repo")
@EntityScan(basePackages = "com.cg.hbm.entity")
public class SpringBootJwtAuthenticationUsingDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJwtAuthenticationUsingDbApplication.class, args);
	}

}
