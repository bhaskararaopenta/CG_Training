package com.day15.lamdaExpression;

@FunctionalInterface
public interface MyApp {

	public int addition(int x, int y, int z);
}
