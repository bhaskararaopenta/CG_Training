package com.cg.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.bean.CollectionDI;

@Configuration
public class SpringConfig {

	@Bean
	public CollectionDI getAllDetails() {
		CollectionDI cdi = new CollectionDI();

		List<String> li = new ArrayList<String>();
		li.add("tv");
		li.add("remote");
		li.add("charger");

		cdi.setProdNames(li);

		Set<String> st = new HashSet<String>();
		st.add("Bhaskar");
		st.add("Siva");
		st.add("Jyothi");

		cdi.setCustNames(st);

		Map<Integer, String> mp = new HashMap<Integer, String>();
		mp.put(1001, "Ramu");
		mp.put(1002, "Hari");
		mp.put(1003, "Siri");

		cdi.setEmpIdName(mp);

		return cdi;
	}
}
