package com.training.dto;

public class ResponseDTO {

	private BugDTO bdto;
	private ProjectDTO pdto;
	private EmployeeDTO edto;
	

	public BugDTO getBdto() {
		return bdto;
	}

	public void setBdto(BugDTO bdto) {
		this.bdto = bdto;
	}

	public EmployeeDTO getEdto() {
		return edto;
	}

	public void setEdto(EmployeeDTO edto) {
		this.edto = edto;
	}

	public ProjectDTO getPdto() {
		return pdto;
	}

	public void setPdto(ProjectDTO pdto) {
		this.pdto = pdto;
	}
}
