package com.cg.hbm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.consumes.HotelFeignClient;
import com.cg.hbm.consumes.RoomDetailsFeignClient;
import com.cg.hbm.consumes.UserDetailsFeignClient;
import com.cg.hbm.dto.HotelDTO;
import com.cg.hbm.dto.ResponseDTO;
import com.cg.hbm.dto.RoomDetailsDTO;
import com.cg.hbm.dto.UserDTO;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entites.Hotel;
import com.cg.hbm.entity.RoomDetails;
import com.cg.hbm.entity.User;
import com.cg.hbm.exceptions.BookingDetailsNotFoundException;
import com.cg.hbm.service.IBookingDetailsService;

@RestController
@RequestMapping("/api/bookings")
public class BookingDetailsController {

    @Autowired
    private IBookingDetailsService bookingDetailsService;

    @Autowired
    private HotelFeignClient hotelFeignClient;  // Injecting the Hotel Feign Client
    @Autowired
    private RoomDetailsFeignClient roomFeignClient;  // Injecting the Room Feign Client
    @Autowired
    private UserDetailsFeignClient userFeignClient;  // Injecting the User Feign Client
    
    @PostMapping("/add")
    public ResponseEntity<BookingDetails> addBooking(@RequestBody BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
    	 BookingDetails addedBooking = bookingDetailsService.addBookingDetails(bookingDetails);
    	return new ResponseEntity<>(addedBooking, HttpStatus.CREATED);
    }

    @PostMapping("/adddetails")
    public ResponseEntity<ResponseDTO> addBookingwithdetails(@RequestBody BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
    	 BookingDetails addedBooking = bookingDetailsService.addBookingDetails(bookingDetails);
        // Fetch hotel details using Feign Client
        Hotel hotel = hotelFeignClient.getHotelById(addedBooking.getHotelId());
        // Fetch room details using Feign Client
        RoomDetails room = roomFeignClient.getRoomById(addedBooking.getRoomId());
        // Fetch user details using Feign Client
        User user = userFeignClient.getUserById(addedBooking.getUserId());
      ResponseDTO rdto= new ResponseDTO(addedBooking, hotel, room, user);
        // Now proceed with adding the booking
        return new ResponseEntity<>(rdto, HttpStatus.CREATED);  // Return 201 Created
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<BookingDetails> updateBooking(@PathVariable int id, @RequestBody BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
    	BookingDetails updatedBooking = bookingDetailsService.updateBookingDetails(bookingDetails);
		return new ResponseEntity<>(updatedBooking, HttpStatus.CREATED);
    }

    @PutMapping("/updatedetails/{id}")
    public ResponseEntity<ResponseDTO> updateBookingwithdetails(@PathVariable int id, @RequestBody BookingDetails bookingDetails) throws BookingDetailsNotFoundException {
    	 BookingDetails updatedBooking = bookingDetailsService.updateBookingDetails(bookingDetails);
        // Fetch hotel details using Feign Client
        Hotel hotel = hotelFeignClient.getHotelById(updatedBooking.getHotelId());

        // Fetch room details using Feign Client
        RoomDetails room = roomFeignClient.getRoomById(updatedBooking.getRoomId());
       
        // Fetch user details using Feign Client
        User user = userFeignClient.getUserById(updatedBooking.getUserId());
          // Set the ID for the booking to be updated
        ResponseDTO rdto= new ResponseDTO(updatedBooking, hotel, room, user);
        return new ResponseEntity<>(rdto, HttpStatus.OK);  // Return 200 OK
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<BookingDetails> removeBooking(@PathVariable int id) throws BookingDetailsNotFoundException {
        BookingDetails bookingDetails = new BookingDetails();
        bookingDetails.setBookingId(id);  // Set the ID for the booking to be removed

        BookingDetails removedBooking = bookingDetailsService.removeBookingDetails(bookingDetails);
        return new ResponseEntity<>(removedBooking, HttpStatus.OK);  // Return 200 OK
    }
    @GetMapping("/show/{id}")
    public ResponseEntity<BookingDetails> showBooking(@PathVariable int id) throws BookingDetailsNotFoundException {
    	BookingDetails bookingDetails = new BookingDetails();
        bookingDetails.setBookingId(id);  // Set the ID for the booking to be retrieved
        BookingDetails foundBooking = bookingDetailsService.showBookingDetails(bookingDetails);
		return new ResponseEntity<>(foundBooking, HttpStatus.OK);
    }

    @GetMapping("/showdetails/{id}")
    public ResponseEntity<ResponseDTO> showBookingwithdetails(@PathVariable int id) throws BookingDetailsNotFoundException {
        BookingDetails bookingDetails = new BookingDetails();
        bookingDetails.setBookingId(id);  // Set the ID for the booking to be retrieved
        BookingDetails foundBooking = bookingDetailsService.showBookingDetails(bookingDetails);
     // Fetch hotel details using Feign Client
        Hotel hotel = hotelFeignClient.getHotelById(foundBooking.getHotelId());

        // Fetch room details using Feign Client
        RoomDetails room = roomFeignClient.getRoomById(foundBooking.getRoomId());
       
        // Fetch user details using Feign Client
        User user = userFeignClient.getUserById(foundBooking.getUserId());
          // Set the ID for the booking to be updated
        ResponseDTO rdto= new ResponseDTO(foundBooking, hotel, room, user);
        return new ResponseEntity<>(rdto, HttpStatus.OK);  // Return 200 OK
    }

    @GetMapping("/showall")
    public ResponseEntity<List<BookingDetails>> showAllBookings() {
        List<BookingDetails> allBookings = bookingDetailsService.showAllBookingDetails();
        return new ResponseEntity<>(allBookings, HttpStatus.OK);  // Return 200 OK
    }
}
