package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoOnSpringBootRestApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoOnSpringBootRestApi1Application.class, args);
	}

}
