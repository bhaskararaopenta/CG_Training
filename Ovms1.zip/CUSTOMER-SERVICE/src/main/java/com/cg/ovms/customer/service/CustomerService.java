package com.cg.ovms.customer.service;

import java.util.List;

import com.cg.ovms.customer.entity.Customer;
import com.cg.ovms.customer.exception.DuplicateRecordException;
import com.cg.ovms.customer.exception.ResourceNotFoundException;

public interface CustomerService {
    Customer addCustomer(Customer customer) throws DuplicateRecordException;
    Customer removeCustomer(Customer customer)throws ResourceNotFoundException;
    Customer updateCustomer(Customer customer)throws ResourceNotFoundException;
    Customer viewCustomer(int customerId)throws ResourceNotFoundException;
    List<Customer> viewAllCustomers(String vtype)throws ResourceNotFoundException;
    List<Customer> viewAllCustomersByLocation(String location) throws ResourceNotFoundException;
	Customer viewCustomer(Customer customer) throws ResourceNotFoundException;
}
