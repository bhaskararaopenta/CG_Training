package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;

import org.springframework.stereotype.Component;

import com.cg.bean.Employee;
import com.cg.bean.Student;

@Component
public class Test implements CommandLineRunner {

	@Autowired
	private Employee emp;
	@Autowired
	private Student st;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		System.out.println("details are :");
		System.out.println(emp.getEmpId() + " " + emp.getEmpName() + " " + emp.getEmpSal());
		System.out.println(st.getStuId() + " " + st.getStuName() + " " + st.getStuAddr());
	}

}
