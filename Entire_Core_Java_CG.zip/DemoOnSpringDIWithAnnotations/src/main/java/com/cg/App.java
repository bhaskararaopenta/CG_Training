package com.cg;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.bean.Address;
import com.cg.bean.Employee;
import com.cg.config.SpringConfig;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		Employee e = context.getBean("emp", Employee.class);

		System.out.println("employee details are :-  ");
		System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getEmpSal());

		System.out.println();

		Address a = e.getAddress();
		System.out.println("Address details are :- ");
		System.out.println(a.getCity() + " " + a.getDistrict() + " " + a.getState());
	}
}
