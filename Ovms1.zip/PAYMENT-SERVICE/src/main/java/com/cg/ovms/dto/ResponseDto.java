package com.cg.ovms.dto;

import com.cg.ovms.entities.Payment;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class ResponseDto {

	private Booking booking;
	
	private Vehicle vehicle;
	
	private Payment payment ;
}
