import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FruitBasketUtility {
	private List<FruitBasket> fruitBasketList = new ArrayList<FruitBasket>();

	public List<FruitBasket> getFruitBasketList() {
		return fruitBasketList;
	}

	public void setFruitBasketList(List<FruitBasket> fruitBasketList) {
		this.fruitBasketList = fruitBasketList;
	}

	public void addToBasket(FruitBasket fbObj) {
		// Fill your code here
		fruitBasketList.add(fbObj);

	}

	public int calculateBill(Stream<FruitBasket> fruitBasketStream) { // apple 3 20 3*20 =60
																		// kiwi 3 20 3*20 =60

		Integer res = fruitBasketStream.map(e -> e.getWeightInKgs() * e.getPricePerKg())
				.collect(Collectors.summingInt(Integer::valueOf));
		return res;

//		int total = 0;
//		List<Integer> res = fruitBasketStream.map(e -> e.getWeightInKgs() * e.getPricePerKg()).toList();
//		for (Integer integer : res) {
//			total = integer + total;
//		}
//
//		return total;
	}

}
