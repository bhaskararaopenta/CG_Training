package com.cg.bean;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionDI {

	private List<String> prodNames;
	private Set<String> custNames;
	private Map<Integer, String> empIdName;

	public List<String> getProdNames() {
		return prodNames;
	}

	public void setProdNames(List<String> prodNames) {
		this.prodNames = prodNames;
	}

	public Set<String> getCustNames() {
		return custNames;
	}

	public void setCustNames(Set<String> custNames) {
		this.custNames = custNames;
	}

	public Map<Integer, String> getEmpIdName() {
		return empIdName;
	}

	public void setEmpIdName(Map<Integer, String> empIdName) {
		this.empIdName = empIdName;
	}

}
