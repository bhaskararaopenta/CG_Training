package com.training.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.dto.EmployeeForProject;
import com.training.dto.ProjectDTO;
import com.training.entity.Project;
import com.training.exception.BugTracking;
import com.training.repository.ProjectRepository;


@ExtendWith(MockitoExtension.class)
public class ProjectServiceImplTest {

    @Mock
    private ProjectRepository projectRepository;

    @InjectMocks
    private ProjectServiceImpl projectServiceImpl;

    @Test
    public void addProject() throws BugTracking {
        // Set up the test data
        List<EmployeeForProject> managers = new ArrayList<>();
        EmployeeForProject manager = new EmployeeForProject();
        manager.setEmpId(1L);
        manager.setEmpName("John Doe");
        manager.setEmail("john.doe@example.com");
        manager.setEmpContact("1234567890");
        managers.add(manager);

        ProjectDTO projectDTO = new ProjectDTO();
        projectDTO.setProjName("Test Project");
        projectDTO.setProjManager(managers);
        projectDTO.setProjStatus("Active");

        Project project = new Project();
        project.setProjId(1L);
        project.setProjName("Test Project");
        project.setProjManager(managers);
        project.setProjStatus("Active");

        when(projectRepository.save(any(Project.class))).thenReturn(project);

        ProjectDTO addedProject = projectServiceImpl.addProject(projectDTO);

        assertEquals(1L, addedProject.getProjId());
        assertEquals("Test Project", addedProject.getProjName());
        assertEquals(managers, addedProject.getProjManager());
        assertEquals("Active", addedProject.getProjStatus());
    }

    @Test
    public void deleteProject() throws BugTracking {
        // Set up the test data
        List<EmployeeForProject> managers = new ArrayList<>();
        EmployeeForProject manager = new EmployeeForProject();
        manager.setEmpId(1L);
        manager.setEmpName("John Doe");
        manager.setEmail("john.doe@example.com");
        manager.setEmpContact("1234567890");
        managers.add(manager);

        Project project = new Project();
        project.setProjId(1L);
        project.setProjName("Test Project");
        project.setProjManager(managers);
        project.setProjStatus("Active");

        when(projectRepository.findById(1L)).thenReturn(Optional.of(project));

        ProjectDTO deletedProject = projectServiceImpl.deleteProject(1L);

        assertEquals(1L, deletedProject.getProjId());
        assertEquals("Test Project", deletedProject.getProjName());
        assertEquals(managers, deletedProject.getProjManager());
        assertEquals("Active", deletedProject.getProjStatus());

        verify(projectRepository, times(1)).delete(project);
    }

    @Test
    public void getProject() throws BugTracking {
        // Set up the test data
        List<EmployeeForProject> managers = new ArrayList<>();
        EmployeeForProject manager = new EmployeeForProject();
        manager.setEmpId(1L);
        manager.setEmpName("John Doe");
        manager.setEmail("john.doe@example.com");
        manager.setEmpContact("1234567890");
        managers.add(manager);

        Project project = new Project();
        project.setProjId(1L);
        project.setProjName("Test Project");
        project.setProjManager(managers);
        project.setProjStatus("Active");

        when(projectRepository.findById(1L)).thenReturn(Optional.of(project));

        ProjectDTO projectDTO = projectServiceImpl.getProject(1L);

        assertEquals(1L, projectDTO.getProjId());
        assertEquals("Test Project", projectDTO.getProjName());
        assertEquals(managers, projectDTO.getProjManager());
        assertEquals("Active", projectDTO.getProjStatus());
    }

    @Test
    public void getAllProjects() throws BugTracking {
        // Set up the test data
        List<EmployeeForProject> managers1 = new ArrayList<>();
        EmployeeForProject manager1 = new EmployeeForProject();
        manager1.setEmpId(1L);
        manager1.setEmpName("John Doe");
        manager1.setEmail("john.doe@example.com");
        manager1.setEmpContact("1234567890");
        managers1.add(manager1);

        List<EmployeeForProject> managers2 = new ArrayList<>();
        EmployeeForProject manager2 = new EmployeeForProject();
        manager2.setEmpId(2L);
        manager2.setEmpName("Jane Doe");
        manager2.setEmail("jane.doe@example.com");
        manager2.setEmpContact("0987654321");
        managers2.add(manager2);

        Project project1 = new Project();
        project1.setProjId(1L);
        project1.setProjName("Project 1");
        project1.setProjManager(managers1);
        project1.setProjStatus("Active");

        Project project2 = new Project();
        project2.setProjId(2L);
        project2.setProjName("Project 2");
        project2.setProjManager(managers2);
        project2.setProjStatus("Inactive");

        List<Project> projects = new ArrayList<>();
        projects.add(project1);
        projects.add(project2);

        when(projectRepository.findAll()).thenReturn(projects);

        List<ProjectDTO> projectDTOs = projectServiceImpl.getAllProjects();

        assertEquals(2, projectDTOs.size());
        assertEquals(1L, projectDTOs.get(0).getProjId());
        assertEquals("Project 1", projectDTOs.get(0).getProjName());
        assertEquals(managers1, projectDTOs.get(0).getProjManager());
        assertEquals("Active", projectDTOs.get(0).getProjStatus());

        assertEquals(2L, projectDTOs.get(1).getProjId());
        assertEquals("Project 2", projectDTOs.get(1).getProjName());
        assertEquals(managers2, projectDTOs.get(1).getProjManager());
        assertEquals("Inactive", projectDTOs.get(1).getProjStatus());
    }

    @Test
    public void updateProject() throws BugTracking {
        // Set up the test data
        List<EmployeeForProject> managers = new ArrayList<>();
        EmployeeForProject manager = new EmployeeForProject();
        manager.setEmpId(1L);
        manager.setEmpName("John Doe");
        manager.setEmail("john.doe@example.com");
        manager.setEmpContact("1234567890");
        managers.add(manager);

        Project existingProject = new Project();
        existingProject.setProjId(1L);
        existingProject.setProjName("Existing Project");
        existingProject.setProjManager(managers);
        existingProject.setProjStatus("Active");

        List<EmployeeForProject> updatedManagers = new ArrayList<>();
        EmployeeForProject updatedManager = new EmployeeForProject();
        updatedManager.setEmpId(2L);
        updatedManager.setEmpName("Jane Doe");
        updatedManager.setEmail("jane.doe@example.com");
        updatedManager.setEmpContact("0987654321");
        updatedManagers.add(updatedManager);

        ProjectDTO projectDTO = new ProjectDTO();
        projectDTO.setProjName("Updated Project");
        projectDTO.setProjManager(updatedManagers);
        projectDTO.setProjStatus("Inactive");

        Project updatedProject = new Project();
        updatedProject.setProjId(1L);
        updatedProject.setProjName("Updated Project");
        updatedProject.setProjManager(updatedManagers);
        updatedProject.setProjStatus("Inactive");

        when(projectRepository.findById(1L)).thenReturn(Optional.of(existingProject));
        when(projectRepository.save(any(Project.class))).thenReturn(updatedProject);

        ProjectDTO updatedProjectDTO = projectServiceImpl.updateProject(1L, projectDTO);

        assertEquals(1L, updatedProjectDTO.getProjId());
        assertEquals("Updated Project", updatedProjectDTO.getProjName());
        assertEquals(updatedManagers, updatedProjectDTO.getProjManager());
        assertEquals("Inactive", updatedProjectDTO.getProjStatus());
    }
}

