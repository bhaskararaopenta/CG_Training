package com.day5.test2OnInterface;

public interface Shape {

	public double getArea();
}
