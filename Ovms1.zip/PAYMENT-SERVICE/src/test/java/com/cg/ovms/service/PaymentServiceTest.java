package com.cg.ovms.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.ovms.entities.Payment;
import com.cg.ovms.exception.ResourceNotFoundException;
import com.cg.ovms.repository.PaymentRepository;

class PaymentServiceImpTest {

    @Mock
    private PaymentRepository paymentRepository;

    @InjectMocks
    private PaymentServiceImp paymentService;

    private Payment payment;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        payment = new Payment();
        payment.setPaymentId(1);
        payment.setPaymentStatus("Completed");
        payment.setPaymentMode("CASH");
        payment.setPaymentDate(LocalDate.now());
        payment.setVehicleId(1);
        payment.setBookingId(1);
    }

    @Test
    void testAddPayment() {
        when(paymentRepository.save(any(Payment.class))).thenReturn(payment);
        Payment savedPayment = paymentService.addPayment(payment);
        assertNotNull(savedPayment);
        assertEquals(payment.getPaymentStatus(), savedPayment.getPaymentStatus());
    }

    @Test
    void testCancelPayment() {
        when(paymentRepository.findById(anyInt())).thenReturn(Optional.of(payment));
        Payment cancelledPayment = paymentService.cancelPayment(payment);
        assertNotNull(cancelledPayment);
        assertEquals("Cancelled", cancelledPayment.getPaymentStatus());
    }

    @Test
    void testCancelPayment_ThrowsException_WhenPaymentNotFound() {
        when(paymentRepository.findById(anyInt())).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> paymentService.cancelPayment(payment));
    }

    @Test
    void testViewByVehicleIdEquals() {
        when(paymentRepository.findByVehicleIdEquals(anyInt())).thenReturn(List.of(payment));
        List<Payment> payments = paymentService.viewByVehicleIdEquals(payment.getVehicleId());
        assertNotNull(payments);
        assertFalse(payments.isEmpty());
    }

    @Test
    void testViewByBookingIdEquals() {
        when(paymentRepository.findByBookingIdEquals(anyInt())).thenReturn(List.of(payment));
        List<Payment> payments = paymentService.viewByBookingIdEquals(payment.getBookingId());
        assertNotNull(payments);
        assertFalse(payments.isEmpty());
    }
}