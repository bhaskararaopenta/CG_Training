package com.day14.enumurations;

public enum EnumClass {
	RECTANGLE, SQUARE, CIRCLE, TRIANGLE
}
