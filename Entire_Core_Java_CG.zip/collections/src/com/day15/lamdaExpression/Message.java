package com.day15.lamdaExpression;

public class Message {

	public Message(String m) {
		// TODO Auto-generated method stub
		System.out.println("from msg class : "+m);
	}
}
