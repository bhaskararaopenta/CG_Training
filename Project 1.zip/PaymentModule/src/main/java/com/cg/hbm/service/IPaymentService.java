package com.cg.hbm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.hbm.entity.Payments;
import com.cg.hbm.exceptions.PaymentsNotFoundException;

@Service
public interface IPaymentService {
	public Payments addPayment(Payments payment) throws PaymentsNotFoundException;
	public Payments showPayment(int paymentId) throws PaymentsNotFoundException;
	public List<Payments> showAllPayments() throws PaymentsNotFoundException;

}
