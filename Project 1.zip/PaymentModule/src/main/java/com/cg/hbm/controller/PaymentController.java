package com.cg.hbm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.consumes.BookingFeignClient;
import com.cg.hbm.consumes.PaymentFeignClient;
import com.cg.hbm.dto.ResponseDTO;
import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.entity.Payments;
import com.cg.hbm.entity.Transactions;
import com.cg.hbm.exceptions.PaymentsNotFoundException;
import com.cg.hbm.service.IPaymentService;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private IPaymentService iPaymentService;

    @Autowired 
    private PaymentFeignClient paymentFeignClient;

    @Autowired
    private BookingFeignClient bookingFeignClient;

    // Add a new payment
    @PostMapping("/add")
    public Payments addPayment(@RequestBody Payments payment) throws PaymentsNotFoundException {
        return iPaymentService.addPayment(payment);
    }

    // Add a new payment with transaction details
    @PostMapping("/addDetails")
    public ResponseEntity<ResponseDTO> addPaymentWithTransaction(@RequestBody Payments payment) throws PaymentsNotFoundException {
        Payments newPayment = iPaymentService.addPayment(payment);
        int tid = newPayment.getTransactionId();
        // Call the Feign client to get transaction details
        Transactions td = paymentFeignClient.getTransaction(tid);
        BookingDetails booking = bookingFeignClient.getBooking(newPayment.getBookingId());
        ResponseDTO rdto = new ResponseDTO();
        rdto.setPayment(payment);
        rdto.setTransactions(td);
        rdto.setBookingDetails(booking);
        return new ResponseEntity<>(rdto, HttpStatus.OK);
    }

    // Get payment details by payment ID
    @GetMapping("/{paymentId}")
    public ResponseEntity<Payments> getPayment(@PathVariable("paymentId") int paymentId) throws PaymentsNotFoundException {
        Payments payment = iPaymentService.showPayment(paymentId);
        return new ResponseEntity<>(payment, HttpStatus.OK);
    }

    // Get transaction details by payment ID
    @GetMapping("/showdetails/{paymentId}")
    public ResponseEntity<ResponseDTO> getTransactionDetailsById(@PathVariable("paymentId") int paymentId) throws PaymentsNotFoundException {
        Payments payment = iPaymentService.showPayment(paymentId);
        int tid = payment.getTransactionId();
        // Call the Feign client to get transaction details
        Transactions td = paymentFeignClient.getTransaction(tid);
        BookingDetails booking = bookingFeignClient.getBooking(payment.getBookingId());
        ResponseDTO rdto = new ResponseDTO();
        rdto.setPayment(payment);
        rdto.setTransactions(td);
        rdto.setBookingDetails(booking);
        return new ResponseEntity<>(rdto, HttpStatus.OK);
    }

    // Get all payments
    @GetMapping("/showall")
    public ResponseEntity<List<Payments>> getAllPayments() throws PaymentsNotFoundException {
        List<Payments> payment = iPaymentService.showAllPayments();
        return new ResponseEntity<>(payment, HttpStatus.OK);
    }
}