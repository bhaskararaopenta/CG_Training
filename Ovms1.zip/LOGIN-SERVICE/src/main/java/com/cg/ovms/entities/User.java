package com.cg.ovms.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class User {

	@Id
	@NotBlank(message = "Userd must not be blank")
	@Pattern(regexp = "^[A-Za-z][A-Za-z@#$%^&*]{3,14}$", message = "UserId must be in the format: first alphabet, then alphabets and symbols with size between 4 and 15")
	private String userId;
	
	@NotBlank
	@Size(min = 4 , max = 20 , message = "The size of password must be between 4 and 20")
	private String password;
	
	@NotBlank(message = "Role is mandatory")
	@Pattern(regexp = "(?i)^(Admin|Customer)$", message = "Role must be either Admin or Customer")
	private String role;
}
