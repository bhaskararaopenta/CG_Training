package com.day20.threads;

public class DepositThread extends Thread {

	Bank b;
	int amount;

	public DepositThread(Bank b, int amount) {
		this.b = b;
		this.amount = amount;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		b.deposit(amount);
	}
}
