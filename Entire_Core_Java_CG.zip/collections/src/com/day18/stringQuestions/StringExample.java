package com.day18.stringQuestions;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input = sc.nextLine();
		String[] out = input.split(" ");
		String first = out[0];
		String two = out[1];
		// TODO Auto-generated method stub

		System.out.println(two + "," + first.charAt(0));

	}

}
