package com.training.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.dto.BugDTO;
import com.training.entity.Bug;
import com.training.exception.BugException;
import com.training.repository.BugRepository;
import com.training.service.IBugImplementation;

@ExtendWith(MockitoExtension.class)
public class IBugImplementationTest {

	@Mock
	private BugRepository bugRepository;

	@InjectMocks
	private IBugImplementation bugService;

	@Test
	public void createBug() throws BugException {
		// Set up test data
		BugDTO bugDTO = new BugDTO();
		bugDTO.setBugId(1L);
		bugDTO.setTitle("Bug Title");
		bugDTO.setDescription("Bug Description");
		bugDTO.setType("Bug Type");
		bugDTO.setPriority("High");
		bugDTO.setProgress(1); // Correctly setting as an integer (e.g., 1 for "In Progress")
		bugDTO.setStatus("Open");
		bugDTO.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		bugDTO.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		bugDTO.setProjectId(1L);
		bugDTO.setEmployeeId(1L);

		Bug bug = new Bug();
		bug.setBugId(1L);
		bug.setTitle("Bug Title");
		bug.setDescription("Bug Description");
		bug.setType("Bug Type");
		bug.setPriority("High");
		bug.setProgress(1); // Integer for progress
		bug.setStatus("Open");
		bug.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		bug.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		bug.setProjectId(1L);
		bug.setEmployeeId(1L);

		when(bugRepository.save(any(Bug.class))).thenReturn(bug);

		// Call method and assert results
		BugDTO createdBug = bugService.createBug(bugDTO);
		assertEquals(1L, createdBug.getBugId());
		assertEquals("Bug Title", createdBug.getTitle());
		assertEquals("Bug Description", createdBug.getDescription());
	}

	@Test
	public void updateBug() throws BugException {
		// Set up test data
		BugDTO bugDTO = new BugDTO();
		bugDTO.setBugId(1L);
		bugDTO.setTitle("Updated Bug Title");
		bugDTO.setDescription("Updated Bug Description");
		bugDTO.setType("Bug Type");
		bugDTO.setPriority("Low");
		bugDTO.setProgress(2); // Correctly setting as an integer (e.g., 2 for "Completed")
		bugDTO.setStatus("Closed");
		bugDTO.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		bugDTO.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		bugDTO.setProjectId(1L);
		bugDTO.setEmployeeId(1L);

		Bug existingBug = new Bug();
		existingBug.setBugId(1L);
		existingBug.setTitle("Bug Title");
		existingBug.setDescription("Bug Description");
		existingBug.setType("Bug Type");
		existingBug.setPriority("High");
		existingBug.setProgress(1); // Integer progress (In Progress)
		existingBug.setStatus("Open");
		existingBug.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		existingBug.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		existingBug.setProjectId(1L);
		existingBug.setEmployeeId(1L);

		Bug updatedBug = new Bug();
		updatedBug.setBugId(1L);
		updatedBug.setTitle("Updated Bug Title");
		updatedBug.setDescription("Updated Bug Description");
		updatedBug.setType("Bug Type");
		updatedBug.setPriority("Low");
		updatedBug.setProgress(2); // Updated progress to "Completed" (2)
		updatedBug.setStatus("Closed");
		updatedBug.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		updatedBug.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		updatedBug.setProjectId(1L);
		updatedBug.setEmployeeId(1L);

		when(bugRepository.findById(1L)).thenReturn(Optional.of(existingBug));
		when(bugRepository.save(any(Bug.class))).thenReturn(updatedBug);

		// Call method and assert results
		BugDTO updatedBugDTO = bugService.updateBug(1L, bugDTO);
		assertEquals(1L, updatedBugDTO.getBugId());
		assertEquals("Updated Bug Title", updatedBugDTO.getTitle());
		assertEquals("Updated Bug Description", updatedBugDTO.getDescription());
		assertEquals("Low", updatedBugDTO.getPriority());
		assertEquals(2, updatedBugDTO.getProgress()); // Checking progress 2 (Completed)
	}

	@Test
	public void getBug() throws BugException {
		// Set up test data
		Bug bug = new Bug();
		bug.setBugId(1L);
		bug.setTitle("Bug Title");
		bug.setDescription("Bug Description");
		bug.setType("Bug Type");
		bug.setPriority("High");
		bug.setProgress(1); // Integer for progress
		bug.setStatus("Open");
		bug.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		bug.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		bug.setProjectId(1L);
		bug.setEmployeeId(1L);

		when(bugRepository.findById(1L)).thenReturn(Optional.of(bug));

		// Call method and assert results
		BugDTO bugDTO = bugService.getBug(1L);
		assertEquals(1L, bugDTO.getBugId());
		assertEquals("Bug Title", bugDTO.getTitle());
		assertEquals("Bug Description", bugDTO.getDescription());
		assertEquals("High", bugDTO.getPriority());
	}

	@Test
	public void getAllBugs() throws BugException {
		// Set up test data
		Bug bug1 = new Bug();
		bug1.setBugId(1L);
		bug1.setTitle("Bug Title 1");
		bug1.setDescription("Bug Description 1");
		bug1.setType("Bug Type");
		bug1.setPriority("High");
		bug1.setProgress(1); // Integer for progress
		bug1.setStatus("Open");
		bug1.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		bug1.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		bug1.setProjectId(1L);
		bug1.setEmployeeId(1L);

		Bug bug2 = new Bug();
		bug2.setBugId(2L);
		bug2.setTitle("Bug Title 2");
		bug2.setDescription("Bug Description 2");
		bug2.setType("Bug Type");
		bug2.setPriority("Medium");
		bug2.setProgress(1); // Integer for progress
		bug2.setStatus("Open");
		bug2.setStartDate(LocalDate.of(2024, 11, 21)); // Set as LocalDate
		bug2.setEndDate(LocalDate.of(2024, 12, 1)); // Set as LocalDate
		bug2.setProjectId(1L);
		bug2.setEmployeeId(2L);

		List<Bug> bugs = new ArrayList<>();
		bugs.add(bug1);
		bugs.add(bug2);

		when(bugRepository.findAll()).thenReturn(bugs);

		// Call method and assert results
		List<BugDTO> bugDTOs = bugService.getAllBugs();
		assertEquals(2, bugDTOs.size());
		assertEquals("Bug Title 1", bugDTOs.get(0).getTitle());
		assertEquals("Bug Title 2", bugDTOs.get(1).getTitle());
	}

	@Test
	public void deleteBug() throws BugException {
		// Set up test data
		Bug bug = new Bug();
		bug.setBugId(1L);
		bug.setTitle("Bug Title");
		bug.setDescription("Bug Description");
		bug.setType("Bug Type");
		bug.setPriority("High");
		bug.setProgress(1); // Integer for progress
		bug.setStatus("Open");
		bug.setStartDate(LocalDate.of(2024, 11, 20)); // Set as LocalDate
		bug.setEndDate(LocalDate.of(2024, 11, 30)); // Set as LocalDate
		bug.setProjectId(1L);
		bug.setEmployeeId(1L);

		when(bugRepository.findById(1L)).thenReturn(Optional.of(bug));

		// Call method
		bugService.deleteBug(1L);

		// Verify that the repository's deleteById method was called
		verify(bugRepository, times(1)).deleteById(1L); // Corrected method call
	}

}
