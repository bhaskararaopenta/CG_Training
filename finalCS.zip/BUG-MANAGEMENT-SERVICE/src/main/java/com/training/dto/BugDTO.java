package com.training.dto;

import java.time.LocalDate;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;


public class BugDTO {

	private Long bugId;
	
	@NotNull(message = "Title cannot be null")
    @Size(min = 3, max = 100, message = "Title must be between 3 and 100 characters")
	private String title;
	@NotNull(message = "Description cannot be null")
    @Size(min = 10, max = 1000, message = "Description must be between 10 and 1000 characters")
	private String description;
	@NotNull(message = "Type cannot be null")
    @Size(min = 3, max = 50, message = "Type must be between 3 and 50 characters")
	private String type;
    @NotNull(message = "Priority cannot be null")
	private String priority;
    @Min(value = 0, message = "Progress cannot be less than 0")
    @Max(value = 100, message = "Progress cannot be more than 100")
	private Integer progress;
    //FK
	//private Employee assignee;
    @NotNull(message = "Status cannot be null")
	private String status;
    @NotNull(message = "Start Date cannot be null")
	private LocalDate startDate;
	private LocalDate endDate;
   private Long projectId;
   private Long employeeId;
   
   
   
   
	public BugDTO() {
	super();
	// TODO Auto-generated constructor stub
}
	public Long getProjectId() {
	return projectId;
}
public void setProjectId(Long projectId) {
	this.projectId = projectId;
}
public Long getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(Long employeeId) {
	this.employeeId = employeeId;
}
	public Long getBugId() {
		return bugId;
	}
	public void setBugId(Long bugId) {
		this.bugId = bugId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public Integer getProgress() {
		return progress;
	}
	public void setProgress(Integer progress) {
		this.progress = progress;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	

	@Override
public String toString() {
	return "BugDTO [bugId=" + bugId + ", title=" + title + ", description=" + description + ", type=" + type
			+ ", priority=" + priority + ", progress=" + progress + ", status=" + status + ", startDate=" + startDate
			+ ", endDate=" + endDate + ", projectId=" + projectId + ", employeeId=" + employeeId + "]";
}
	
}
