package com.cg.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ExampleOnMetaData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		

		/*
		 * Class.forName("com.mysql.cj.jdbc.Driver");
		 * 
		 * String url = "jdbc:mysql://localhost:3306/batch2"; String uname = "root";
		 * String pwd = "root";
		 * 
		 * Connection con = DriverManager.getConnection(url, uname, pwd);
		 */

		Connection con = DBUtil.getMySQLConnection();
		DatabaseMetaData dbmdata = con.getMetaData();
		System.out.println(dbmdata.getDriverMajorVersion());
		System.out.println(dbmdata.getDatabaseMajorVersion());
		System.out.println(dbmdata.getDriverVersion());
		System.out.println(dbmdata.getDriverName());
		Statement st = con.createStatement();
		String query="select * from dept";
		ResultSet rs = st.executeQuery(query);
		ResultSetMetaData rmdata = rs.getMetaData();
		System.out.println("no of columns count :"+rmdata.getColumnCount());
		
		System.out.println("column name and its datatype");
		
		for (int i = 1; i <=rmdata.getColumnCount(); i++) {
			System.out.println(rmdata.getColumnName(i)+" "+ rmdata.getColumnTypeName(i));
		}
		
	}

}
