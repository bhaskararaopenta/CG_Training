package com.cg.ovms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entities.Driver;
import com.cg.ovms.exception.DriverNotFoundException;
import com.cg.ovms.repository.DriverRepository;

@Service
public class DriverServiceImpl implements DriverService {

    @Autowired
    private DriverRepository driverRepository;

    @Override
    public Driver addDriver(Driver driver) {
        return driverRepository.save(driver);
    }

    @Override
    public Driver updateDriver(Driver driver) throws DriverNotFoundException {
        Optional<Driver> existingDriver = driverRepository.findById(driver.getDriverId());
        if (existingDriver.isPresent()) {
            return driverRepository.save(driver);
        } else {
            throw new DriverNotFoundException("Driver not found with id: " + driver.getDriverId());
        }
    }

    @Override
    public void deleteDriver(int driverId) {
        driverRepository.deleteById(driverId);
    }

    @Override
    public Driver findById(int driverId) throws DriverNotFoundException {
        return driverRepository.findById(driverId)
                .orElseThrow(() -> new DriverNotFoundException("Driver not found with id: " + driverId));
    }

    @Override
    public List<Driver> findAllDriver() {
        return driverRepository.findAll();
    }

    @Override
    public Driver findByVehicleId(int vehicleId) {
        return driverRepository.findByVehicleIdEquals(vehicleId);
    }
}