package com.cg.ovms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.cg.ovms.entities.User;
import com.cg.ovms.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

public class UserServiceImpTest {

	@Mock
	private UserRepository userRepository;
	
	@Mock
	private PasswordEncoder passwordEncoder;
	
	@Mock
	private HttpSession httpSession;
	
	@InjectMocks
	private UserServiceImp userService;
	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void testAddUser() {
		 User user = new User();
	        user.setUserId("testUser");
	        user.setPassword("password");
	        user.setRole("CUSTOMER");

	        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
	        when(userRepository.save(any(User.class))).thenReturn(user);

	        User result = userService.addUser(user);

	        assertNotNull(result);
	        assertEquals("encodedPassword", result.getPassword());
	        verify(userRepository, times(1)).save(user);
	    }

	    @Test
	    void testLoginUser_Success() throws Exception {
	        User user = new User();
	        user.setUserId("testUser");
	        user.setPassword("encodedPassword");
	        user.setRole("CUSTOMER");

	        when(userRepository.findById("testUser")).thenReturn(Optional.of(user));
	        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(true);

	        String result = userService.loginUser("testUser", "password");

	        assertEquals("Redirecting to the Customer Service Module.", result);
	    }

	    @Test
	    void testLoginUser_InvalidPassword() {
	        User user = new User();
	        user.setUserId("testUser");
	        user.setPassword("encodedPassword");
	        user.setRole("CUSTOMER");

	        when(userRepository.findById("testUser")).thenReturn(Optional.of(user));
	        when(passwordEncoder.matches(anyString(), anyString())).thenReturn(false);

	        Exception exception = assertThrows(Exception.class, () -> {
	            userService.loginUser("testUser", "password");
	        });

	        assertEquals("Invalid password", exception.getMessage());
	    }

	    @Test
	    void testLoginUser_UserNotFound() {
	        when(userRepository.findById("testUser")).thenReturn(Optional.empty());

	        Exception exception = assertThrows(Exception.class, () -> {
	            userService.loginUser("testUser", "password");
	        });

	        assertEquals("User Not Found", exception.getMessage());
	    }

	    @Test
	    void testRemoveUser() {
	        doNothing().when(userRepository).deleteById("testUser");

	        String result = userService.removeUser("testUser");

	        assertEquals("Successfully deleted", result);
	        verify(userRepository, times(1)).deleteById("testUser");
	    }

	    @Test
	    void testSignOut() {
	        doNothing().when(httpSession).invalidate();

	        String result = userService.signOut();

	        assertEquals("You are Signed Out", result);
	        verify(httpSession, times(1)).invalidate();
	    }

	    @Test
	    void testFindByUserId() {
	        User user = new User();
	        user.setUserId("testUser");

	        when(userRepository.findById("testUser")).thenReturn(Optional.of(user));

	        Optional<User> result = userService.findByUserId("testUser");

	        assertTrue(result.isPresent());
	        assertEquals("testUser", result.get().getUserId());
	    }
	}