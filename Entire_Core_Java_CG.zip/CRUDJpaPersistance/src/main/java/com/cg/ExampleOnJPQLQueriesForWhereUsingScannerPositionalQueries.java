package com.cg;

import java.util.List;
import java.util.Scanner;

import com.cg.model.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class ExampleOnJPQLQueriesForWhereUsingScannerPositionalQueries {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value to search");
		String name = sc.next();
		EntityManagerFactory emfty = Persistence.createEntityManagerFactory("bhaskar");
		EntityManager em = emfty.createEntityManager();

		String query = "select s from com.cg.model.Student s where s.studentName=?1";

		Query qobj = em.createQuery(query);
		qobj.setParameter(1, name);
		List<Student> ls = qobj.getResultList();

		for (Student st : ls) {
			System.out.println(st.getStudentId() + " " + st.getStudentName() + " " + st.getAddress());
		}

		em.close();
	}

}
