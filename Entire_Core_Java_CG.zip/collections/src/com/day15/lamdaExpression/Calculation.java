package com.day15.lamdaExpression;

public class Calculation {

	public static int getSum(int a, int b) {
		return a + b;
	}
}
