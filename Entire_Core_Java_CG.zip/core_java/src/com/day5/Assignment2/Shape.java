package com.day5.Assignment2;

public abstract class Shape {

	public abstract double calculateArea();
	
	public abstract double calculatePerimeter();
}
