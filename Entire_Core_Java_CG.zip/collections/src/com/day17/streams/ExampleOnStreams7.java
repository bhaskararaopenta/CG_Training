package com.day17.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams7 {

	public static void main(String[] args) {

		List<String> al = new ArrayList();
		al.add("smith");
		al.add("rakesh");
		al.add("allen");
		al.add("banu");
		al.add("jack");

		System.out.println("no of elkements is list :" + al.size());
		System.out.println(al);

		// printing in ascending order

		Stream<String> st2 = al.stream();
		st2.filter(e -> e.length() > 4).sorted().forEach(System.out::println);

	}

}
