package com.cg;


import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.cg.dto.BookDTO;
import com.cg.service.BookService;


@SpringBootApplication
public class SpringBootDataJpaQueryExercise1Application  implements CommandLineRunner{
	
	private static final String GENERAL_ERROR = "Some exception occured.Please check the code.";
	
	@Autowired
	Environment environment;
	@Autowired
	BookService bookService;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootDataJpaQueryExercise1Application.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		//getBookDetails();
		//addBook();
		//getBookByAuthorName();
		//getBookGreaterThanEqualToPrice();
		//getBookLessThanPrice();
		//bookPublishedBetweenYear();
		bookPublishedAfterYear();
		//getBookByAuthorNameAndPublisher();
		//updateBookPrice();
		//deleteBook();
	}

	public void getBookDetails() {
		try {

			// Input= BookId
			BookDTO bookdto = bookService.getBookDetails(1001);

			System.out.println(bookdto);

		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(),GENERAL_ERROR));

		}
	}

	public void addBook() {
		try {
			BookDTO bookdto = new BookDTO();
			bookdto.setBookId(1010);
			bookdto.setTitle("The Da Vinci Code");
			bookdto.setAuthorName("Dan Brown");
			bookdto.setPublishedYear(LocalDate.of(2003, 04, 18));
			bookdto.setPublisher("Doubleday");
			bookdto.setIsbn(1456987609875l);
			bookdto.setPrice(980);

			bookService.addBook(bookdto);
			System.out.println("\n" + environment.getProperty("UserInterface.INSERT_SUCCESS")+bookdto.getTitle());

		} catch (Exception e) {

			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}

	public void getBookByAuthorName() {
		try {
			String authorName = "Nicholas Sparks";
			List<BookDTO> bookDTOs = bookService.getBookByAuthorName(authorName);
			System.out.println("\n");
			bookDTOs.forEach(t -> System.out.println(t));

		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}

	public void getBookGreaterThanEqualToPrice() {
		try {
			Integer price = 700;
			List<BookDTO> bookDTOs = bookService.getBookGreaterThanEqualToPrice(price);
			System.out.println("\n");
			bookDTOs.forEach(t -> System.out.println(t));

		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}

	public void getBookLessThanPrice() {
		try {
			Integer price = 600;
			List<BookDTO> bookDTOs = bookService.getBookLessThanPrice(price);
			System.out.println("\n");
			bookDTOs.forEach(t -> System.out.println(t));

		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}

	public void bookPublishedBetweenYear() {
		try {
			LocalDate startYear = LocalDate.of(1990, 12, 22);
			LocalDate endYear = LocalDate.of(2000, 12, 22);
			List<BookDTO> bookDTOs = bookService.bookPublishedBetweenYear(startYear, endYear);
			System.out.println("\n");
			bookDTOs.forEach(t -> System.out.println(t));
		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));
		}
	}

	public void bookPublishedAfterYear() {
		try {
			LocalDate year = LocalDate.of(2000, 12, 22);

			List<BookDTO> bookDTOs = bookService.bookPublishedAfterYear(year);
			System.out.println("\n");
			bookDTOs.forEach(t-> System.out.println(t));

		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}

	public void getBookByAuthorNameAndPublisher() {
		try {
			String authorName = "Amish Tripathi";
			String publisher = "Westland Press";
			List<BookDTO> bookDTOs = bookService.getBookByAuthorNameAndPublisher(authorName, publisher);
			System.out.println("\n");
			bookDTOs.forEach(t-> System.out.println(t));
		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));
		}
	}

	public void updateBookPrice() {
		try {

			Integer bookId = 1005;
			Integer price = 850;

			bookService.updateBookPrice(bookId, price);
			System.out.println("\n" + environment.getProperty("UserInterface.UPDATE_SUCCESS"));

		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}

	public void deleteBook() {
		try {

			bookService.deleteBook(1005);
			System.out.println("\n" + environment.getProperty("UserInterface.DELETE_SUCCESS"));
		} catch (Exception e) {
			System.out.println("\n" + environment.getProperty(e.getMessage(), GENERAL_ERROR));

		}
	}


}
