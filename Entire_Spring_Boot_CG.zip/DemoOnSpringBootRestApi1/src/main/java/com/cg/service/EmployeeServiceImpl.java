package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.repo.EmployeeRepository;
import com.cg.restcontroller.EmployeeController;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	

	@Override
	public void insertEmployee(Employee e) {
		employeeRepository.save(e);
	}

}
