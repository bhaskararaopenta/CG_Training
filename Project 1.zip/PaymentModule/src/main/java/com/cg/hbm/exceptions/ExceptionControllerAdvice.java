package com.cg.hbm.exceptions;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.hbm.exceptions.ErrorInfo;

@ControllerAdvice
public class ExceptionControllerAdvice {

	    @Autowired
	    private Environment environment;

	    @ExceptionHandler(Exception.class)
		public ResponseEntity<ErrorInfo> exceptionHandler(Exception exception) {
			ErrorInfo error = new ErrorInfo();
			error.setErrorMessage(environment.getProperty("General.EXCEPTION_MESSAGE"));
			System.out.println(exception.getMessage());
			error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			error.setTimestamp(LocalDateTime.now());
			return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		/*
		 * @ExceptionHandler(PaymentsNotFoundException.class) public
		 * ResponseEntity<ErrorInfo> (PaymentsNotFoundException exception) { ErrorInfo
		 * error = new ErrorInfo();
		 * error.setErrorMessage(environment.getProperty(exception.getMessage()));
		 * error.setTimestamp(LocalDateTime.now());
		 * error.setErrorCode(HttpStatus.NOT_FOUND.value()); return new
		 * ResponseEntity<>(error, HttpStatus.NOT_FOUND); }
		 * 
		 * @ExceptionHandler(MethodArgumentNotValidException.class) public
		 * ResponseEntity<ErrorInfo> MethodArgumentNotValidException
		 * (MethodArgumentNotValidException exception) { ErrorInfo error = new
		 * ErrorInfo();
		 * //error.setErrorMessage(environment.getProperty(exception.getMessage()));
		 * error.setTimestamp(LocalDateTime.now());
		 * error.setErrorCode(HttpStatus.NOT_FOUND.value()); String msg =
		 * exception.getBindingResult().getAllErrors().stream().map(x->x.
		 * getDefaultMessage()) .collect(Collectors.joining(","));
		 * error.setErrorMessage(msg);
		 * 
		 * return new ResponseEntity<ErrorInfo>(error, HttpStatus.NOT_FOUND); }
		 */
		
	    @ExceptionHandler(PaymentsNotFoundException.class)
		public ResponseEntity<ErrorInfo> paymentsNotFoundExceptionHandler(PaymentsNotFoundException exception) {
			ErrorInfo error = new ErrorInfo();
			error.setErrorMessage(environment.getProperty(exception.getMessage()));
			error.setTimestamp(LocalDateTime.now());
			error.setErrorCode(HttpStatus.NOT_FOUND.value());
			return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
		}
	    
		 
	    @ExceptionHandler(MethodArgumentNotValidException.class)
		public ResponseEntity<ErrorInfo> methodargumentNotValidException (MethodArgumentNotValidException  exception) {
			ErrorInfo error = new ErrorInfo();
	 
			error.setTimestamp(LocalDateTime.now());
			error.setErrorCode(HttpStatus.NOT_FOUND.value());
			String msg = exception.getBindingResult().getAllErrors().stream().map(x->x.getDefaultMessage())
					.collect(Collectors.joining(","));
			error.setErrorMessage(msg);
			return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
		}
	}

