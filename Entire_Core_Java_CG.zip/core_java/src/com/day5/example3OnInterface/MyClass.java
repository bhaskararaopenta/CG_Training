package com.day5.example3OnInterface;

public class MyClass {
	public void m1() {
		System.out.println("we are in m1 method");
	}
	
	public int addition(int x,int y) {
		return x+y;
	}
}
