package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.entity.Product;

public interface IProductService {

	public int insertProduct(Product p);

	public Optional<Product> searchById(int id);

	public List<Product> getAllProductDetails();

	public void productDeleteById(int id);

	public int updateProduct(Product p);

	public Optional<Product> searchByProdName(String prodName);

	public List<Product> searchProductsByProdName(String ProdName);

	public List<Product> searchProductsByProdNameThirdWay(String prodName);

}
