import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the username");
		String input = sc.next();

		if (checkingUserInput(input)) {
			String res = password(input);
			System.out.println("Password :" + res);
		} else {
			System.out.println(input + "is an invalid username");
		}

	}

	private static String password(String input) {
		String s = "";
		String last = input.substring(6);
		int sum = 0;
 
		String firstSubstring = input.substring(0, 4).toLowerCase();
		for (int i = 0; i < firstSubstring.length(); i++) {
			sum = sum + (int) firstSubstring.charAt(i);
		}
 
		s = "TECH_" + sum + last;
		// TODO Auto-generated method stub
		return s;
	}

	public static boolean checkingUserInput(String input) {
		String firstFour = input.substring(0, 4);
		char fivee = input.charAt(4);
		String last = input.substring(6);
		int lastRes = Integer.parseInt(last);
		if (input.length() != 8) {
			return false;
		} else if (!firstFour.matches("[A-Z]{4}")) {
			return false;
		} else if (fivee != '@') {
			return false;
		} else if (lastRes < 101 || lastRes > 115) {
			return false;
		} else {
			// TODO Auto-generated method stub
			return true;
		}
	}
}
