package com.day20.threads;

public class Thread2 {

	public static void main(String[] args) { // Single Thread Model
		// TODO Auto-generated method stub]

		Thread t = Thread.currentThread();
		System.out.println("current thread is :" + t);
		System.out.println("current thread name is :" + t.getName());
		System.out.println("Current thread priority is  :" + t.getPriority()); // 5
		System.out.println("hi");
	}

}
