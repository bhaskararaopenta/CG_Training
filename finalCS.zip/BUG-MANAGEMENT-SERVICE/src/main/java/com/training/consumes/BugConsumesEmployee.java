package com.training.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.training.dto.EmployeeDTO;



@FeignClient(name = "Employee-Module")
public interface BugConsumesEmployee {
	
	@GetMapping("/employee/get/{id}")//http://
	public EmployeeDTO bugConsumesEmplyoeeById(@PathVariable Long id);

}
