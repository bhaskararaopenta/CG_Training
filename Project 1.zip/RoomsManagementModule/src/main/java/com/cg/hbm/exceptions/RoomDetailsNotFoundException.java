package com.cg.hbm.exceptions;

public class RoomDetailsNotFoundException extends Exception {

	public RoomDetailsNotFoundException(String message) {
		super(message);
	
	}
	
	
	

}
