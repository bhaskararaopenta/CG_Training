package com.day4.inheritance;


// this class refers to single inheritance
public class Animal {

	public void eat() {
		System.out.println("animal eats food");
	}
}
