 package com.cg.ovms.entities;

import java.time.LocalDate;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingId;
    
	@Positive
	private int  customerId;
	@Positive
    private int vehicleId;
	@Positive
    private int driverId;
	
	@NotBlank
	@FutureOrPresent(message = "Booking date must be presnt aor future date only")
    private LocalDate bookingDate;
	
	@NotEmpty
	@Future(message = "Here date should be Future")
    private LocalDate bookedTillDate;
	@NotBlank
	@Size(min = 5,max =  40)
    private String bookingDescription;
	
	@Positive(message = "Total cost must be Positive")
    private double totalCost;
	
	@Positive(message = "Distance must be positive")
    private double distance;
	
	
	@Pattern(regexp = "(?i)^(true|false)$", message = "Must be true or false")
	private boolean delivery;
}
