package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import com.cg.hbm.entity.Transactions;
import com.cg.hbm.exceptions.TransactionsNotFoundException;

public interface ITransactionService {

    // Add a new transaction
    public Transactions addTransaction(Transactions transaction);

    // Show a specific transaction by ID
    public Transactions showTransaction(int transactionId) throws TransactionsNotFoundException;

    // Show all transactions
    public List<Transactions> showAllTransactions() throws TransactionsNotFoundException;
}