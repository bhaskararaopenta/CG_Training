package com.day20.threads;

public class InterThreadCommunication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Bank b = new Bank();

		WithdrawThread wt = new WithdrawThread(b, 30000);
		wt.start();

		DepositThread dt = new DepositThread(b, 10000);
		dt.start();

	}

}
