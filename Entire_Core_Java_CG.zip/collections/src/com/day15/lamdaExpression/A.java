package com.day15.lamdaExpression;

public class A implements XYZ {

	@Override
	public void m1() {
		System.out.println("we are in methodOne of A class");
	}

	@Override
	public void m2() {
		System.out.println("we are in methodTwo of A class");
	}

}
