package com.day5.Assignment3;

public abstract class BankAccount {

	public abstract double deposit(double amount);
	
	public abstract double withdraw(double amount);
}
