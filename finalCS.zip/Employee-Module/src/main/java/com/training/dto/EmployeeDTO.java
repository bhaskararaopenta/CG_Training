package com.training.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class EmployeeDTO {

	private Long empId;
	@NotNull(message = "Employee name cannot be null")
    @Pattern(regexp = "[A-Za-z\\s]+", message = "Employee name should not contain numbers")
	private String empName;
	@Email(message = "Invalid email format")
    @NotNull(message = "Email cannot be null")
	private String email;
	@Pattern(regexp = "\\d{10}", message = "Contact number should be 10 digits")
	private String empContact;
	private Long projId;
	
	

	public Long getProjId() {
		return projId;
	}

	public void setProjId(Long projId) {
		this.projId = projId;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmpContact() {
		return empContact;
	}

	public void setEmpContact(String empContact) {
		this.empContact = empContact;
	}

	@Override
	public String toString() {
		return "EmployeeDTO [empId=" + empId + ", empName=" + empName + ", email=" + email + ", empContact="
				+ empContact + "]";
	}

}
