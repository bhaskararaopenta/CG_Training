package com.cg.hbm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.hbm.entity.RoomDetails;
import com.cg.hbm.exceptions.RoomDetailsNotFoundException;
@Service
public interface IRoomDetailsService {
	
	public RoomDetails addRoomDetails(RoomDetails roomDetails) throws  RoomDetailsNotFoundException ;
	public RoomDetails updateRoomDetails(RoomDetails roomDetails) throws  RoomDetailsNotFoundException ;
	public RoomDetails removeRoomDetails(RoomDetails roomDetails) throws  RoomDetailsNotFoundException ;
	public List<RoomDetails> showAllRoomDetails() throws  RoomDetailsNotFoundException ;
	public RoomDetails showRoomDetails(int roomDetails_id) throws  RoomDetailsNotFoundException ;

}
