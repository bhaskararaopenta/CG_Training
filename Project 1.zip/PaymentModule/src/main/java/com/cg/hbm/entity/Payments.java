package com.cg.hbm.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="payment_tab")
@Setter
@Getter
public class Payments {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer paymentId; // Unique identifier for the payment

    private int bookingId; // Identifier for the associated booking

    private int transactionId; // Identifier for the associated transaction
}