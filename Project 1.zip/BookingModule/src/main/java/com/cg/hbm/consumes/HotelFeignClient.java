package com.cg.hbm.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.cg.hbm.entites.Hotel;

@FeignClient(name ="HotelModule") // Assuming the hotel service runs on port 2021
public interface HotelFeignClient {

    @GetMapping("/api/hotels/{hotelId}")
    Hotel getHotelById(@PathVariable("hotelId") int hotelId);
    
	
}
