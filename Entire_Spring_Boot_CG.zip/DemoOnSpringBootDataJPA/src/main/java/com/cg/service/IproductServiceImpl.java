package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Product;
import com.cg.repo.ProductRepository;

@Service
public class IproductServiceImpl implements IProductService {

	@Autowired
	private ProductRepository repository;

	@Override
	public int insertProduct(Product p) {
		// TODO Auto-generated method stub
		Product pobj = repository.save(p); // calling save method from jpa repository
		return pobj.getProdId();
	}

	@Override
	public Optional<Product> searchById(int id) {
		// TODO Auto-generated method stub

		Optional<Product> res = repository.findById(id);
		return res;
	}

	@Override
	public List<Product> getAllProductDetails() {
		// TODO Auto-generated method stub

		List<Product> res = repository.findAll();
		return res;
	}

	@Override
	public void productDeleteById(int id) {
		// TODO Auto-generated method stub

		Optional<Product> pdel = searchById(id);

		if (pdel.isEmpty()) {
			System.out.println("record not exist");
		} else {
			repository.deleteById(id);
		}

	}

	@Override
	public int updateProduct(Product p) {
		Product pobj = null;
		// TODO Auto-generated method stub
		Optional<Product> pdel = searchById(p.getProdId());

		if (pdel.isEmpty()) {
			System.out.println("record not exist");
		} else {
			pobj = repository.save(p);
		}
		return pobj.getProdId();
	}

	@Override
	public Optional<Product> searchByProdName(String prodName) {
		// TODO Auto-generated method stub
		Optional<Product> optpro = repository.findByProdName(prodName);
		return optpro;
	}

	@Override
	public List<Product> searchProductsByProdName(String ProdName) {
		// TODO Auto-generated method stub
		List<Product> res = repository.findProdNameByName(ProdName);
		return res;
	}

	@Override
	public List<Product> searchProductsByProdNameThirdWay(String prodName) {
		// TODO Auto-generated method stub
		List<Product> res = repository.findProductNameByNameThird(prodName);
		return res;
	}

}
