package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hbm.entity.Transactions;
import com.cg.hbm.exceptions.TransactionsNotFoundException;
import com.cg.hbm.repository.ITransactionRepository;

@Service
public class ITransactionServiceImpl implements ITransactionService {

    @Autowired
    private ITransactionRepository transactionRepository;

    // Add a new transaction
    @Override
    public Transactions addTransaction(Transactions transaction) {
        return transactionRepository.save(transaction);
    }

    // Show a specific transaction by ID
    @Override
    public Transactions showTransaction(int transactionId) throws TransactionsNotFoundException {
        Optional<Transactions> get = transactionRepository.findById(transactionId);
        Transactions details = get.orElseThrow(() -> new TransactionsNotFoundException("No Transaction found."));
        return details;
    }

    // Show all transactions
    @Override
    public List<Transactions> showAllTransactions() throws TransactionsNotFoundException {
        return transactionRepository.findAll();
    }
}