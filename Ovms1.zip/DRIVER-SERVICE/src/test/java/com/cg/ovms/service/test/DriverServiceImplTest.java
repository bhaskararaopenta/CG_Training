package com.cg.ovms.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.ovms.entities.Driver;
import com.cg.ovms.repository.DriverRepository;
import com.cg.ovms.service.DriverServiceImpl;

class DriverServiceImplTest {

    @Mock
    private DriverRepository driverRepository;

    @InjectMocks
    private DriverServiceImpl driverService;

    private Driver driver;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        driver = new Driver();
        driver.setDriverId(1);
        driver.setFirstName("John");
        driver.setLastName("Doe");
        driver.setAddress("123 Street");
        driver.setMobileNumber("1234567890");
        driver.setEmailId("john.doe@example.com");
        driver.setLicenseNo("ABC12345");
        driver.setVehicleId(1);
    }

    @Test
    void testAddDriver() {
        when(driverRepository.save(any(Driver.class))).thenReturn(driver);
        Driver savedDriver = driverService.addDriver(driver);
        assertNotNull(savedDriver);
        assertEquals(driver.getFirstName(), savedDriver.getFirstName());
    }

    @Test
    void testUpdateDriver() {
        when(driverRepository.findById(anyInt())).thenReturn(Optional.of(driver));
        when(driverRepository.save(any(Driver.class))).thenReturn(driver);
        Driver updatedDriver = driverService.updateDriver(driver);
        assertNotNull(updatedDriver);
        assertEquals(driver.getFirstName(), updatedDriver.getFirstName());
    }

    @Test
    void testDeleteDriver() {
        doNothing().when(driverRepository).deleteById(anyInt());
        driverService.deleteDriver(driver.getDriverId());
        verify(driverRepository, times(1)).deleteById(driver.getDriverId());
    }

    @Test
    void testFindById() {
        when(driverRepository.findById(anyInt())).thenReturn(Optional.of(driver));
        Driver foundDriver = driverService.findById(driver.getDriverId());
        assertNotNull(foundDriver);
        assertEquals(driver.getFirstName(), foundDriver.getFirstName());
    }

    @Test
    void testFindAllDriver() {
        when(driverRepository.findAll()).thenReturn(List.of(driver));
        List<Driver> drivers = driverService.findAllDriver();
        assertNotNull(drivers);
        assertFalse(drivers.isEmpty());
    }

    @Test
    void testFindByVehicleId() {
        when(driverRepository.findByVehicleIdEquals(anyInt())).thenReturn(driver);
        Driver foundDriver = driverService.findByVehicleId(driver.getVehicleId());
        assertNotNull(foundDriver);
        assertEquals(driver.getFirstName(), foundDriver.getFirstName());
    }
}