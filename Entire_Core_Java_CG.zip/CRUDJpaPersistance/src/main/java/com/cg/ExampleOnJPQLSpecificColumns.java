package com.cg;

import java.util.List;

import com.cg.model.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class ExampleOnJPQLSpecificColumns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory emfty = Persistence.createEntityManagerFactory("bhaskar");
		EntityManager em = emfty.createEntityManager();

		String query = "select s.studentId,s.studentName from com.cg.model.Student s";

		Query qobj = em.createQuery(query);

		List<Object[]> ls = qobj.getResultList();

		for (Object[] ob : ls) {
			System.out.println(ob[0] + " " + ob[1]);
		}
	}

}
