package com.cg.repository;



import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.dto.BookDTO;
import com.cg.entity.Book;

public interface BookRepository extends JpaRepository<Book, Integer> {
     
	List<Book> getBookByAuthorName(String authorName);
	@Query("select b from Book b where b.price>=:price")
	List<Book> getBookGreaterThanEqualToPrice(@Param("price") int price);
	@Query("select b from Book b where b.price <:price")
	List<Book> getBookLessThanPrice(@Param("price") int price);
	//Query MethodName using findBy or getBooKByFieldName
	List<Book> getBookByAuthorNameAndPublisher(String authorName, String publisher);
    
	//using Named Parameter you can use any one of syntax
	//@Query("select b from Book b where b.publishedYear between :startYear and :endYear")
	//List<Book> bookPublishedBetweenYear(@Param("startYear") LocalDate startYear,@Param("endYear") LocalDate endYear);
	
	//using Positional parameter
	@Query("select b from Book b where b.publishedYear between ?1 and ?2")
	List<Book> bookPublishedBetweenYear(LocalDate startYear,LocalDate endYear);
	
	@Query("select b from Book b where b.publishedYear >?1")
	List<Book> bookPublishedAfterYear(LocalDate year);
	
	
	
}