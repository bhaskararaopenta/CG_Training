package com.cg.ovms.entities;
 
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
 
@Entity
@Data
public class Driver {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer driverId;
 
    @NotNull(message = "First name cannot be null")
    @Size(min = 2, message = "First name should have at least 2 characters")
    private String firstName;
 
    @NotNull(message = "Last name cannot be null")
    @Size(min = 2, message = "Last name should have at least 2 characters")
    private String lastName;
 
    @NotNull(message = "Address cannot be null")
    private String address;
 
    @NotNull(message = "Mobile number cannot be null")
    private String mobileNumber;
 
    @NotNull(message = "Email ID cannot be null")
    private String emailId;
 
    @NotNull(message = "License number cannot be null")
    @Size(min = 5, message = "License number should have at least 5 characters")
    private String licenseNo;
    
    
    private int  vehicleId;
}