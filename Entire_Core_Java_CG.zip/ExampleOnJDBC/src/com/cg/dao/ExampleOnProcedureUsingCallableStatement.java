package com.cg.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ExampleOnProcedureUsingCallableStatement {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Connection con = DBUtil.getMySQLConnection();
		
		String query="{call getEmpDetails(?)}";
		CallableStatement cstmt = con.prepareCall(query);
		cstmt.setInt(1, 20);
		
		ResultSet rs = cstmt.executeQuery();
		
		while (rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getDouble(3));
		}

	}

}
