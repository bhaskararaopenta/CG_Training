package com.cg.utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HIbernateUtil {
	static SessionFactory sfty = null;

	public static SessionFactory getUserSessionFactory() {
		Configuration cfg = new Configuration();
		cfg.configure(); // it will load hibernate.cfg.xml
		sfty = cfg.buildSessionFactory();
		return sfty;
	}

}
