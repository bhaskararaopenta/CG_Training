package com.cg.hbm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.entity.Transactions;
import com.cg.hbm.exceptions.TransactionsNotFoundException;
import com.cg.hbm.service.ITransactionService;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    @Autowired
    private ITransactionService iTransactionService;

    // Add a new transaction
    @PostMapping("/add")
    public Transactions addTransaction(@RequestBody Transactions transaction) throws TransactionsNotFoundException {
        return iTransactionService.addTransaction(transaction);
    }

    // Get a specific transaction by ID
    @GetMapping("/{transactionId}")
    public ResponseEntity<Transactions> showTransactions(@PathVariable int transactionId) throws TransactionsNotFoundException {
        Transactions transaction = iTransactionService.showTransaction(transactionId);
        return new ResponseEntity<>(transaction, HttpStatus.OK);
    }

    // Get all transactions
    @GetMapping("/showall")
    public ResponseEntity<List<Transactions>> getAllTransactions() throws TransactionsNotFoundException {
        List<Transactions> transactions = iTransactionService.showAllTransactions();
        return new ResponseEntity<>(transactions, HttpStatus.OK);
    }
}