package com.cg.hbm.consumes;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.hbm.entity.Transactions;

@FeignClient(name = "TransactionModule")
public interface PaymentFeignClient {

    // Fetch a transaction by its ID
    @GetMapping("/api/transactions/{transactionId}")
    Transactions getTransaction(@PathVariable int transactionId);
}
