package com.cg;

import com.cg.model.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

/**
 * Hello world!
 *
 */
public class StudentRemove {
	public static void main(String[] args) {
		EntityManagerFactory emfty = Persistence.createEntityManagerFactory("bhaskar");
		EntityManager em = emfty.createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();

		Student sobj = em.find(Student.class, 12345);
		if (sobj != null) {
			em.remove(sobj);
		}

		et.commit();
		em.close();
	}
}
