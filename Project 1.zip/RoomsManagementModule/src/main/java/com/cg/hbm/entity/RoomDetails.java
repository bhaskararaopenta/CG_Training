package com.cg.hbm.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Setter
@Getter
@Entity
@Table(name = "roomdetails")
public class RoomDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int room_id; // Unique identifier for the room

    @Min(1)
    private int hotel_id; // Identifier for the associated hotel

    @NotNull(message = "Room number cannot be null")
    @NotEmpty(message = "Room number cannot be empty")
    private String room_no; // Room number with validation

    @NotNull(message = "Room type cannot be null")
    @NotEmpty(message = "Room type cannot be empty")
    @Pattern(regexp = "^(Single|Double|Suite|Penthouse|Deluxe)$", message = "Room type must be one of the following: Single, Double, Suite, Penthouse, Deluxe")
    private String room_type; // Room type with specific pattern validation

    @DecimalMin(value = "0.01", message = "Rate per day must be greater than 0")
    private double rate_per_day; // Rate per day with minimum value validation

    private boolean isAvailable; // Availability status of the room

    @Pattern(regexp = ".*\\.(jpg|jpeg|png|gif)$", message = "Photo must be an image file with .jpg, .jpeg, .png, or .gif extension")
    private String photo; // Photo URL with validation for image file extensions
}