package com.cg.hbm.service;

import com.cg.hbm.entites.Transactions;

public interface ITransactionService {
	public Transactions addTransaction(Transactions transaction);
}
