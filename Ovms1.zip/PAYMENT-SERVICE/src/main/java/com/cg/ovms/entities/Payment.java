package com.cg.ovms.entities;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Payment {
	@Id
    @Positive(message = "Payment ID must be a positive number")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int paymentId;

    @NotEmpty(message = "Payment status cannot be null")
    @Size(min = 3, message = "Payment status should have at least 3 characters")
    private String paymentStatus;

    
    @Pattern(regexp = "CASH|CARD|ONLINE", message = "Payment mode must be either 'CASH', 'CARD', or 'ONLINE'")
    private String paymentMode;

    @PastOrPresent(message = "Payment date cannot be in the future")
    private LocalDate paymentDate;
    
    
    @Positive(message = "Must be grater than 0")
	private int bookingId;
    
    
    
    @Positive(message = "Must be grater than 0")
    private int  vehicleId;
    
  
    
    
    
}