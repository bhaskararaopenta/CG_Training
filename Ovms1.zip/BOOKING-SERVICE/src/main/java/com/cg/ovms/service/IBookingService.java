package com.cg.ovms.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.ovms.entities.Booking;

public interface IBookingService {

	public Booking addBooking(Booking booking);
	public Booking cancelBooking(Booking b);
	public Booking updateBooking(Booking b);
	public Booking viewById(int bookingId);
	public List<Booking> viewAllBooking(int customerId);
	public List<Booking> viewAllBookingByDate (LocalDate bookingDate);
	public List<Booking> viewAllBookingByVehicle(int vehicleId);
}
