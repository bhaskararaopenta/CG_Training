package com.training.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.consumes.BugConsumesEmployee;
import com.training.consumes.BugConsumesProject;
import com.training.dto.BugDTO;
import com.training.dto.EmployeeDTO;
import com.training.dto.ProjectDTO;
import com.training.dto.ResponseDTO;
import com.training.exception.BugException;
import com.training.service.IBugService;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/bug")
public class BugController {
	@Autowired
	private IBugService bugService;

	@Autowired
	private Environment environment;

	@Autowired
	private BugConsumesEmployee bugConsumesEmployee;
	
	@Autowired
	private BugConsumesProject bugConsumesProject;

	
	  @PostMapping(value = "/postbug") 
	  public ResponseEntity<BugDTO>addBug(@Valid @RequestBody BugDTO bugDTO) throws BugException {  
		  BugDTO bugDTO1 = bugService.createBug(bugDTO); 
		  String success =environment.getProperty("API.INSERT_SUCCESS") + bugDTO1;
	  
	  return new ResponseEntity<>(bugDTO1, HttpStatus.CREATED);
	  
	  } 

	
	@GetMapping(value = "/get/{id}")
	public ResponseEntity<BugDTO> getBug(@PathVariable Long id) throws BugException {
		System.out.println("Accessing Bug Service From port number:"+environment.getProperty("server.port"));

		BugDTO bugDTOs = bugService.getBug( id);
		
		return new ResponseEntity<>(bugDTOs, HttpStatus.OK);
	}

	@GetMapping(value = "/getbugs")
	public ResponseEntity<List<BugDTO>> getAllCustomers() throws BugException {
		List<BugDTO> bugDTOs = bugService.getAllBugs();
		return new ResponseEntity<>(bugDTOs, HttpStatus.OK);
	}

	@PutMapping(value = "/put/{id}")
	public ResponseEntity<String> updateBug(@PathVariable Long id, @Valid @RequestBody BugDTO bug) throws BugException {
		bugService.updateBug(id, bug);
		String successMessage = environment.getProperty("API.UPDATE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}

	@DeleteMapping(value = "/delete/{id}")
	public ResponseEntity<String> deleteBug(@PathVariable Long id) throws BugException {
		bugService.deleteBug(id);
		String successMessage = environment.getProperty("API.DELETE_SUCCESS");
		return new ResponseEntity<>(successMessage, HttpStatus.OK);
	}
	
	
	
	

	//CONNECTION OF SERVICES
	@GetMapping(value = "/getBug/{id}")
	public ResponseEntity<ResponseDTO> getEmployeeProjectByBugId(@PathVariable Long id) throws BugException {
		System.out.println("Accessing Bug Service From port number:"+environment.getProperty("server.port"));

		BugDTO bugDTOs = bugService.getBug( id);
		
		long eid=bugDTOs.getEmployeeId();
		long pid=bugDTOs.getProjectId();
		
		EmployeeDTO empdto= bugConsumesEmployee.bugConsumesEmplyoeeById(eid);
		
		ProjectDTO prodto= bugConsumesProject.bugConsumesProjectById(pid);
		
		ResponseDTO rdto = new ResponseDTO();
		rdto.setBdto(bugDTOs);
		rdto.setEdto(empdto);
		rdto.setPdto(prodto);
		
		return new ResponseEntity<>(rdto, HttpStatus.OK);
	}
	
	
}
