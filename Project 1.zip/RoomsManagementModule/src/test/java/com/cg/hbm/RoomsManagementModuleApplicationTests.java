package com.cg.hbm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.hbm.RoomsManagementModuleApplication;

@SpringBootTest(classes = RoomsManagementModuleApplication.class)
class RoomsManagementModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
