package com.day20.threads;

class ExampleOnTable {

	public synchronized void printTable(int n) {
		for (int i = 0; i <= 10; i++) {
			System.out.println(n + "X" + i + "=" + (n * i));
		}
	}
}

class DemoOnThread extends Thread {
	ExampleOnTable eot;
	int n;

	public DemoOnThread(ExampleOnTable eot,int n) {
		this.eot = eot;
		this.n=n;
	}

	@Override
	public void run() {
		eot.printTable(n);
	}
}

public class TestDemo {
	public static void main(String[] args) {
		ExampleOnTable et=new ExampleOnTable();
		
		DemoOnThread dot=new DemoOnThread(et,2);
		dot.start();
		
		DemoOnThread dot1=new DemoOnThread(et,7);
		dot1.start();
	}
}
