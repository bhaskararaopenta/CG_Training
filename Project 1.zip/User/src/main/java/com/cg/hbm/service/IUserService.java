package com.cg.hbm.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.hbm.entity.User;
import com.cg.hbm.exceptions.UserNotFoundException;

@Service
public interface IUserService {

    // Add a new user
    public User addUser(User user) throws UserNotFoundException;

    // Update an existing user
    public User updateUser(User user) throws UserNotFoundException;

    // Remove a user
    public User removeUser(User user) throws UserNotFoundException;

    // Show all users
    public List<User> showAllUsers() throws UserNotFoundException;

    // Show a specific user
    public User showUser(User user) throws UserNotFoundException;
}