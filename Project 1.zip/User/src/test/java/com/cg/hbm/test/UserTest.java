package com.cg.hbm.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.hbm.entity.User;
import com.cg.hbm.exceptions.UserNotFoundException;
import com.cg.hbm.repository.UserRepository;
import com.cg.hbm.service.IUserServiceImpl;

@ExtendWith(MockitoExtension.class)
public class UserTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private IUserServiceImpl userService;

    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setUser_id(1);
        user.setUser_name("John Doe");
        user.setEmail("john.doe@example.com");
        user.setPassword("password");
        user.setRole("USER");
        user.setAddress("123 Main St");
    }

    // Test for adding a user
    @Test
    public void testAddUser() throws UserNotFoundException {
        when(userRepository.save(any(User.class))).thenReturn(user);
        User createdUser = userService.addUser(user);
        assertEquals(user, createdUser);
    }

    // Test for updating a user
    @Test
    public void testUpdateUser() throws UserNotFoundException {
        when(userRepository.findById(user.getUser_id())).thenReturn(Optional.of(user));
        when(userRepository.save(any(User.class))).thenReturn(user);
        User updatedUser = userService.updateUser(user);
        assertEquals(user, updatedUser);
    }

    // Test for removing a user
    @Test
    public void testRemoveUser() throws UserNotFoundException {
        when(userRepository.findById(user.getUser_id())).thenReturn(Optional.of(user));
        User removedUser = userService.removeUser(user);
        verify(userRepository, times(1)).delete(user);
        assertEquals(user, removedUser);
    }

    // Test for showing all users
    @Test
    public void testShowAllUsers() throws UserNotFoundException {
        List<User> users = Arrays.asList(user);
        when(userRepository.findAll()).thenReturn(users);
        List<User> allUsers = userService.showAllUsers();
        assertEquals(users, allUsers);
    }

    // Test for showing a specific user
    @Test
    public void testShowUser() throws UserNotFoundException {
        when(userRepository.findById(user.getUser_id())).thenReturn(Optional.of(user));
        User foundUser = userService.showUser(user);
        assertEquals(user, foundUser);
    }

    // Test for handling user not found exception
    @Test
    public void testShowUserNotFound() {
        when(userRepository.findById(user.getUser_id())).thenReturn(Optional.empty());
        assertThrows(UserNotFoundException.class, () -> {
            userService.showUser(user);
        });
    }
}