import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// Fill the code here
		System.out.println("Enter the sentence");
		String input = sc.nextLine();
		int howMany = input.split(" ").length;
		System.out.println("Word Count :" + howMany);
		if (howMany%2==0) {
			String res = two(input);
			System.out.println(res);
		} else if (howMany%2!=0) {
			String res1 = three(input);
			System.out.println(res1);
		} else {
			System.out.println("Invalid Sentence");
		}
	}

	public static String three(String input) {
		// TODO Auto-generated method stub
		String ret = "";
		String[] res = input.split(" ");
		for (int i = 0; i < res.length; i++) {
			ret = ret + " " + reverse(res[i]);
		}
		return ret;
	}

	private static String reverse(String string) {
		String ret = "";

		for (int i = 0; i < string.length(); i++) {
			ret = string.charAt(i) + ret;
		}
		// TODO Auto-generated method stub
		return ret;
	}

	public static String two(String input) {
		String ret = "";
		String[] res = input.split(" ");
		for (int i = 0; i < res.length; i++) {
			ret = res[i] + " " + ret;
		}
		// TODO Auto-generated method stub
		return ret;
	}

}
