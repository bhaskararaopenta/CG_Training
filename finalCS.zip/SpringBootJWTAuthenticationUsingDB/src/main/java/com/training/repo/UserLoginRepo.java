package com.training.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.training.entity.UserLogin;


@Repository
public interface UserLoginRepo extends CrudRepository<UserLogin,Long> {

	public UserLogin findByRole(String role);

}
