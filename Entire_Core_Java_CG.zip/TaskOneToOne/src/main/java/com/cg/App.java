package com.cg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cg.entity.Address;
import com.cg.entity.Employee;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure();

		SessionFactory sfty = cfg.buildSessionFactory();
		Session sion = sfty.openSession();
		Transaction tx = sion.beginTransaction();

		Address ad = new Address();
		ad.setAddrId(102);
		ad.setLoc("CHN");
		ad.setPin("50811");
		sion.persist(ad);

		Employee emp1 = new Employee();
		emp1.setEmpId(2);
		emp1.setEmpName("B");
		emp1.setEmpSal(3.2);
		emp1.setAddr(ad);

		sion.persist(emp1);

//		Employee emp2 = new Employee();
//		emp2.setEmpId(3);
//		emp2.setEmpName("C");
//		emp2.setEmpSal(4.4);
//
//		sion.persist(emp2);
		tx.commit();
	}
}
