package com.day5.example2OnInterface;

public interface MyInt1 {
	public void m1();
	public abstract String sayHello(String s);
 
}
