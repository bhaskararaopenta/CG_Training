package com.cg.hbm.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.hbm.entity.RoomDetails;
import com.cg.hbm.exceptions.RoomDetailsNotFoundException;
import com.cg.hbm.repository.IRoomDetailsRepository;

@Service
public class IRoomDetailsServiceImpl implements IRoomDetailsService {

    @Autowired
    private IRoomDetailsRepository detailsRepository;

    // Add a new room detail
    @Override
    public RoomDetails addRoomDetails(RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        return detailsRepository.save(roomDetails);
    }

    // Update existing room details
    @Override
    public RoomDetails updateRoomDetails(RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        Optional<RoomDetails> roomdetail = detailsRepository.findById(roomDetails.getRoom_id());
        RoomDetails details = roomdetail.orElseThrow(() -> new RoomDetailsNotFoundException("Service.ROOMDETAILS_NOT_FOUND"));
        details.setHotel_id(roomDetails.getHotel_id());
        details.setRoom_no(roomDetails.getRoom_no());
        details.setRoom_type(roomDetails.getRoom_type());
        details.setRate_per_day(roomDetails.getRate_per_day());
        details.setAvailable(roomDetails.isAvailable());
        details.setPhoto(roomDetails.getPhoto());
        detailsRepository.save(details);
        return details;
    }

    // Remove room details
    @Override
    public RoomDetails removeRoomDetails(RoomDetails roomDetails) throws RoomDetailsNotFoundException {
        Optional<RoomDetails> roomdetail = detailsRepository.findById(roomDetails.getRoom_id());
        RoomDetails details = roomdetail.orElseThrow(() -> new RoomDetailsNotFoundException("Service.ROOMDETAIL_NOT_FOUND"));
        detailsRepository.delete(details);
        return details;
    }

    // Show all room details
    @Override
    public List<RoomDetails> showAllRoomDetails() throws RoomDetailsNotFoundException {
        return detailsRepository.findAll();
    }

    // Show specific room details by ID
    @Override
    public RoomDetails showRoomDetails(int roomDetails_id) throws RoomDetailsNotFoundException {
        Optional<RoomDetails> details = detailsRepository.findById(roomDetails_id);
        RoomDetails showroomdetails = details.orElseThrow(() -> new RoomDetailsNotFoundException("Service.ROOMDETAIL_NOT_FOUND"));
        return showroomdetails;
    }
}
