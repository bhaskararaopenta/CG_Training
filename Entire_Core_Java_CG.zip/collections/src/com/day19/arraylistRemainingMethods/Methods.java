package com.day19.arraylistRemainingMethods;

import java.util.ArrayList;
import java.util.stream.Stream;

public class Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(30);
		al.add(40);
		al.add(10);
		al.add(50);
		al.add(30);
		al.add(5);
		al.add(40);

		System.out.println("no of elements :" + al.size());

		// distinct() -> will remove the duplicates

		System.out.println("After removing duplicates");
		Stream<Integer> st = al.stream();
		st.distinct().forEach(System.out::println);

		System.out.println("first four elements :");
		// limit(int) -> it will display no of elements
		al.stream().limit(4).forEach(System.out::println);

		System.out.println("Skip four elements :");
		// skip(int) -> it will skip no of elements
		al.stream().skip(4).forEach(System.out::println);

	}

}
