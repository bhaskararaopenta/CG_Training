package com.cg.validator;

import java.time.LocalDate;

import com.cg.dto.BookDTO;
import com.cg.exception.CGBookException;

public class Validator {

	public static void validate(BookDTO bookDTO) throws CGBookException {

	}

	public static boolean validateYear(LocalDate year) {
		return false;
	}

}