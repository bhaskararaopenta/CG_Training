package com.cg.hbm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.hbm.entity.User;
import com.cg.hbm.exceptions.UserNotFoundException;
import com.cg.hbm.service.IUserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
@Validated
public class UserController {

    @Autowired
    private IUserService userService;

    // Add a new user
    @PostMapping("/add")
    public User addUser(@Valid @RequestBody User user) throws UserNotFoundException {
        return userService.addUser(user);
    }

    // Update an existing user
    @PutMapping("/update/{user_id}")
    public ResponseEntity<User> updateUser(@Valid @PathVariable int user_id, @Valid @RequestBody User user) throws UserNotFoundException {
        user.setUser_id(user_id);
        User updatedUser = userService.updateUser(user);
        return new ResponseEntity<>(updatedUser, HttpStatus.OK);
    }

    // Delete a user by ID
    @DeleteMapping("/delete/{user_id}")
    public ResponseEntity<User> removeUser(@Valid @PathVariable int user_id) throws UserNotFoundException {
        User user1 = new User();
        user1.setUser_id(user_id);
        User deletedUser = userService.removeUser(user1);
        return new ResponseEntity<>(deletedUser, HttpStatus.OK);
    }

    // Get all users
    @GetMapping("/allusers")
    public List<User> showAllUsers() throws UserNotFoundException {
        return userService.showAllUsers();
    }

    // Get a user by ID
    @GetMapping("/{user_id}")
    public User showUser(@Valid @PathVariable int user_id) throws UserNotFoundException {
        User user = new User();
        user.setUser_id(user_id);
        return userService.showUser(user);
    }
}