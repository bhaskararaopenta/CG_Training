import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class UserInterface {
	public static void main(String args[]) throws ParseException {
		Scanner sc = new Scanner(System.in);
		ForensicReport fr = new ForensicReport();
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simFormat = new SimpleDateFormat(pattern);
		// DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		System.out.println("Enter number of reports to be added");
		int count = sc.nextInt();

		sc.nextLine();

		for (int i = 0; i < count; i++) {
			System.out.println("Enter the Forensic reports (Reporting Officer: Report Filed Date)");
			String input = sc.nextLine();
			String[] twoInputs = input.split(":");
			String name = twoInputs[0];
			String date = twoInputs[1];

			String d2 = simFormat.format(date);

			Date d = simFormat.parse(d2);

			fr.addReportDetails(name, d);

		}

		System.out.println("Enter the filed date to identify the reporting officers");
		String dateee = sc.next();

		String d3 = simFormat.format(dateee);
		Date fd3 = simFormat.parse(d3);

		List<String> res = fr.getOfficersWhoFiledReportsOnDate(fd3);
		if (res.isEmpty()) {
			System.out.println("No reporting officer filed the report");
		} else {
			System.out.println("Reports filed on the " + fd3 + " are by ");
			for (String string : res) {
				System.out.println(string);
			}
		}

		// Fill the code here
	}

}
