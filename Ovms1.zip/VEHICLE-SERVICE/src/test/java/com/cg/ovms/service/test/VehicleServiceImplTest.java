package com.cg.ovms.service.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.ovms.entites.Vehicle;
import com.cg.ovms.repository.VehicleRepository;
import com.cg.ovms.service.VehicleServiceImpl;

class VehicleServiceImplTest {

    @Mock
    private VehicleRepository vehicleRepository;

    @InjectMocks
    private VehicleServiceImpl vehicleService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddVehicle() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1);
        when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);

        Vehicle result = vehicleService.addVehicle(vehicle);
        assertNotNull(result);
        assertEquals(1, result.getVehicleId());
    }

    @Test
    void testUpdateVehicle() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1);
        when(vehicleRepository.save(any(Vehicle.class))).thenReturn(vehicle);

        Vehicle result = vehicleService.updateVehicle(vehicle);
        assertNotNull(result);
        assertEquals(1, result.getVehicleId());
    }

    @Test
    void testDeleteVehicle() {
        doNothing().when(vehicleRepository).deleteById(1);
        vehicleService.deleteVehicle(1);
        verify(vehicleRepository, times(1)).deleteById(1);
    }

    @Test
    void testGetVehicleById() {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleId(1);
        when(vehicleRepository.findById(1)).thenReturn(Optional.of(vehicle));

        Vehicle result = vehicleService.getVehicleById(1);
        assertNotNull(result);
        assertEquals(1, result.getVehicleId());
    }

    @Test
    void testGetAllVehicles() {
        when(vehicleRepository.findAll()).thenReturn(List.of(new Vehicle(), new Vehicle()));

        List<Vehicle> result = vehicleService.getAllVehicles();
        assertNotNull(result);
        assertEquals(2, result.size());
    }
}

