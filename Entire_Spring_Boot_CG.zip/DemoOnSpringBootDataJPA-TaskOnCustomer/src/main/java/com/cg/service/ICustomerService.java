package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.dto.CustomerDTO;

public interface ICustomerService {

	public int insertCustomer(CustomerDTO c);

	public Optional<CustomerDTO> searchById(int id);

	public List<CustomerDTO> getAllCustomerDetails();

	public void customerDeleteById(int id);

	public int updateCustomer(CustomerDTO c);
}
