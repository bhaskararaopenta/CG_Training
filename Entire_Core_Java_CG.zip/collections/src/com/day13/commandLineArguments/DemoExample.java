package com.day13.commandLineArguments;

public class DemoExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String a = args[0];
		String b = args[1];
		System.out.println(a + " " + b);

	}

}
