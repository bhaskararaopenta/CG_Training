package com.day20.threads;

public class DemoOnThreadUsingLambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Runnable robj = () -> {
			for (int i = 0; i < 5; i++) {
				System.out.println("we are in child thread");
			}
		};

		Thread tobj = new Thread(robj);
		tobj.start();

	}

}
