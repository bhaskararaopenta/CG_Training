package com.cg.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	@Autowired
	private EmployeeService eService;

	@GetMapping("/getEmp") // http://localhost:8000/myapp/emp/getEmp
	public String getEmployee() {
		return "welcome to SpringBootRestApi services";
	}

	@PostMapping("/insert") // http://localhost:8000/myapp/emp/insert
	public String postEmployee() {
		return "post mapping request for insert";
	}

	@PutMapping("/updateAll") // http://localhost:8000/myapp/emp/updateAll
	public String putEmployee() {
		return "put mapping will update all the fields";
	}

	@PatchMapping("/partial") // http://localhost:8000/myapp/emp/partial
	public String patchEmployee() {
		return "partial mapping will help to update particular fields ";
	}

	@DeleteMapping("/delete") // http://localhost:8000/myapp/emp/getEmp
	public String deleteEmployee() {
		return "delete request is used to delete the record";
	}

	@GetMapping("/gt") // http://localhost:8000/myapp/emp/gt?id=1000&name=bhaskar&salary=15000
	public String reqParamEmployee(@RequestParam int id, @RequestParam String name, @RequestParam double salary) {
		return "Employee details are \n " + id + " " + name + " " + salary;
	}

	@GetMapping("/gtPath/{id}/{name}/{salary}") // http://localhost:8000/myapp/emp/gtPath/1000/bhaskar/15000
	public String reqPathEmployee(@PathVariable int id, @PathVariable String name, @PathVariable double salary) {
		return "Employee details are \n " + id + " " + name + " " + salary;
	}

	@GetMapping("/p1/{firstName}") // http://localhost:8000/myapp/emp/p1/bhaskara?lastName=Rao
	public String reqBothParamAndPathEmployee(@PathVariable String firstName, @RequestParam String lastName) {
		return "Employee details are \n " + firstName + " " + lastName;
	}

	@GetMapping("/gtPathNameConv/{empId}/{ename}/{salary}") // http://localhost:8000/myapp/emp/gtPathNameConv/1000/bhaskar/15000
	public String reqPathNamingConventionEmployee(@PathVariable("empId") int id, @PathVariable("ename") String name,
			@PathVariable double salary) {
		return "Employee details are \n " + id + " " + name + " " + salary;
	}

	@PostMapping("/add") // http://localhost:8000/myapp/emp/add --->postman-body-raw-json-{
//	"empId":1000,"empName":"Chand","empSal":25000,"job":"HR"}
	public Employee addEmployee(@RequestBody Employee eobj) {
		eService.insertEmployee(eobj);
		return eobj;
	}
}
