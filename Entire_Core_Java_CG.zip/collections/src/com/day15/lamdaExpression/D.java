package com.day15.lamdaExpression;

public class D implements XYZ {

	@Override
	public void m1() {
		System.out.println("We are in methodOne of D class");
	}

	@Override
	public void m2() {
		System.out.println("We are in methodTwo of D class");
	}

}
