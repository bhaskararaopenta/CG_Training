package com.cg.hbm.service;

import java.util.List;

import com.cg.hbm.entites.BookingDetails;
import com.cg.hbm.exceptions.BookingDetailsNotFoundException;

public interface IBookingDetailsService {
	public BookingDetails addBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException;
	public BookingDetails updateBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException;
	public BookingDetails removeBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException;
	public List<BookingDetails> showAllBookingDetails(); 
	public BookingDetails showBookingDetails(BookingDetails bookingDetails) throws BookingDetailsNotFoundException;
}
