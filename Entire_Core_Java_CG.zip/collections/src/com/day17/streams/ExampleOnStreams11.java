package com.day17.streams;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ExampleOnStreams11 {

	public static void main(String[] args) {

		
	}
}
