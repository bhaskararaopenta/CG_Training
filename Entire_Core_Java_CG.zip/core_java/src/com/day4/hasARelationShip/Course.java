package com.day4.hasARelationShip;

public class Course {

	int cId;
	String Cname;
	double fees;

	public Course(int cId, String cname, double fees) {
		super();
		this.cId = cId;
		Cname = cname;
		this.fees = fees;
	}

}
