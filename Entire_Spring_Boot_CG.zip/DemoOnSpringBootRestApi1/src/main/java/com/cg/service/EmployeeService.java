package com.cg.service;

import org.springframework.stereotype.Service;

import com.cg.bean.Employee;

public interface EmployeeService {

	public void insertEmployee(Employee e);
}
