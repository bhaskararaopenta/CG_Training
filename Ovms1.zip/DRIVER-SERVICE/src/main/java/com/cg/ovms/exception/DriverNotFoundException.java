package com.cg.ovms.exception;

public class DriverNotFoundException  extends RuntimeException{

	public DriverNotFoundException(String msg) {
		super(msg);
	}
}
