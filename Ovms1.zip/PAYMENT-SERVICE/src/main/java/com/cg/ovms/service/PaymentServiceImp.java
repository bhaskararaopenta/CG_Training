package com.cg.ovms.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.entities.Payment;
import com.cg.ovms.exception.ResourceNotFoundException;
import com.cg.ovms.repository.PaymentRepository;

@Service
public class PaymentServiceImp implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public Payment addPayment(Payment payment) {
        // Save the payment, assuming validation is done before calling this method
        return paymentRepository.save(payment);
    }

    @Override
    public Payment cancelPayment(Payment p) throws ResourceNotFoundException {
        Optional<Payment> existingPayment = paymentRepository.findById(p.getPaymentId());
        if (!existingPayment.isPresent()) {
            throw new ResourceNotFoundException("Payment with ID " + p.getPaymentId() + " not found.");
        }
        Payment payment = existingPayment.get();
        // Here, we assume that canceling means updating payment status to 'Cancelled'
        payment.setPaymentStatus("Cancelled");
        return paymentRepository.save(payment);
    }

    @Override
    public List<Payment> viewByVehicleIdEquals(int vehicleId) {
        return paymentRepository.findByVehicleIdEquals(vehicleId);
    }

    @Override
    public List<Payment> viewByBookingIdEquals(int bookingId) {
        return paymentRepository.findByBookingIdEquals(bookingId);
    }
}