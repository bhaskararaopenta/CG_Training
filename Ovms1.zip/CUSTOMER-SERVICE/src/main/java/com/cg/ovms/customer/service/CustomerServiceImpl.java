package com.cg.ovms.customer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ovms.customer.entity.Customer;
import com.cg.ovms.customer.exception.DuplicateRecordException;
import com.cg.ovms.customer.exception.ResourceNotFoundException;
import com.cg.ovms.customer.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer addCustomer(Customer customer) throws DuplicateRecordException {
        // Check if a customer with the same email already exists
        Optional<Customer> existingCustomer = customerRepository.findByEmailld(customer.getEmailld());
        if (existingCustomer.isPresent()) {
            throw new DuplicateRecordException("Customer already exists with email: " + customer.getEmailld());
        }
        // Save the new customer
        return customerRepository.save(customer);
    }

    @Override
    public Customer removeCustomer(Customer customer) throws ResourceNotFoundException {
       
        Optional<Customer> existingCustomer = customerRepository.findById(customer.getCustomerld());
        if (!existingCustomer.isPresent()) {
            throw new ResourceNotFoundException("Customer not found with ID: " + customer.getCustomerld());
        }
     
        customerRepository.delete(customer);
        return customer;
    }

    @Override
    public Customer updateCustomer(Customer customer) throws ResourceNotFoundException, DuplicateRecordException {
     
        Optional<Customer> existingCustomer = customerRepository.findById(customer.getCustomerld());
        if (!existingCustomer.isPresent()) {
            throw new ResourceNotFoundException("Customer not found with ID: " + customer.getCustomerld());
        }

        
        Optional<Customer> existingCustomerByEmail = customerRepository.findByEmailld(customer.getEmailld());
        if (existingCustomerByEmail.isPresent() && existingCustomerByEmail.get().getCustomerld() != customer.getCustomerld()) {
            throw new DuplicateRecordException("Customer already exists with email: " + customer.getEmailld());
        }
        return customerRepository.save(customer);
    }

    @Override
    public Customer viewCustomer(Customer customer) throws ResourceNotFoundException {
      
        return customerRepository.findById(customer.getCustomerld())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with ID: " + customer.getCustomerld()));
    }

    @Override
    public List<Customer> viewAllCustomers(String vtype) throws ResourceNotFoundException {
       
        List<Customer> customers = customerRepository.findAll();
        if (customers.isEmpty()) {
            throw new ResourceNotFoundException("No customers found.");
        }
        return customers;
    }

    @Override
    public List<Customer> viewAllCustomersByLocation(String location) throws ResourceNotFoundException {
   
        List<Customer> customers = customerRepository.findByAddress(location);
        if (customers.isEmpty()) {
            throw new ResourceNotFoundException("No customers found in the specified location.");
        }
        return customers;
    }

	@Override
	public Customer viewCustomer(int customerId) throws ResourceNotFoundException {
		
		return customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with ID: " + customerId));
    }

	
}