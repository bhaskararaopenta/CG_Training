package com.cg.hbm.entites;

import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Entity
@Table(name = "bookinghotel")
@Data // Lombok annotation to generate getters, setters, equals, and other methods
public class BookingDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookingId;

	@NotNull
	private int hotelId;

	@NotNull(message = "Room ID must not be null.")
	@Min(value = 1, message = "Room ID must be greater than zero.")
	private int roomId;

	@NotNull(message = "User ID must not be null.")
	@Min(value = 1, message = "User ID must be greater than zero.")
	private int userId;

	@NotNull(message = "Booking start date must not be null.")
	@FutureOrPresent(message = "Booked from date must be in the present or future.")
	private LocalDate bookedFrom;

	@NotNull(message = "Booking end date must not be null.")
	@Future(message = "Booked to date must be in the future.")
	private LocalDate bookedTo;

	@Min(value = 1, message = "Number of adults must be at least 1.")
	private int noOfAdults;

	@Min(value = 0, message = "Number of children cannot be negative.")
	private int noOfChildren;

	@Min(value = 0, message = "Amount must be a positive value.")
	private double amount;

	
	// Assuming Hotel is a POJO class that corresponds to the Booking entity
	




	
	

	}
