package com.cg.hbm.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.hbm.entity.Payments;
import com.cg.hbm.exceptions.PaymentsNotFoundException;
import com.cg.hbm.repository.IPaymentRepository;
import com.cg.hbm.service.IPaymentServiceImpl;

@ExtendWith(MockitoExtension.class)
public class PaymentTest {

    @InjectMocks
    private IPaymentServiceImpl paymentService;

    @Mock
    private IPaymentRepository paymentRepository;

    private Payments payment;

    @BeforeEach
    public void setUp() {
        payment = new Payments();
        payment.setPaymentId(1);
        // Set other properties of payment as needed
    }

    @Test
    public void testAddPayment() throws PaymentsNotFoundException {
        // Mock the save method of the repository
        when(paymentRepository.save(payment)).thenReturn(payment);
        // Call the service method and assert the result
        Payments savedPayment = paymentService.addPayment(payment);
        assertEquals(payment, savedPayment);
    }

    @Test
    public void testShowPayment() throws PaymentsNotFoundException {
        // Mock the findById method of the repository
        when(paymentRepository.findById(1)).thenReturn(Optional.of(payment));
        // Call the service method and assert the result
        Payments foundPayment = paymentService.showPayment(1);
        assertEquals(payment, foundPayment);
    }

    @Test
    public void testShowPaymentNotFound() {
        // Mock the findById method to return an empty Optional
        when(paymentRepository.findById(1)).thenReturn(Optional.empty());
        // Assert that the service method throws the expected exception
        assertThrows(PaymentsNotFoundException.class, () -> {
            paymentService.showPayment(1);
        });
    }

    @Test
    public void testShowAllPayments() throws PaymentsNotFoundException {
        // Create a list of payments and mock the findAll method
        List<Payments> paymentsList = Arrays.asList(payment);
        when(paymentRepository.findAll()).thenReturn(paymentsList);
        // Call the service method and assert the result
        List<Payments> foundPayments = paymentService.showAllPayments();
        assertEquals(paymentsList, foundPayments);
    }
}