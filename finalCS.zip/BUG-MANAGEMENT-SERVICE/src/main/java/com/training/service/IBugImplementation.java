package com.training.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.dto.BugDTO;
import com.training.entity.Bug;
import com.training.exception.BugException;
import com.training.repository.BugRepository;

@Service
public class IBugImplementation implements IBugService {

	@Autowired
	private BugRepository bugRepository;

	@Override
	public BugDTO createBug(BugDTO bugdto) throws BugException {

		Bug bugEntity = new Bug();
		bugEntity.setBugId(bugdto.getBugId());
		bugEntity.setTitle(bugdto.getTitle());
		bugEntity.setDescription(bugdto.getDescription());
		bugEntity.setType(bugdto.getType());
		bugEntity.setPriority(bugdto.getPriority());
		bugEntity.setProgress(bugdto.getProgress());
		bugEntity.setStatus(bugdto.getStatus());
		bugEntity.setStartDate(bugdto.getStartDate());
		bugEntity.setEndDate(bugdto.getEndDate());
		bugEntity.setProjectId(bugdto.getProjectId());
		bugEntity.setEmployeeId(bugdto.getEmployeeId());

		Bug bugEntity2 = bugRepository.save(bugEntity);

		BugDTO bugdto1 = new BugDTO();

		bugdto1.setBugId(bugEntity2.getBugId());
		bugdto1.setTitle(bugEntity2.getTitle());
		bugdto1.setDescription(bugEntity2.getDescription());
		bugdto1.setType(bugEntity2.getType());
		bugdto1.setPriority(bugEntity2.getPriority());
		bugdto1.setProgress(bugEntity2.getProgress());
		bugdto1.setStatus(bugEntity2.getStatus());
		bugdto1.setStartDate(bugEntity2.getStartDate());
		bugdto1.setEndDate(bugEntity2.getEndDate());
		bugdto1.setEmployeeId(bugEntity2.getEmployeeId());
		bugdto1.setProjectId(bugEntity2.getProjectId());

		return bugdto1;
	}

	@Override
	public BugDTO updateBug(Long id, BugDTO bugdto) throws BugException {

//		Optional<Bug> optional = bugRepository.findById(id);
//
//		Bug bugEntity = optional.get();

		Bug bugEntity = bugRepository.findById(id)
				.orElseThrow(() -> new BugException("service.BUG_ID_NOT_FOUND_TO_UPDATE"));
		
		bugEntity.setBugId(bugdto.getBugId());
		bugEntity.setTitle(bugdto.getTitle());
		bugEntity.setDescription(bugdto.getDescription());
		bugEntity.setType(bugdto.getType());
		bugEntity.setPriority(bugdto.getPriority());
		bugEntity.setProgress(bugdto.getProgress());
		bugEntity.setStatus(bugdto.getStatus());
		bugEntity.setStartDate(bugdto.getStartDate());
		bugEntity.setEndDate(bugdto.getEndDate());

		Bug bugEntity1 = bugRepository.save(bugEntity);

		BugDTO bugdto1 = new BugDTO();
		bugdto1.setBugId(bugEntity1.getBugId());
		bugdto1.setTitle(bugEntity1.getTitle());
		bugdto1.setDescription(bugEntity1.getDescription());
		bugdto1.setType(bugEntity1.getType());
		bugdto1.setPriority(bugEntity1.getPriority());
		bugdto1.setProgress(bugEntity1.getProgress());
		bugdto1.setStatus(bugEntity1.getStatus());
		bugdto1.setStartDate(bugEntity1.getStartDate());
		bugdto1.setEndDate(bugEntity1.getEndDate());

		return bugdto1;
	}

	@Override
	public BugDTO getBug(Long id) throws BugException {

		Optional<Bug> optional = bugRepository.findById(id);
		Bug bug = optional.orElseThrow(() -> new BugException("service.BUG_ID_NOT_FOUND"));

		BugDTO bugDTO = new BugDTO();

		bugDTO.setBugId(bug.getBugId());
		bugDTO.setTitle(bug.getTitle());
		bugDTO.setDescription(bug.getDescription());
		bugDTO.setType(bug.getType());
		bugDTO.setPriority(bug.getPriority());
		bugDTO.setProgress(bug.getProgress());
		bugDTO.setStatus(bug.getStatus());
		bugDTO.setStartDate(bug.getStartDate());
		bugDTO.setEndDate(bug.getEndDate());
		bugDTO.setEmployeeId(bug.getEmployeeId());
		bugDTO.setProjectId(bug.getProjectId());

		return bugDTO;
	}

	@Override
	public List<BugDTO> getAllBugs() throws BugException {

		Iterable<Bug> bug = bugRepository.findAll();

		List<BugDTO> bugDTOs = new ArrayList<>();
		bug.forEach(bg -> {
			BugDTO bgdto = new BugDTO();
			bgdto.setBugId(bg.getBugId());
			bgdto.setTitle(bg.getTitle());
			bgdto.setDescription(bg.getDescription());
			bgdto.setType(bg.getType());
			bgdto.setPriority(bg.getPriority());
			bgdto.setProgress(bg.getProgress());
			bgdto.setStatus(bg.getStatus());
			bgdto.setStartDate(bg.getStartDate());
			bgdto.setEndDate(bg.getEndDate());

			bugDTOs.add(bgdto);
		});
		if (bugDTOs.isEmpty())
			throw new BugException("Service.ALL_BUG_NOT_FOUND");
		return bugDTOs;
	}

	@Override
	public List<BugDTO> getAllBugsByStatus() throws BugException {

		Iterable<Bug> bug = bugRepository.findAll();
		List<BugDTO> bugdto = new ArrayList<>();
		bug.forEach(bg -> {
			BugDTO bgdto = new BugDTO();
			bgdto.setStatus(bg.getStatus());
		});
		return bugdto;

	}

	@Override
	public BugDTO deleteBug(Long id) throws BugException {
		Optional<Bug> optional = bugRepository.findById(id);

		Bug bug = optional.orElseThrow(() -> new BugException("service.BUG_ID_NOT_FOUND"));

		bugRepository.deleteById(id); // Changed to deleteById(id)

		BugDTO bugdto = new BugDTO();
		bugdto.setBugId(bug.getBugId());
		bugdto.setTitle(bug.getTitle());
		bugdto.setDescription(bug.getDescription());
		bugdto.setType(bug.getType());
		bugdto.setPriority(bug.getPriority());
		bugdto.setProgress(bug.getProgress());
		bugdto.setStatus(bug.getStatus());
		bugdto.setStartDate(bug.getStartDate());
		bugdto.setEndDate(bug.getEndDate());
		bugdto.setEmployeeId(bug.getEmployeeId());
		bugdto.setProjectId(bug.getProjectId());

		return bugdto;
	}

}
