package com.day5.interfaceTopic2Way;

public interface MyTest {
	public void m2();
	public String sayHello(String s);
	public abstract int addition(int x,int y);

 
}
