import java.util.Scanner;

public class UserInterface {
	public static void main(String[] args) {
		EntryUtility eu = new EntryUtility();
		Scanner scanner = new Scanner(System.in);
		// Fill the code here
		System.out.println("Enter the number of entries ");
		int count = scanner.nextInt();
		scanner.nextLine();
		for (int i = 1; i <= count; i++) {
			System.out.println("Enter entry " + i + " details ");
			String data = scanner.nextLine();
			String[] allData = data.split(":");
			String id = allData[0];
			String entryType = allData[1];
			int duration = Integer.parseInt(allData[2]);

			try {
				boolean res1 = EntryUtility.validateEmployeeId(id);
				boolean res2 = EntryUtility.validateDuration(duration);
				if (res1&res2==true) {
					System.out.println("Valid entry details");
				}
			} catch (InvalidEntryException e) {
				// TODO Auto-generated catch block
				System.out.println("Invalid entry details ");
			}

			
		}
	}
}
