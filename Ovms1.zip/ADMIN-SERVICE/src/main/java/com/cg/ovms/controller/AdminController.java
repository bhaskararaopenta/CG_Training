package com.cg.ovms.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ovms.client.BookingClient;
import com.cg.ovms.client.CustomerClient;
import com.cg.ovms.client.DriverClient;
import com.cg.ovms.client.PaymentClient;
import com.cg.ovms.customer.entity.Customer;
import com.cg.ovms.dto.ResponseDto;
import com.cg.ovms.entities.Booking;
import com.cg.ovms.entities.Driver;
import com.cg.ovms.entities.Payment;
import com.cg.ovms.entity.Admin;

import com.cg.ovms.service.AdminService;

import jakarta.validation.Valid;


@RestController
@RequestMapping("/admin")
@Validated
public class AdminController {

    @Autowired
    private AdminService adminService;
    
    @Autowired
    private BookingClient bookingClient;
    
    @Autowired
    private CustomerClient customerClient;
    
    @Autowired
    private DriverClient driverClient;
    
    @Autowired 
    private PaymentClient paymentClient;
    
    @PostMapping("/addAdmin")
    public ResponseEntity<Admin> addAdmin(@Valid @RequestBody Admin admin) {
        Admin newAdmin = adminService.addAdmin(admin);
        return ResponseEntity.ok(newAdmin);
    }

    @GetMapping("/byId/{id}")
    public ResponseEntity<Admin> viewAdmin(@Valid @PathVariable int id) {
        Admin admin = adminService.viewById(id);
        return ResponseEntity.ok(admin);
    }

    @DeleteMapping("/deleteAdmin/{id}")
    public ResponseEntity<Admin> deleteAdmin(@Valid @PathVariable int id) {
        Admin deletedAdmin = adminService.deleteById(id);
        return ResponseEntity.ok(deletedAdmin);
    }

    @PutMapping("/updateAdmin")
    public ResponseEntity<Admin> updateAdmin(@Valid @RequestBody Admin admin) {
        Admin updatedAdmin = adminService.updateAdmin(admin);
        return ResponseEntity.ok(updatedAdmin);       
    }
    
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<ResponseDto> getCustomerById(@PathVariable int customerId){
        Customer ret = customerClient.getCustomerById(customerId);
        ResponseDto rdto = new ResponseDto();
        rdto.setCustomer(ret);
        return ResponseEntity.ok(rdto);
    }

    @PostMapping("/addDriver")
    public ResponseEntity<ResponseDto> addDriver(@RequestBody Driver driver) {
        Driver newDriver = driverClient.addDriver(driver);
        ResponseDto rdto = new ResponseDto();
        rdto.setDriver(newDriver);
        return new ResponseEntity<>(rdto, HttpStatus.CREATED);
    }

    @DeleteMapping("/deleteDriver/{id}")
    public ResponseEntity<Void> deleteDriver(@PathVariable int id) {
        driverClient.deleteDriver(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping("/getDriver/{id}")
    public ResponseEntity<ResponseDto> findDriverById(@PathVariable int id) {
        Driver driver = driverClient.findDriverById(id);
        ResponseDto rdto = new ResponseDto();
        rdto.setDriver(driver);
        return new ResponseEntity<>(rdto, HttpStatus.OK);
    } 

    @GetMapping("/booking/{id}")
    public ResponseEntity<ResponseDto> viewBooking(@Valid @PathVariable int id) {
        Booking book = bookingClient.viewBooking(id);
        ResponseDto rdto = new ResponseDto();
        rdto.setBooking(book);
        return new ResponseEntity<>(rdto, HttpStatus.OK);
    }

    @DeleteMapping("/cancelBooking")
    public ResponseEntity<ResponseDto> cancelBooking(@Valid @RequestBody Booking booking) {
        Booking cancelledBooking = bookingClient.cancelBooking(booking);
        ResponseDto rdto = new ResponseDto();
        rdto.setBooking(cancelledBooking);
        return ResponseEntity.ok(rdto);
    }

    @GetMapping("/payments/vehicle")
    public ResponseEntity<ResponseDto> viewPaymentsByVehicle(@RequestParam int vehicleId) {
        List<Payment> payments = paymentClient.viewPaymentsByVehicle(vehicleId);
        ResponseDto rdto = new ResponseDto();
        rdto.setPayment(payments);
        return new ResponseEntity<>(rdto, HttpStatus.OK);
    }
}