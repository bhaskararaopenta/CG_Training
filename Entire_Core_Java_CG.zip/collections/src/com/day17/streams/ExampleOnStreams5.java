package com.day17.streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class ExampleOnStreams5 {

	public static void main(String[] args) {

		List<Integer> al = Arrays.asList(40, 10, 20, 5, 50, 30);

		Stream<Integer> st = al.stream();

		// max it takes comparator

		Comparator<Integer> cobj = (a, b) -> (a > b) ? 1 : (a < b) ? -1 : 0;

		int maxValue = st.max(cobj).get();
		System.out.println("max value is  " + " " + maxValue);

		Comparator<Integer> cobj2 = (a, b) -> (a < b) ? -1 : (a > b) ? 1 : 0;

		Stream<Integer> st1 = al.stream();
		int minValue = st1.min(cobj2).get();
		System.out.println("min value is  " + " " + minValue);

		Stream<Integer> st2 = al.stream();
		long a = st2.count();
		System.out.println(a);

		Stream<Integer> st3 = al.stream();
		int max1 = st3.max(Comparator.comparing(Integer::valueOf)).get();
		System.out.println("max value using comparator.comparing method " + max1);

		Stream<Integer> st4 = al.stream();
		int min1 = st4.min(Comparator.comparing(Integer::valueOf)).get();
		System.out.println("min value using comparator.comparing method " + min1);

		Stream<Integer> st5 = al.stream();
		long l = st5.count();
		System.out.println("count is : " + " " + l);

	}

}
